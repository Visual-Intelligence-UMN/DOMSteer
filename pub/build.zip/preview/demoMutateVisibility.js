(() => {
  window.VADemoMutateVisibility = (example, elementMap) => {
    const config = example.DOM_Manipulation.configuration || {};
    const modifiedElements = new Set();

    example.DOM_Manipulation.targets.forEach(target => {
      const element = elementMap.get(target.index);
      if (!element) return;

      element.classList.add('demo-preview-element');
      const mode = target.payload?.mode || 'dim';

      // Store original styles
      element.dataset.demoOriginalOpacity = element.style.opacity || '';
      element.dataset.demoOriginalFilter = element.style.filter || '';
      element.dataset.demoOriginalPointerEvents = element.style.pointerEvents || '';

      if (mode === 'dim') {
        element.style.opacity = String(config.opacity || 0.3);
        if (config.blur) {
          element.style.filter = `blur(${config.blur}px)`;
        }
        if (config.pointerEvents) {
          element.style.pointerEvents = config.pointerEvents;
        }
      }

      modifiedElements.add(element);
    });

    return {
      undo: () => {
        modifiedElements.forEach(element => {
          if (element.dataset.demoOriginalOpacity !== undefined) {
            if (element.dataset.demoOriginalOpacity === '') {
              element.style.removeProperty('opacity');
            } else {
              element.style.opacity = element.dataset.demoOriginalOpacity;
            }
            delete element.dataset.demoOriginalOpacity;
          }
          if (element.dataset.demoOriginalFilter !== undefined) {
            if (element.dataset.demoOriginalFilter === '') {
              element.style.removeProperty('filter');
            } else {
              element.style.filter = element.dataset.demoOriginalFilter;
            }
            delete element.dataset.demoOriginalFilter;
          }
          if (element.dataset.demoOriginalPointerEvents !== undefined) {
            if (element.dataset.demoOriginalPointerEvents === '') {
              element.style.removeProperty('pointer-events');
            } else {
              element.style.pointerEvents = element.dataset.demoOriginalPointerEvents;
            }
            delete element.dataset.demoOriginalPointerEvents;
          }
          element.classList.remove('demo-preview-element');
        });
        modifiedElements.clear();
      },
    };
  };
})();
