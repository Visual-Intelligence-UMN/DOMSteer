(() => {
  const STORAGE_KEY = 'va-demo-tensorflow-snapshots-v1';

  function isVisible(element) {
    if (!element) return false;
    const style = window.getComputedStyle(element);
    return style.display !== 'none' && style.visibility !== 'hidden' && element.offsetParent !== null;
  }

  function clean(text) {
    return (text || '').replace(/\s+/g, ' ').trim();
  }

  function labelFor(element) {
    const explicit =
      element.closest?.('label')?.textContent ||
      element.previousElementSibling?.textContent ||
      element.parentElement?.querySelector?.('label')?.textContent ||
      element.parentElement?.previousElementSibling?.textContent ||
      '';
    return clean(explicit).replace(/[:：]\s*$/, '');
  }

  function findMetric(name) {
    for (const element of Array.from(document.querySelectorAll('body *'))) {
      const text = clean(element.textContent);
      const match = text.match(new RegExp(`${name}\\s+([0-9.]+)`, 'i'));
      if (match) return match[1];
    }
    return null;
  }

  function getSelectedFeatures() {
    const selected = [];

    Array.from(document.querySelectorAll('.column.features input[type="checkbox"]')).forEach(input => {
      if (!isVisible(input) || !input.checked) return;
      const feature =
        input.getAttribute('data-feature') ||
        clean(input.closest?.('label')?.textContent) ||
        clean(input.parentElement?.textContent);
      if (feature) selected.push(feature);
    });

    if (selected.length) return selected;

    const likelyFeatures = Array.from(document.querySelectorAll('.column.features *'))
      .map(element => clean(element.textContent))
      .filter(Boolean)
      .filter(text => /^x[₁₂]|x1|x2|x²|x1x2|sin\(x/i.test(text));

    return [...new Set(likelyFeatures)];
  }

  function getHiddenLayerCount() {
    const text = Array.from(document.querySelectorAll('body *'))
      .map(element => clean(element.textContent))
      .find(value => /^\d+\s+HIDDEN LAYERS$/i.test(value || ''));
    if (!text) return null;
    const match = text.match(/^(\d+)/);
    return match ? match[1] : null;
  }

  function getNeuronsPerLayer() {
    const values = [];
    Array.from(document.querySelectorAll('body *')).forEach(element => {
      const text = clean(element.textContent);
      const match = text.match(/^(\d+)\s+neurons?$/i);
      if (match) values.push(match[1]);
    });
    return values;
  }

  function readSnapshotState() {
    const state = {
      savedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      dataset: null,
      features: [],
      hiddenLayerCount: getHiddenLayerCount(),
      neuronsPerLayer: getNeuronsPerLayer(),
      testLoss: findMetric('Test loss'),
      trainingLoss: findMetric('Training loss'),
      selects: [],
    };

    const activeDataset =
      document.querySelector('.dataset.selected') ||
      document.querySelector('.dataset.active') ||
      document.querySelector('.dataset[aria-pressed="true"]') ||
      Array.from(document.querySelectorAll('.dataset')).find(element => {
        const style = window.getComputedStyle(element);
        return isVisible(element) && (style.outlineStyle !== 'none' || parseFloat(style.borderWidth || '0') >= 2);
      });

    state.dataset =
      activeDataset?.getAttribute('title') ||
      activeDataset?.querySelector?.('[data-dataset]')?.getAttribute?.('data-dataset') ||
      null;

    Array.from(document.querySelectorAll('select')).forEach(select => {
      if (!isVisible(select)) return;
      const value = clean(select.selectedOptions?.[0]?.textContent || '');
      if (!value || value === '--') return;
      state.selects.push({
        label: labelFor(select) || `Select ${state.selects.length + 1}`,
        value,
      });
    });

    return state;
  }

  function loadSnapshots() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    } catch {
      return [];
    }
  }

  function saveSnapshots(snapshots) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshots));
  }

  function buildMetricPill(label, value) {
    const pill = document.createElement('div');
    pill.textContent = `${label}: ${value ?? '—'}`;
    pill.style.cssText = `
      padding: 3px 7px;
      border-radius: 999px;
      background: rgba(45, 212, 191, 0.1);
      border: 1px solid rgba(45, 212, 191, 0.2);
      color: rgba(45, 212, 191, 0.85);
      font-size: 10px;
      font-weight: 700;
    `;
    return pill;
  }

  window.VADemoInsertTensorflowSnapshotWidget = example => {
    const config = example?.DOM_Manipulation?.configuration || {};
    const titleText = config.title || 'Snapshot Widget';
    const noteText = config.note || 'Save a careful checkpoint before trying another round.';
    const maxSnapshots = Number(config.maxSnapshots || 8);

    const widget = document.createElement('div');
    widget.id = 'va-snapshot-widget';
    widget.className = 'demo-preview-element';
    widget.style.cssText = `
      position: fixed;
      right: 16px;
      top: 88px;
      width: 280px;
      max-height: 68vh;
      overflow: auto;
      padding: 10px;
      border-radius: 12px;
      background: rgba(30, 41, 40, 0.92);
      border: 1px solid rgba(45, 212, 191, 0.25);
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(45, 212, 191, 0.08);
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
      z-index: 999999;
      font-family: ui-sans-serif, system-ui, sans-serif;
    `;

    const header = document.createElement('div');
    header.style.cssText = `
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 6px;
    `;

    const title = document.createElement('div');
    title.textContent = titleText;
    title.style.cssText = `
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.06em;
      color: rgba(45, 212, 191, 0.9);
      text-transform: uppercase;
    `;

    const closeButton = document.createElement('button');
    closeButton.type = 'button';
    closeButton.textContent = '×';
    closeButton.style.cssText = `
      border: none;
      background: transparent;
      font-size: 16px;
      line-height: 1;
      cursor: pointer;
      color: rgba(45, 212, 191, 0.6);
    `;

    const saveButton = document.createElement('button');
    saveButton.type = 'button';
    saveButton.textContent = 'Record Snapshot';
    saveButton.style.cssText = `
      width: 100%;
      padding: 7px 10px;
      border-radius: 8px;
      border: 1px solid rgba(45, 212, 191, 0.3);
      background: rgba(45, 212, 191, 0.12);
      color: rgba(45, 212, 191, 0.95);
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
    `;

    const note = document.createElement('div');
    note.textContent = noteText;
    note.style.cssText = `
      margin: 5px 0 8px;
      font-size: 11px;
      line-height: 1.4;
      color: rgba(148, 163, 184, 0.8);
    `;

    const list = document.createElement('div');
    list.style.cssText = `
      display: flex;
      flex-direction: column;
      gap: 6px;
    `;

    const render = () => {
      const snapshots = loadSnapshots();
      list.innerHTML = '';

      if (!snapshots.length) {
        const empty = document.createElement('div');
        empty.textContent = 'No snapshots saved yet.';
        empty.style.cssText = `
          font-size: 11px;
          color: rgba(148, 163, 184, 0.6);
          padding: 4px 2px;
        `;
        list.appendChild(empty);
        return;
      }

      snapshots.forEach((snapshot, index) => {
        const card = document.createElement('div');
        card.style.cssText = `
          padding: 8px 10px;
          border-radius: 8px;
          background: rgba(45, 212, 191, 0.06);
          border: 1px solid rgba(45, 212, 191, 0.15);
        `;

        const top = document.createElement('div');
        top.style.cssText = `
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 8px;
          margin-bottom: 6px;
        `;

        const stamp = document.createElement('div');
        stamp.textContent = snapshot.savedAt;
        stamp.style.cssText = `
          font-size: 10px;
          font-weight: 700;
          color: rgba(45, 212, 191, 0.8);
        `;

        const removeButton = document.createElement('button');
        removeButton.type = 'button';
        removeButton.textContent = 'Remove';
        removeButton.style.cssText = `
          border: none;
          background: transparent;
          color: rgba(148, 163, 184, 0.5);
          font-size: 10px;
          cursor: pointer;
        `;
        removeButton.addEventListener('click', () => {
          const next = loadSnapshots();
          next.splice(index, 1);
          saveSnapshots(next);
          render();
        });

        const summary = document.createElement('div');
        const bits = [];
        if (snapshot.dataset) bits.push(`Dataset: ${snapshot.dataset}`);
        if (snapshot.hiddenLayerCount) bits.push(`${snapshot.hiddenLayerCount} hidden layers`);
        if (snapshot.neuronsPerLayer?.length) bits.push(`Neurons: ${snapshot.neuronsPerLayer.join(' / ')}`);
        summary.textContent = bits.join(' • ') || 'Snapshot saved';
        summary.style.cssText = `
          font-size: 11px;
          line-height: 1.4;
          color: rgba(226, 232, 240, 0.9);
          margin-bottom: 4px;
        `;

        const features = document.createElement('div');
        features.textContent = 'Features: X1, X2';
        features.style.cssText = `
          font-size: 10px;
          line-height: 1.4;
          color: rgba(148, 163, 184, 0.7);
          margin-bottom: 4px;
        `;

        const metrics = document.createElement('div');
        metrics.style.cssText = `
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        `;
        metrics.append(
          buildMetricPill('Test loss', snapshot.testLoss),
          buildMetricPill('Training loss', snapshot.trainingLoss),
        );

        top.append(stamp, removeButton);
        card.append(top, summary, features, metrics);
        list.appendChild(card);
      });
    };

    saveButton.addEventListener('click', () => {
      const snapshots = loadSnapshots();
      snapshots.unshift(readSnapshotState());
      saveSnapshots(snapshots.slice(0, maxSnapshots));
      render();
    });

    closeButton.addEventListener('click', () => {
      widget.remove();
      if (typeof example?.__vaOnEmpty === 'function') {
        example.__vaOnEmpty();
      }
    });

    header.append(title, closeButton);
    widget.append(header, saveButton, note, list);
    document.body.appendChild(widget);
    render();

    return {
      undo: () => {
        widget.remove();
        localStorage.removeItem(STORAGE_KEY);
      },
    };
  };
})();
