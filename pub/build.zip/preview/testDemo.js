/**
 * testDemo.js - Manual test harness for demo scripts
 *
 * This script provides manual testing functions for demo scripts.
 * It can be loaded in any page to trigger demos programmatically.
 *
 * Usage:
 * 1. Load demo scripts (demoRecomposeReorder.js, etc.)
 * 2. Load this script
 * 3. Call test functions in console:
 *    - window.testReorder()
 *    - window.testReorderCustom()
 *    - window.testLayout()
 *    - window.testRepresentation()
 *    - window.testInsertSearchBar()
 *    - window.testInsertChartDescribeButton()
 */

(() => {
  // Store active demo results for cleanup
  window.__activeDemos = window.__activeDemos || [];

  /**
   * Build element map from DOM elements with data-va-element-id attributes
   */
  function buildElementMap() {
    const map = new Map();
    document.querySelectorAll('[data-va-element-id]').forEach(element => {
      const id = element.getAttribute('data-va-element-id');
      const match = id.match(/va-auto-id-(\d+)/);
      if (match) {
        const index = parseInt(match[1], 10);
        map.set(index, element);
      }
    });
    console.log('[testDemo] Built element map with', map.size, 'elements');
    return map;
  }

  /**
   * Test reorder demo with default reverse order
   */
  window.testReorder = () => {
    console.log('[testDemo] === Testing Reorder (Reverse) ===');
    const elementMap = buildElementMap();
    const example = {
      domSubtype: 'recompose.reorder',
      DOM_Manipulation: {
        targets: [{ index: 8 }, { index: 12 }, { index: 16 }, { index: 20 }, { index: 24 }, { index: 28 }],
        configuration: {
          policy: 'frequency',
          direction: 'top',
          animated: true,
        },
      },
    };

    if (!window.VADemoRecomposeReorder) {
      console.error('[testDemo] VADemoRecomposeReorder not found. Load demoRecomposeReorder.js first.');
      return null;
    }

    const result = window.VADemoRecomposeReorder(example, elementMap);
    window.__activeDemos.push(result);
    console.log('[testDemo] Reorder demo initialized (reverse order)');
    return result;
  };

  /**
   * Test reorder demo with custom order
   */
  window.testReorderCustom = () => {
    console.log('[testDemo] === Testing Reorder (Custom Order) ===');
    const elementMap = buildElementMap();
    const example = {
      domSubtype: 'recompose.reorder',
      DOM_Manipulation: {
        targets: [{ index: 8 }, { index: 12 }, { index: 16 }, { index: 20 }, { index: 24 }, { index: 28 }],
        configuration: {
          policy: 'custom',
          signal: 'click',
          window: 'session',
          direction: 'top',
          customOrderUiDescriptions: [
            'Year Field',
            'Name Field',
            'Origin Field',
            'Acceleration Field',
            'Cylinder Field',
            'Displacement Field',
          ],
        },
      },
    };

    if (!window.VADemoRecomposeReorder) {
      console.error('[testDemo] VADemoRecomposeReorder not found. Load demoRecomposeReorder.js first.');
      return null;
    }

    const result = window.VADemoRecomposeReorder(example, elementMap);
    window.__activeDemos.push(result);
    console.log('[testDemo] Reorder demo initialized (custom order: [20, 12, 16, 24, 8, 28])');
    return result;
  };

  /**
   * Test layout demo (list to grid transformation)
   */
  window.testLayout = () => {
    console.log('[testDemo] === Testing Layout ===');
    const elementMap = buildElementMap();
    const example = {
      domSubtype: 'recompose.layout',
      DOM_Manipulation: {
        targets: [{ index: 8 }],
        configuration: {
          from: 'list',
          to: 'grid',
          columns: 2,
          gap: 8,
        },
      },
    };

    if (!window.VADemoRecomposeLayout) {
      console.error('[testDemo] VADemoRecomposeLayout not found. Load demoRecomposeLayout.js first.');
      return null;
    }

    const result = window.VADemoRecomposeLayout(example, elementMap);
    window.__activeDemos.push(result);
    console.log('[testDemo] Layout demo initialized (list → grid)');
    return result;
  };

  /**
   * Test representation demo (dropdown to button-group transformation)
   */
  window.testRepresentation = () => {
    console.log('[testDemo] === Testing Representation ===');
    const elementMap = buildElementMap();
    const example = {
      domSubtype: 'mutate.representation',
      DOM_Manipulation: {
        targets: [{ index: 69 }],
        configuration: {
          from: 'dropdown',
          to: 'button-group',
          spacing: 8,
        },
      },
    };

    if (!window.VADemoMutateRepresentation) {
      console.error('[testDemo] VADemoMutateRepresentation not found. Load demoMutateRepresentation.js first.');
      return null;
    }

    const result = window.VADemoMutateRepresentation(example, elementMap);
    window.__activeDemos.push(result);
    console.log('[testDemo] Representation demo initialized (dropdown → button-group)');
    return result;
  };

  /**
   * Test hardcoded Data Voyager field-search prototype
   */
  window.testInsertSearchBar = () => {
    console.log('[testDemo] === Testing Insert Search Bar ===');

    if (!window.VADemoInsertSearchBar) {
      console.error('[testDemo] VADemoInsertSearchBar not found. Load demoInsertSearchBar.js first.');
      return null;
    }

    const result = window.VADemoInsertSearchBar();
    window.__activeDemos.push(result);
    console.log('[testDemo] Insert search bar demo initialized');
    return result;
  };

  /**
   * Test Data Voyager chart describe button prototype
   */
  window.testInsertChartDescribeButton = async () => {
    console.log('[testDemo] === Testing Insert Chart Describe Button ===');

    if (!window.VADemoInsertChartDescribeButton) {
      console.error(
        '[testDemo] VADemoInsertChartDescribeButton not found. Load demoInsertChartDescribeButton.js first.',
      );
      return null;
    }

    const result = await window.VADemoInsertChartDescribeButton();
    window.__activeDemos.push(result);
    console.log('[testDemo] Insert chart describe button demo initialized');
    return result;
  };

  /**
   * Undo all active demos
   */
  window.undoAllDemos = () => {
    console.log('[testDemo] === Undoing All Demos ===');
    let count = 0;
    window.__activeDemos.forEach(demo => {
      if (demo && demo.undo) {
        demo.undo();
        count++;
      }
    });
    window.__activeDemos = [];
    console.log(`[testDemo] Undone ${count} demos`);
  };

  /**
   * Clean up all demo elements (emergency cleanup)
   */
  window.cleanupAllDemos = () => {
    console.log('[testDemo] === Emergency Cleanup ===');
    document.querySelectorAll('.demo-preview-element').forEach(el => el.remove());
    console.log('[testDemo] Removed all .demo-preview-element nodes');
  };

  // Log available functions
  console.log('[testDemo] Test functions loaded:');
  console.log('  - window.testReorder() - Reverse order demo');
  console.log('  - window.testReorderCustom() - Custom order demo [20,12,16,24,8,28]');
  console.log('  - window.testLayout() - List to grid layout demo');
  console.log('  - window.testRepresentation() - Dropdown to button-group demo');
  console.log('  - window.testInsertSearchBar() - Insert search bar demo');
  console.log('  - window.testInsertChartDescribeButton() - Insert chart describe button demo');
  console.log('  - window.undoAllDemos() - Undo all active demos');
  console.log('  - window.cleanupAllDemos() - Emergency cleanup of demo elements');
})();
