(() => {
  // Shared entrance animation for all insert.inline_control scripts
  function ensureControlAnimation() {
    if (document.getElementById('demo-control-animation')) return;
    const el = document.createElement('style');
    el.id = 'demo-control-animation';
    el.className = 'demo-preview-element';
    el.textContent = `
      @keyframes demo-control-backdrop-in {
        0% { opacity: 0; }
        100% { opacity: 1; }
      }
      @keyframes demo-control-glow {
        0%, 100% {
          box-shadow: 0 0 4px 1px rgba(20, 184, 166, 0.28),
                      0 0 12px 4px rgba(20, 184, 166, 0.1);
          outline-color: rgba(20, 184, 166, 0.6);
        }
        50% {
          box-shadow: 0 0 8px 3px rgba(20, 184, 166, 0.45),
                      0 0 20px 8px rgba(20, 184, 166, 0.18);
          outline-color: rgba(20, 184, 166, 1);
        }
      }
    `;
    document.head.appendChild(el);
  }

  /**
   * Brief spotlight focus: dims the page, zooms and glows the control,
   * then fades out after ~1.8s — leaving the control in place.
   */
  function applyControlEntrance(el) {
    // --- Backdrop ---
    const backdrop = document.createElement('div');
    backdrop.className = 'demo-preview-element';
    backdrop.style.cssText = `
      position: fixed; inset: 0;
      background: rgba(0, 0, 0, 0.3);
      z-index: 9998;
      pointer-events: none;
      animation: demo-control-backdrop-in 0.3s ease-out forwards;
    `;
    document.body.appendChild(backdrop);

    // --- Lift control above backdrop ---
    const origPosition = el.style.position || '';
    const origZIndex = el.style.zIndex || '';
    const origOutline = el.style.outline || '';
    const origOutlineOffset = el.style.outlineOffset || '';
    const origBorderRadius = el.style.borderRadius || '';
    const origTransform = el.style.transform || '';
    const origBg = el.style.backgroundColor || '';

    el.style.position = 'relative';
    el.style.zIndex = '9999';
    el.style.outline = '2.5px solid rgba(20, 184, 166, 0.9)';
    el.style.outlineOffset = '4px';
    el.style.borderRadius = el.style.borderRadius || '6px';
    el.style.transform = 'scale(1.06)';
    el.style.backgroundColor = 'rgba(240, 253, 250, 0.96)';
    el.style.transition =
      'transform 0.4s cubic-bezier(0.22, 1, 0.36, 1), background-color 0.4s ease, box-shadow 0.3s ease';
    el.style.animation = 'demo-control-glow 1s ease-in-out infinite';

    // --- Fade out after brief spotlight ---
    setTimeout(() => {
      // Animate control back
      el.style.transform = origTransform || 'scale(1)';
      el.style.backgroundColor = origBg || '';
      el.style.animation = 'none';
      el.style.outline = origOutline;
      el.style.outlineOffset = origOutlineOffset;
      el.style.boxShadow = '';

      // Fade backdrop
      backdrop.style.transition = 'opacity 0.4s ease-in';
      backdrop.style.opacity = '0';

      // Full cleanup after fade
      setTimeout(() => {
        el.style.position = origPosition;
        el.style.zIndex = origZIndex;
        el.style.borderRadius = origBorderRadius;
        el.style.transition = 'background 0.2s, box-shadow 0.2s, border-color 0.2s';
        backdrop.remove();
      }, 420);
    }, 1800);
  }

  window.VADemoInsertInlineControl = (example, elementMap) => {
    const target = example.DOM_Manipulation.targets[0];
    if (!target) return { undo: () => {} };

    const element = elementMap.get(target.index);
    if (!element) return { undo: () => {} };

    const config = example.DOM_Manipulation.configuration || {};
    const payload = config.payload || {};
    const controlType = payload.controlType || 'button';
    const action = payload.action;
    const assistanceText = String(example?.assistance || '')
      .trim()
      .toLowerCase();
    const searchLabel = String(payload.label || '')
      .trim()
      .toLowerCase();
    const isSearchLike =
      controlType === 'input' &&
      (action?.type === 'search_filter_fields' ||
        action?.type === 'filterFields' ||
        searchLabel.includes('search') ||
        searchLabel.includes('find'));

    if (isSearchLike && typeof window.VADemoInsertSearchBar === 'function') {
      return window.VADemoInsertSearchBar(example, elementMap);
    }

    const buttonLabel = String(payload.label || '')
      .trim()
      .toLowerCase();
    const actionValue = String(action?.value || '')
      .trim()
      .toLowerCase();
    const isChartDescribeLike =
      controlType === 'button' &&
      (buttonLabel.includes('describe chart') ||
        assistanceText.includes('insert chart describe button') ||
        assistanceText.includes('describe button') ||
        actionValue.includes('describe chart'));

    if (isChartDescribeLike && typeof window.VADemoInsertChartDescribeButton === 'function') {
      return window.VADemoInsertChartDescribeButton(example, elementMap);
    }

    const isTxgnnZoomLike =
      controlType === 'button' &&
      (action?.type === 'zoom_controls' ||
        buttonLabel.includes('zoom') ||
        assistanceText.includes('zoom in') ||
        assistanceText.includes('zoom out'));

    if (isTxgnnZoomLike && typeof window.VADemoInsertTxgnnZoom === 'function') {
      return window.VADemoInsertTxgnnZoom(example, elementMap);
    }

    const isSearchInput =
      controlType === 'input' && action && (action.type === 'filterFields' || action.type === 'search_filter_fields');
    ensureControlAnimation();
    const control = document.createElement(controlType === 'input' ? 'input' : 'button');
    control.className = 'demo-preview-element';
    control.dataset.demoInlineControlType = controlType;

    if (controlType === 'input') {
      control.type = 'text';
      control.placeholder = payload.label || 'Search';
      control.setAttribute('aria-label', payload.label || 'Search');
      control.style.cssText = `
        display: inline-block;
        width: 180px;
        margin: 4px 8px;
        padding: 4px 8px;
        background: white;
        color: #111827;
        border: 1px solid rgba(20, 184, 166, 0.45);
        border-radius: 8px;
        font-size: 12px;
        box-sizing: border-box;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      `;
    } else {
      control.textContent = payload.label || 'Control';
      control.style.cssText = `
        display: inline-block;
        width: auto;
        max-width: fit-content;
        flex: none;
        flex-shrink: 0;
        margin: 4px 8px;
        padding: 2px 8px;
        background: linear-gradient(135deg, rgba(45, 212, 191, 0.46) 0%, rgba(13, 148, 136, 0.4) 100%);
        color: #115e59;
        border: 1px solid rgba(20, 184, 166, 0.32);
        border-radius: 8px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.2s;
        white-space: nowrap;
        box-sizing: border-box;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
      `;

      control.addEventListener('mouseenter', () => {
        control.style.background =
          'linear-gradient(135deg, rgba(45, 212, 191, 0.58) 0%, rgba(13, 148, 136, 0.5) 100%)';
      });
      control.addEventListener('mouseleave', () => {
        control.style.background =
          'linear-gradient(135deg, rgba(45, 212, 191, 0.46) 0%, rgba(13, 148, 136, 0.4) 100%)';
      });
    }

    applyControlEntrance(control);

    const modifiedElements = new Map();
    const reorderedContainers = new Map();
    let inlineRow = null;
    let originalParent = null;
    let originalNextSibling = null;

    const isHeadingLikeAnchor = anchorElement => {
      if (!anchorElement) return false;
      if (/^H[1-6]$/.test(anchorElement.tagName || '')) return true;
      return anchorElement.getAttribute && anchorElement.getAttribute('role') === 'heading';
    };

    const getSiblingCandidates = node => {
      const parent = node?.parentElement;
      if (!parent || !Array.isArray(parent.children)) return [];
      return parent.children.filter(child => child !== node && child !== control);
    };

    const resolveFieldScope = candidate => {
      if (!candidate) return null;
      const explicitItems = Array.from(candidate.querySelectorAll?.('[data-va-field-item="true"]') || []);
      if (explicitItems.length > 0) {
        return { scopeElement: candidate, items: explicitItems };
      }
      return null;
    };

    const restoreSearchEffects = () => {
      modifiedElements.forEach((original, node) => {
        node.style.background = original.background;
        node.style.outline = original.outline;
        node.style.opacity = original.opacity;
      });
      modifiedElements.clear();

      reorderedContainers.forEach((originalOrder, container) => {
        originalOrder.forEach(child => {
          if (child.parentNode === container) {
            container.appendChild(child);
          }
        });
      });
      reorderedContainers.clear();
    };

    const collectSearchItems = anchorElement => {
      const explicitScope = action && elementMap.get(action.targetIndex);
      const siblingCandidates = getSiblingCandidates(anchorElement);
      const candidateScopes = [explicitScope, ...siblingCandidates, anchorElement.parentElement, anchorElement].filter(
        Boolean,
      );

      for (const candidate of candidateScopes) {
        const resolved = resolveFieldScope(candidate);
        if (resolved) {
          return resolved;
        }
      }

      const scopeElement = explicitScope || anchorElement.parentElement || anchorElement;
      const siblingItems = Array.from(scopeElement.children || []).filter(child => child !== control);
      return { scopeElement, items: siblingItems };
    };

    const applySearchBehavior = rawQuery => {
      const query = String(rawQuery || '')
        .trim()
        .toLowerCase();
      const { scopeElement, items } = collectSearchItems(element);

      if (!reorderedContainers.has(scopeElement)) {
        reorderedContainers.set(scopeElement, Array.from(scopeElement.children || []));
      }

      const matches = [];
      const nonMatches = [];

      items.forEach(item => {
        if (!modifiedElements.has(item)) {
          modifiedElements.set(item, {
            background: item.style.background || '',
            outline: item.style.outline || '',
            opacity: item.style.opacity || '',
          });
        }

        const text = (item.textContent || '').toLowerCase();
        const isMatch = query.length === 0 || text.includes(query);

        if (query.length === 0) {
          item.style.background = modifiedElements.get(item).background;
          item.style.outline = modifiedElements.get(item).outline;
          item.style.opacity = modifiedElements.get(item).opacity;
        } else if (isMatch) {
          item.style.background = 'rgba(20, 184, 166, 0.12)';
          item.style.outline = '2px solid rgba(20, 184, 166, 0.72)';
          item.style.opacity = '1';
        } else {
          item.style.background = modifiedElements.get(item).background;
          item.style.outline = modifiedElements.get(item).outline;
          item.style.opacity = '0.45';
        }

        (isMatch ? matches : nonMatches).push(item);
      });

      if (query.length === 0) {
        restoreSearchEffects();
        return;
      }

      const ordered = matches.concat(nonMatches);
      ordered.forEach(item => {
        if (item.parentNode === scopeElement) {
          scopeElement.appendChild(item);
        }
      });
    };

    // Add click handler for button with fill action
    if (controlType === 'button' && action && action.type === 'fill') {
      control.addEventListener('click', async () => {
        console.log('[InsertInlineControl] Button clicked, executing fill action:', action);
        const targetElement = elementMap.get(action.targetIndex);
        if (!targetElement) {
          console.warn('[InsertInlineControl] Target element not found for index:', action.targetIndex);
          return;
        }

        // Typewriter effect helper
        const typewriterFill = async (element, text, isContentEditable = false) => {
          // Clear current value
          if (isContentEditable) {
            element.textContent = '';
          } else {
            element.value = '';
          }

          // Type each character with delay
          for (let i = 0; i < text.length; i++) {
            await new Promise(resolve => setTimeout(resolve, 15)); // 15ms per character
            if (isContentEditable) {
              element.textContent += text[i];
            } else {
              element.value += text[i];
            }
            // Dispatch input event for each character
            element.dispatchEvent(new Event('input', { bubbles: true }));
          }

          // Dispatch final change event
          element.dispatchEvent(new Event('change', { bubbles: true }));
        };

        // Fill the target element with typewriter effect
        if (targetElement.tagName === 'INPUT' || targetElement.tagName === 'TEXTAREA') {
          await typewriterFill(targetElement, action.value, false);
          console.log('[InsertInlineControl] Filled element with typewriter effect:', action.value);
        } else if (targetElement.isContentEditable || targetElement.getAttribute('contenteditable') === 'true') {
          await typewriterFill(targetElement, action.value, true);
          console.log('[InsertInlineControl] Filled contenteditable element with typewriter effect:', action.value);
        } else {
          console.warn('[InsertInlineControl] Target element is not a fillable element:', targetElement.tagName);
        }
      });
    }

    if (isSearchInput) {
      control.addEventListener('input', event => {
        applySearchBehavior(event.target.value);
      });
    }

    const position = config.position || 'after';
    const shouldInlineWithAnchor = isSearchInput && isHeadingLikeAnchor(element) && element.parentNode;

    if (shouldInlineWithAnchor) {
      originalParent = element.parentNode;
      originalNextSibling = element.nextSibling;

      inlineRow = document.createElement('div');
      inlineRow.style.cssText = `
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        width: 100%;
        margin: 0 0 6px;
      `;

      originalParent.insertBefore(inlineRow, element);
      inlineRow.appendChild(element);
      inlineRow.appendChild(control);

      control.style.margin = '0';
      control.style.flex = '0 0 180px';
      control.style.width = '180px';
    } else {
      if (position === 'after') {
        element.parentNode?.insertBefore(control, element.nextSibling);
      } else {
        element.parentNode?.insertBefore(control, element);
      }
    }

    return {
      undo: () => {
        restoreSearchEffects();
        if (inlineRow && originalParent) {
          originalParent.insertBefore(element, originalNextSibling);
          inlineRow.remove();
        }
        control.remove();
      },
    };
  };
})();
