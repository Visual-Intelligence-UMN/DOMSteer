(() => {
  /**
   * VADemoRecomposeReorder - Physically reorders DOM elements by extracting and reinserting
   *
   * Configuration options:
   * - direction: 'top' | 'bottom' - Where to insert the reordered group (default: 'top')
   * - customOrderUiDescriptions: string[] - Array of uiDescription values specifying custom order
   *   Example: ["Year Field", "Name Field", "Origin Field"] means those targets become 1st/2nd/3rd
   * - customOrder: number[] - Legacy fallback order by index
   * - policy: string - Ordering policy ('frequency', 'custom', etc.)
   * - layout: 'row' | 'column' | 'wrap' - How to display reordered elements (default: 'column')
   *
   * New approach: Extract all elements and reinsert in a wrapper container (like group)
   * This handles different parents naturally and makes the order visually clear
   */
  window.VADemoRecomposeReorder = (example, elementMap) => {
    console.log('[RecomposeReorder] Called with:', { example, elementMap });
    const overlays = new Set();
    const modifiedElements = new Set();
    const originalPositions = new Map();

    // Collect all target elements from example.DOM_Manipulation.targets
    const elements = example.DOM_Manipulation.targets
      .map((target, targetOrder) => {
        const element = elementMap.get(target.index);
        if (!element) {
          console.warn('[RecomposeReorder] No element found for index:', target.index);
          return null;
        }
        return { element, index: target.index, targetOrder };
      })
      .filter(Boolean);

    if (elements.length === 0) {
      console.warn('[RecomposeReorder] No elements found to reorder');
      return { undo: () => {} };
    }

    // Get configuration
    const config = example.DOM_Manipulation.configuration || {};
    const customOrderUiDescriptions = config.customOrderUiDescriptions;
    const customOrder = config.customOrder;
    const direction = config.direction || 'top';
    const layout = config.layout || 'column';

    console.log('[RecomposeReorder] Configuration:', {
      customOrderUiDescriptions,
      customOrder,
      direction,
      layout,
      policy: config.policy,
    });

    // Check if frequency policy is enabled - delegate to frequency script
    if (config.policy === 'frequency') {
      console.log('[RecomposeReorder] Frequency policy detected, delegating...');
      if (typeof window.VADemoRecomposeReorderFrequency === 'function') {
        return window.VADemoRecomposeReorderFrequency(example, elementMap);
      } else {
        console.error('[RecomposeReorder] Frequency script not loaded!');
        return { undo: () => {} };
      }
    }

    // Log original element order
    console.log(
      '[RecomposeReorder] Original element order:',
      elements.map(e => ({ index: e.index, text: e.element.textContent?.slice(0, 20) })),
    );

    // Store original positions for ALL elements
    elements.forEach(({ element }) => {
      const parent = element.parentElement;
      const originalIndex = parent ? Array.from(parent.children).indexOf(element) : -1;
      originalPositions.set(element, { parent, originalIndex });
    });

    // Determine ordering
    let orderedElements;
    if (customOrderUiDescriptions && Array.isArray(customOrderUiDescriptions)) {
      console.log('[RecomposeReorder] Using customOrderUiDescriptions:', customOrderUiDescriptions);
      const orderMap = new Map();
      customOrderUiDescriptions.forEach((uiDescription, pos) => {
        orderMap.set(uiDescription, pos);
      });

      orderedElements = [...elements].sort((a, b) => {
        const descriptionA = example.DOM_Manipulation.targets[a.targetOrder]?.uiDescription;
        const descriptionB = example.DOM_Manipulation.targets[b.targetOrder]?.uiDescription;
        const posA = orderMap.get(descriptionA) ?? 999;
        const posB = orderMap.get(descriptionB) ?? 999;
        return posA - posB;
      });
    } else if (customOrder && Array.isArray(customOrder)) {
      console.log('[RecomposeReorder] Using legacy customOrder:', customOrder);
      // Create ordering map: index → position in customOrder
      const orderMap = new Map();
      customOrder.forEach((index, pos) => {
        orderMap.set(index, pos);
      });

      // Sort elements by their position in customOrder
      orderedElements = [...elements].sort((a, b) => {
        const posA = orderMap.get(a.index) ?? 999;
        const posB = orderMap.get(b.index) ?? 999;
        return posA - posB;
      });
    } else {
      console.log('[RecomposeReorder] Using reverse order (default)');
      // Default: reverse order
      orderedElements = [...elements].reverse();
    }

    // Log final ordered sequence
    console.log(
      '[RecomposeReorder] New element order:',
      orderedElements.map((e, idx) => ({
        position: idx + 1,
        index: e.index,
        text: e.element.textContent?.slice(0, 20),
      })),
    );

    // Create wrapper container for reordered elements
    const wrapper = document.createElement('div');
    wrapper.className = 'demo-preview-element';

    const gap = 8;
    const padding = 12;

    let layoutStyles = '';
    switch (layout) {
      case 'row':
        layoutStyles = 'flex-direction: row; flex-wrap: nowrap;';
        break;
      case 'column':
        layoutStyles = 'flex-direction: column;';
        break;
      case 'wrap':
        layoutStyles = 'flex-direction: row; flex-wrap: wrap;';
        break;
      default:
        layoutStyles = 'flex-direction: column;';
    }

    wrapper.style.cssText = `
      display: flex;
      ${layoutStyles}
      gap: ${gap}px;
      padding: ${padding}px;
      border: 1px solid rgba(251, 191, 36, 0.35);
      border-radius: 12px;
      background: linear-gradient(135deg, rgba(251, 191, 36, 0.15) 0%, rgba(245, 158, 11, 0.1) 100%);
      backdrop-filter: blur(16px) saturate(160%);
      -webkit-backdrop-filter: blur(16px) saturate(160%);
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1),
                  0 2px 8px rgba(0, 0, 0, 0.06),
                  inset 0 1px 0 rgba(255, 255, 255, 0.4);
      position: relative;
    `;

    // No title or count badges - keep it clean

    // Determine insertion point (use first element's position)
    const firstElement = elements[0].element;
    const insertionPoint = firstElement.parentElement;

    // Insert wrapper at first element's position
    insertionPoint.insertBefore(wrapper, firstElement);
    overlays.add(wrapper);

    console.log('[RecomposeReorder] Inserting', orderedElements.length, 'elements in new order with animation');

    // Move elements into wrapper in the new order with animation
    orderedElements.forEach(({ element, index }, idx) => {
      // Store original styles
      element.dataset.demoOriginalOutline = element.style.outline || '';
      element.dataset.demoOriginalTransition = element.style.transition || '';
      element.dataset.demoOriginalOpacity = element.style.opacity || '';
      element.dataset.demoOriginalTransform = element.style.transform || '';

      // Start with element invisible and slightly shifted
      element.style.opacity = '0';
      element.style.transform = 'translateY(-10px)';
      element.style.transition = 'all 0.4s ease-out';

      // Move element into wrapper
      wrapper.appendChild(element);
      modifiedElements.add(element);

      // Animate in with delay for each element
      setTimeout(() => {
        element.style.opacity = '1';
        element.style.transform = 'translateY(0)';
        element.style.outline = '3px solid rgba(251, 191, 36, 0.8)';
      }, idx * 100); // 100ms delay between each element

      console.log(`  [${idx + 1}] Inserted element ${index} in position ${idx + 1} (will animate in ${idx * 100}ms)`);
    });

    console.log('[RecomposeReorder] Reordering complete:', {
      totalElements: elements.length,
      policy: config.policy,
      direction: direction,
      layout: layout,
      customOrderUiDescriptions: customOrderUiDescriptions || 'none',
      customOrder: customOrder || 'none (reversed)',
    });

    return {
      undo: () => {
        console.log('[RecomposeReorder] undo() called');

        // Restore elements to original positions
        modifiedElements.forEach(element => {
          // Restore original styles
          if (element.dataset.demoOriginalOutline !== undefined) {
            element.style.outline = element.dataset.demoOriginalOutline;
            delete element.dataset.demoOriginalOutline;
          }
          if (element.dataset.demoOriginalTransition !== undefined) {
            element.style.transition = element.dataset.demoOriginalTransition;
            delete element.dataset.demoOriginalTransition;
          }
          if (element.dataset.demoOriginalOpacity !== undefined) {
            if (element.dataset.demoOriginalOpacity === '') {
              element.style.removeProperty('opacity');
            } else {
              element.style.opacity = element.dataset.demoOriginalOpacity;
            }
            delete element.dataset.demoOriginalOpacity;
          }
          if (element.dataset.demoOriginalTransform !== undefined) {
            if (element.dataset.demoOriginalTransform === '') {
              element.style.removeProperty('transform');
            } else {
              element.style.transform = element.dataset.demoOriginalTransform;
            }
            delete element.dataset.demoOriginalTransform;
          }
        });

        const restoreQueue = [...modifiedElements]
          .map(element => ({ element, original: originalPositions.get(element) }))
          .filter(item => item.original?.parent)
          .sort((a, b) => (a.original.originalIndex ?? 0) - (b.original.originalIndex ?? 0));

        restoreQueue.forEach(({ element, original }) => {
          const parent = original.parent;
          const insertionIndex = original.originalIndex ?? parent.children.length;
          const referenceNode = parent.children[insertionIndex] ?? null;
          parent.insertBefore(element, referenceNode);
        });

        originalPositions.clear();
        modifiedElements.clear();

        // Remove all overlay elements (wrapper, badges, message box)
        overlays.forEach(node => node.remove());
        overlays.clear();

        console.log('[RecomposeReorder] Cleanup complete');
      },
    };
  };
})();
