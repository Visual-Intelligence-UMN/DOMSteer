(() => {
  window.VADemoMutateHighlight = (example, elementMap) => {
    console.log('[MutateHighlight] Called with:', { example, elementMap });
    const config = example.DOM_Manipulation.configuration || {};
    if (config.partialRegion && typeof window.VADemoMutatePartialHighlight === 'function') {
      return window.VADemoMutatePartialHighlight(example, elementMap);
    }
    const showMessage = config.showMessage !== false;
    const style = config.style || 'pulse';
    const overlays = new Set();
    const modifiedElements = new Set();
    const messages = [];
    let timeoutId;
    let cleanedUp = false;

    // Add keyframe animations
    if (!document.getElementById('demo-highlight-focus-animation')) {
      const styleEl = document.createElement('style');
      styleEl.id = 'demo-highlight-focus-animation';
      styleEl.className = 'demo-preview-element';
      styleEl.textContent = `
        @keyframes demo-focus-zoom-in {
          0% {
            transform: scale(1);
            box-shadow: 0 0 0 3px rgba(251, 191, 36, 0.72),
                        0 0 0 8px rgba(251, 191, 36, 0.12),
                        0 0 10px 4px rgba(251, 191, 36, 0.12);
          }
          45% {
            transform: scale(1.045);
            box-shadow: 0 0 0 3px rgba(251, 191, 36, 1),
                        0 0 0 10px rgba(251, 191, 36, 0.3),
                        0 0 18px 8px rgba(251, 191, 36, 0.32),
                        0 0 34px 14px rgba(251, 191, 36, 0.16);
          }
          100% {
            transform: scale(1.04);
            box-shadow: 0 0 0 3px rgba(251, 191, 36, 0.92),
                        0 0 0 8px rgba(251, 191, 36, 0.22),
                        0 0 14px 7px rgba(251, 191, 36, 0.28),
                        0 0 28px 14px rgba(251, 191, 36, 0.14);
          }
        }
        @keyframes demo-focus-ring-pulse {
          0%, 100% {
            box-shadow: 0 0 0 3px rgba(251, 191, 36, 0.82),
                        0 0 0 8px rgba(251, 191, 36, 0.14),
                        0 0 10px 4px rgba(251, 191, 36, 0.16);
          }
          50% {
            box-shadow: 0 0 0 3px rgba(251, 191, 36, 1),
                        0 0 0 11px rgba(251, 191, 36, 0.34),
                        0 0 18px 8px rgba(251, 191, 36, 0.34),
                        0 0 34px 14px rgba(251, 191, 36, 0.16);
          }
        }
        @keyframes demo-backdrop-fade-in {
          0% { opacity: 0; }
          100% { opacity: 1; }
        }
      `;
      document.head.appendChild(styleEl);
      overlays.add(styleEl);
    }

    // Collect target rects first for backdrop cutout
    const targetRects = [];
    example.DOM_Manipulation.targets.forEach(target => {
      const el = elementMap.get(target.index);
      if (el) targetRects.push(el.getBoundingClientRect());
    });

    // --- Spotlight backdrop with cutout holes for target elements ---
    // --- Spotlight: one cutout div per target using box-shadow to darken everything else ---
    const pad = 10;
    const maxDim = Math.max(window.innerWidth, window.innerHeight);
    const backdrop = document.createElement('div');
    backdrop.className = 'demo-preview-element';
    // Compute bounding box across ALL target rects for the spotlight hole
    const r = targetRects.reduce(
      (acc, rect) => ({
        left: Math.min(acc.left, rect.left),
        top: Math.min(acc.top, rect.top),
        right: Math.max(acc.right, rect.right),
        bottom: Math.max(acc.bottom, rect.bottom),
      }),
      { left: Infinity, top: Infinity, right: 0, bottom: 0 },
    );
    r.width = r.right - r.left;
    r.height = r.bottom - r.top;
    backdrop.style.cssText = `
      position: fixed;
      left: ${r.left - pad}px;
      top: ${r.top - pad}px;
      width: ${r.width + pad * 2}px;
      height: ${r.height + pad * 2}px;
      border-radius: 4px;
      z-index: 9998;
      pointer-events: auto;
      box-shadow: 0 0 0 ${maxDim * 2}px rgba(0, 0, 0, 0.45);
      animation: demo-backdrop-fade-in 0.4s ease-out forwards;
    `;

    backdrop.addEventListener('click', () => {
      clearTimeout(timeoutId);
      cleanup();
    });
    document.body.appendChild(backdrop);
    overlays.add(backdrop);

    // Process targets and collect messages
    example.DOM_Manipulation.targets.forEach((target, index) => {
      const element = elementMap.get(target.index);
      if (!element) {
        console.warn('[MutateHighlight] No element found for index:', target.index);
        return;
      }

      // Store original styles
      element.classList.add('demo-preview-element');
      element.dataset.demoOriginalPosition = element.style.position || '';
      element.dataset.demoOriginalZIndex = element.style.zIndex || '';
      element.dataset.demoOriginalOutline = element.style.outline || '';
      element.dataset.demoOriginalOutlineOffset = element.style.outlineOffset || '';
      element.dataset.demoOriginalBorderRadius = element.style.borderRadius || '';
      element.dataset.demoOriginalBoxShadow = element.style.boxShadow || '';
      element.dataset.demoOriginalAnimation = element.style.animation || '';
      element.dataset.demoOriginalBackground = element.style.backgroundColor || '';
      element.dataset.demoOriginalTransform = element.style.transform || '';
      element.dataset.demoOriginalTransition = element.style.transition || '';
      modifiedElements.add(element);

      // Don't change position/z-index — element may be in a stacking context
      // The box-shadow cutout on the backdrop handles visibility

      // Add a clear gold ring so the highlighted target reads as intentionally selected.
      element.style.outline = '3px solid rgba(251, 191, 36, 0.95)';
      element.style.outlineOffset = '6px';
      element.style.boxShadow = '0 0 0 3px rgba(251, 191, 36, 0.88), 0 0 0 8px rgba(251, 191, 36, 0.18)';

      // Smooth zoom-in, then keep the outer gold ring shimmering.
      element.style.animation =
        'demo-focus-zoom-in 0.6s cubic-bezier(0.22, 1, 0.36, 1) forwards, demo-focus-ring-pulse 1.7s ease-in-out 0.6s infinite';

      // Collect message if present
      if (target.payload?.message) {
        const prefix = example.DOM_Manipulation.targets.length > 1 ? `${index + 1}. ` : '';
        messages.push(`${prefix}${target.payload.message}`);
      }
    });

    // Define cleanup function — smooth exit animation (guarded against double invocation)
    const cleanup = () => {
      if (cleanedUp) return;
      cleanedUp = true;
      console.log('[MutateHighlight] cleanup() called');

      // Animate elements back to normal
      modifiedElements.forEach(element => {
        element.style.transition = 'opacity 0.2s ease-in';
      });

      // Fade out backdrop
      if (backdrop) {
        backdrop.style.transition = 'opacity 0.4s ease-in';
        backdrop.style.opacity = '0';
      }

      // Fade out message box
      if (messageBox) {
        messageBox.style.transition = 'opacity 0.3s ease-in';
        messageBox.style.opacity = '0';
      }

      // After exit animation, fully restore original styles
      setTimeout(() => {
        modifiedElements.forEach(element => {
          const restore = (prop, dataset) => {
            if (element.dataset[dataset] !== undefined) {
              element.style[prop] = element.dataset[dataset];
              delete element.dataset[dataset];
            }
          };
          restore('position', 'demoOriginalPosition');
          restore('zIndex', 'demoOriginalZIndex');
          restore('outline', 'demoOriginalOutline');
          restore('outlineOffset', 'demoOriginalOutlineOffset');
          restore('borderRadius', 'demoOriginalBorderRadius');
          restore('boxShadow', 'demoOriginalBoxShadow');
          restore('animation', 'demoOriginalAnimation');
          restore('backgroundColor', 'demoOriginalBackground');
          restore('transform', 'demoOriginalTransform');
          restore('transition', 'demoOriginalTransition');
          element.classList.remove('demo-preview-element');
        });
        modifiedElements.clear();

        // Remove all overlay elements
        overlays.forEach(node => {
          if (node && typeof node.remove === 'function') node.remove();
        });
        overlays.clear();

        // Notify completion
        if (typeof example?.__vaOnEmpty === 'function') {
          example.__vaOnEmpty();
        }
      }, 450);
    };

    const clamp = (value, min, max) => Math.min(Math.max(value, min), max);

    // Create message box near the highlighted region (Apple liquid style)
    let messageBox = null;
    if (showMessage && messages.length > 0) {
      messageBox = document.createElement('div');
      messageBox.className = 'demo-preview-element';

      const glassStyles = `
        background: linear-gradient(135deg, rgba(255, 248, 235, 0.92) 0%, rgba(255, 245, 220, 0.88) 100%);
        backdrop-filter: blur(24px) saturate(160%);
        -webkit-backdrop-filter: blur(24px) saturate(160%);
        color: #78350f;
        padding: 6px 22px 6px 10px;
        border-radius: 10px;
        border: 1px solid rgba(251, 191, 36, 0.35);
        font-size: 16px;
        font-weight: 500;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        z-index: 10000;
        pointer-events: auto;
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15),
                    0 2px 8px rgba(0, 0, 0, 0.08),
                    inset 0 1px 0 rgba(255, 255, 255, 0.6);
        max-width: 240px;
        line-height: 1.45;
      `;

      messageBox.style.cssText = `
        position: fixed;
        visibility: hidden;
        ${glassStyles}
      `;

      const messageContent = document.createElement('div');
      messageContent.innerHTML = messages.join('<br>');
      messageBox.appendChild(messageContent);

      // Add close button
      const closeBtn = document.createElement('button');
      closeBtn.textContent = '×';
      closeBtn.style.cssText = `
        position: absolute;
        top: 5px;
        right: 6px;
        background: transparent;
        border: none;
        color: #78350f;
        font-size: 14px;
        line-height: 1;
        cursor: pointer;
        padding: 0;
        width: 14px;
        height: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0.6;
      `;
      closeBtn.addEventListener('click', () => {
        console.log('[MutateHighlight] Close clicked');
        clearTimeout(timeoutId);
        cleanup();
      });
      messageBox.appendChild(closeBtn);

      document.body.appendChild(messageBox);
      overlays.add(messageBox);

      const boxRect = messageBox.getBoundingClientRect();
      const viewportPadding = 16;
      const gap = 18;
      const preferredLeft = r.left + r.width / 2 - boxRect.width / 2;
      const left = clamp(preferredLeft, viewportPadding, window.innerWidth - boxRect.width - viewportPadding);
      const fitsAbove = r.top >= boxRect.height + gap + viewportPadding;
      const fitsBelow = window.innerHeight - r.bottom >= boxRect.height + gap + viewportPadding;
      const top = fitsAbove
        ? r.top - boxRect.height - gap
        : fitsBelow
          ? r.bottom + gap
          : clamp(r.top - boxRect.height - gap, viewportPadding, window.innerHeight - boxRect.height - viewportPadding);

      messageBox.style.left = `${left}px`;
      messageBox.style.top = `${top}px`;
      messageBox.style.visibility = 'visible';
    }

    console.log('[MutateHighlight] Created', overlays.size, 'overlay elements');

    const durationMs = typeof config.durationMs === 'number' ? config.durationMs : 2500;

    // Auto-remove after configured duration
    timeoutId = setTimeout(() => {
      console.log('[MutateHighlight] Auto-removing after timeout');
      cleanup();
    }, durationMs);

    return {
      undo: () => {
        console.log('[MutateHighlight] undo() called');
        clearTimeout(timeoutId);
        cleanup();
      },
    };
  };
})();
