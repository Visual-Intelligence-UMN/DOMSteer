(() => {
  /**
   * VADemoMutateReframe - Changes text content to reframe user perception
   *
   * Payload options:
   * - newText: string - The new text to display
   *
   * Example: Transform "Related Views" to "Charts You Might Want to Explore Next..."
   */
  window.VADemoMutateReframe = (example, elementMap) => {
    console.log('[MutateReframe] Called with:', { example, elementMap });
    console.log('[MutateReframe] Targets:', example.DOM_Manipulation.targets);
    console.log('[MutateReframe] Element map size:', elementMap.size);
    console.log(
      '[MutateReframe] Element map entries:',
      Array.from(elementMap.entries()).map(([k, v]) => ({
        index: k,
        element: v.tagName,
        text: v.textContent?.slice(0, 30),
      })),
    );

    const config = example.DOM_Manipulation.configuration || {};
    const modifiedElements = new Set();
    const overlays = new Set();
    const timeouts = new Set();

    // Add shine animation style if not exists
    if (!document.getElementById('demo-shine-animation-reframe')) {
      const styleEl = document.createElement('style');
      styleEl.id = 'demo-shine-animation-reframe';
      styleEl.className = 'demo-preview-element';
      styleEl.textContent = `
        @keyframes demo-shine-reframe {
          0%, 100% {
            box-shadow: 0 0 0 0 rgba(251, 191, 36, 0.5),
                        0 0 0 4px rgba(251, 191, 36, 0.3),
                        0 0 0 8px rgba(251, 191, 36, 0.15);
            transform: scale(1);
            background-color: rgba(251, 191, 36, 0.08);
          }
          50% {
            box-shadow: 0 0 0 3px rgba(251, 191, 36, 0.7),
                        0 0 0 8px rgba(251, 191, 36, 0.4),
                        0 0 0 14px rgba(251, 191, 36, 0.15);
            transform: scale(1.015);
            background-color: rgba(251, 191, 36, 0.15);
          }
        }
      `;
      document.head.appendChild(styleEl);
      overlays.add(styleEl);
    }

    example.DOM_Manipulation.targets.forEach((target, targetIdx) => {
      console.log(`[MutateReframe] Processing target ${targetIdx}:`, {
        index: target.index,
        uiDescription: target.uiDescription,
        payload: target.payload,
      });

      const element = elementMap.get(target.index);
      if (!element) {
        console.warn('[MutateReframe] No element found for index:', target.index);
        console.warn('[MutateReframe] Available indices:', Array.from(elementMap.keys()));
        return;
      }

      console.log('[MutateReframe] Element found:', {
        tagName: element.tagName,
        id: element.id,
        className: element.className,
        originalText: element.textContent?.slice(0, 50),
      });

      const newText = target.payload?.newText;
      if (!newText) {
        console.warn('[MutateReframe] No newText in payload for target:', target);
        console.warn('[MutateReframe] Payload contents:', target.payload);
        return;
      }

      console.log('[MutateReframe] Will reframe text:', {
        from: element.textContent?.slice(0, 50),
        to: newText.slice(0, 50),
      });

      // Store original text content
      element.dataset.demoOriginalTextContent = element.textContent;

      // Get element position for overlay
      const rect = element.getBoundingClientRect();
      const computedStyle = window.getComputedStyle(element);

      // Create overlay wrapper for animation
      const wrapper = document.createElement('div');
      wrapper.className = 'demo-preview-element';
      wrapper.style.cssText = `
        position: absolute;
        left: ${rect.left + window.scrollX}px;
        top: ${rect.top + window.scrollY}px;
        width: ${rect.width}px;
        height: ${rect.height}px;
        pointer-events: none;
        z-index: 10000;
      `;

      // Create old text layer
      const oldLayer = document.createElement('div');
      oldLayer.textContent = element.textContent;
      oldLayer.style.cssText = `
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        padding: ${computedStyle.padding};
        font-family: ${computedStyle.fontFamily};
        font-size: ${computedStyle.fontSize};
        font-weight: ${computedStyle.fontWeight};
        color: ${computedStyle.color};
        text-align: ${computedStyle.textAlign};
        line-height: ${computedStyle.lineHeight};
        opacity: 1;
        transition: opacity 0.8s ease-in-out;
      `;

      // Create new text layer
      const newLayer = document.createElement('div');
      newLayer.textContent = newText;
      newLayer.style.cssText = `
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        padding: ${computedStyle.padding};
        font-family: ${computedStyle.fontFamily};
        font-size: ${computedStyle.fontSize};
        font-weight: ${computedStyle.fontWeight};
        color: ${computedStyle.color};
        text-align: ${computedStyle.textAlign};
        line-height: ${computedStyle.lineHeight};
        opacity: 0;
        transition: opacity 0.8s ease-in-out;
      `;

      wrapper.appendChild(oldLayer);
      wrapper.appendChild(newLayer);
      document.body.appendChild(wrapper);
      overlays.add(wrapper);

      // Start crossfade animation
      setTimeout(() => {
        oldLayer.style.opacity = '0';
        newLayer.style.opacity = '1';
      }, 50);

      // Store extra original styles for restoration
      element.dataset.demoOriginalBorderRadius = element.style.borderRadius || '';
      element.dataset.demoOriginalOutline = element.style.outline || '';
      element.dataset.demoOriginalOutlineOffset = element.style.outlineOffset || '';
      element.dataset.demoOriginalBackground = element.style.backgroundColor || '';
      element.dataset.demoOriginalTransition = element.style.transition || '';

      // After animation completes, update element and remove wrapper
      const timeoutId = setTimeout(() => {
        element.textContent = newText;
        wrapper.remove();
        overlays.delete(wrapper);

        // Apply rounded golden highlight + background wash + scale pulse
        element.style.borderRadius = '8px';
        element.style.outline = '3px solid rgba(251, 191, 36, 0.85)';
        element.style.outlineOffset = '3px';
        element.style.backgroundColor = 'rgba(251, 191, 36, 0.08)';
        element.style.transition = 'transform 0.3s ease, background-color 0.3s ease';
        element.style.animation = 'demo-shine-reframe 1.8s ease-in-out 2';

        // Store original animation
        element.dataset.demoOriginalAnimation = element.style.animation || '';

        // Remove shine after animation completes, keep subtle background
        const shineTimeoutId = setTimeout(() => {
          element.style.animation = '';
          element.style.outline = '2px solid rgba(251, 191, 36, 0.4)';
          element.style.backgroundColor = 'rgba(251, 191, 36, 0.05)';
        }, 3600);
        timeouts.add(shineTimeoutId);
      }, 900);
      timeouts.add(timeoutId);

      element.classList.add('demo-preview-element');
      modifiedElements.add(element);

      console.log('[MutateReframe] Successfully reframed element:', {
        index: target.index,
        originalText: element.dataset.demoOriginalTextContent?.slice(0, 50),
        newText: element.textContent?.slice(0, 50),
        outline: element.style.outline,
        background: element.style.background,
      });
    });

    console.log('[MutateReframe] Reframed', modifiedElements.size, 'elements total');

    return {
      undo: () => {
        console.log('[MutateReframe] undo() called');

        // Clear all timeouts
        timeouts.forEach(timeoutId => clearTimeout(timeoutId));
        timeouts.clear();

        // Remove all overlay wrappers
        overlays.forEach(node => node.remove());
        overlays.clear();

        modifiedElements.forEach(element => {
          // Restore original text
          if (element.dataset.demoOriginalTextContent !== undefined) {
            element.textContent = element.dataset.demoOriginalTextContent;
            delete element.dataset.demoOriginalTextContent;
          }

          // Restore all styles
          const restore = (prop, dataset) => {
            if (element.dataset[dataset] !== undefined) {
              element.style[prop] = element.dataset[dataset];
              delete element.dataset[dataset];
            }
          };
          restore('borderRadius', 'demoOriginalBorderRadius');
          restore('outline', 'demoOriginalOutline');
          restore('outlineOffset', 'demoOriginalOutlineOffset');
          restore('backgroundColor', 'demoOriginalBackground');
          restore('transition', 'demoOriginalTransition');
          restore('animation', 'demoOriginalAnimation');
          element.style.transform = '';

          element.classList.remove('demo-preview-element');
        });

        modifiedElements.clear();
        console.log('[MutateReframe] Cleanup complete');
      },
    };
  };
})();
