(() => {
  const VISION_ENDPOINT = 'https://ais-dev-c2jk24nd5zxvlvfgsosz7w-163589410587.us-west1.run.app/api/vision';

  function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function createInlineRow(header, controls) {
    const row = document.createElement('div');
    row.className = 'demo-preview-element';
    row.style.cssText = `
      display: flex;
      align-items: center;
      gap: 8px;
      width: fit-content;
      max-width: 100%;
      margin: 0 0 6px;
      min-width: 0;
    `;

    const parent = header.parentNode;
    if (!parent) return null;

    parent.insertBefore(row, header);
    row.appendChild(header);
    row.appendChild(controls);
    return row;
  }

  // Shared entrance animation (same ID as demoInsertInlineControl)
  function ensureControlAnimation() {
    if (document.getElementById('demo-control-animation')) return;
    const el = document.createElement('style');
    el.id = 'demo-control-animation';
    el.className = 'demo-preview-element';
    el.textContent = `
      @keyframes demo-control-backdrop-in { 0% { opacity: 0; } 100% { opacity: 1; } }
      @keyframes demo-control-glow {
        0%, 100% { box-shadow: 0 0 4px 1px rgba(20,184,166,0.28), 0 0 12px 4px rgba(20,184,166,0.1); outline-color: rgba(20,184,166,0.6); }
        50% { box-shadow: 0 0 8px 3px rgba(20,184,166,0.45), 0 0 20px 8px rgba(20,184,166,0.18); outline-color: rgba(20,184,166,1); }
      }
    `;
    document.head.appendChild(el);
  }

  function applyControlEntrance(el) {
    const backdrop = document.createElement('div');
    backdrop.className = 'demo-preview-element';
    backdrop.style.cssText =
      'position:fixed;inset:0;background:rgba(0,0,0,0.3);z-index:9998;pointer-events:none;animation:demo-control-backdrop-in 0.3s ease-out forwards;';
    document.body.appendChild(backdrop);

    const origPosition = el.style.position || '';
    const origZIndex = el.style.zIndex || '';
    const origOutline = el.style.outline || '';
    const origOutlineOffset = el.style.outlineOffset || '';
    const origBorderRadius = el.style.borderRadius || '';
    const origTransform = el.style.transform || '';
    const origBg = el.style.backgroundColor || '';

    el.style.position = 'relative';
    el.style.zIndex = '9999';
    el.style.outline = '2.5px solid rgba(20,184,166,0.9)';
    el.style.outlineOffset = '4px';
    el.style.borderRadius = el.style.borderRadius || '6px';
    el.style.transform = 'scale(1.06)';
    el.style.backgroundColor = 'rgba(240,253,250,0.96)';
    el.style.transition =
      'transform 0.4s cubic-bezier(0.22,1,0.36,1), background-color 0.4s ease, box-shadow 0.3s ease';
    el.style.animation = 'demo-control-glow 1s ease-in-out infinite';

    setTimeout(() => {
      el.style.transform = origTransform || 'scale(1)';
      el.style.backgroundColor = origBg || '';
      el.style.animation = 'none';
      el.style.outline = origOutline;
      el.style.outlineOffset = origOutlineOffset;
      el.style.boxShadow = '';
      backdrop.style.transition = 'opacity 0.4s ease-in';
      backdrop.style.opacity = '0';
      setTimeout(() => {
        el.style.position = origPosition;
        el.style.zIndex = origZIndex;
        el.style.borderRadius = origBorderRadius;
        el.style.transition = 'background 0.2s, box-shadow 0.2s, border-color 0.2s';
        backdrop.remove();
      }, 420);
    }, 1800);
  }

  function buildControls() {
    ensureControlAnimation();
    const controls = document.createElement('div');
    controls.className = 'demo-preview-element';
    controls.style.cssText = `
      display: inline-flex;
      align-items: center;
      justify-content: flex-start;
      gap: 6px;
      width: auto;
      max-width: 100%;
      min-width: 0;
    `;

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'demo-preview-element';
    button.textContent = 'Describe chart';
    button.style.cssText = `
      margin: 0;
      padding: 6px 10px;
      background: linear-gradient(135deg, rgba(45, 212, 191, 0.46) 0%, rgba(13, 148, 136, 0.4) 100%);
      color: #115e59;
      border: 1px solid rgba(20, 184, 166, 0.32);
      border-radius: 8px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      white-space: nowrap;
      box-sizing: border-box;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
    `;
    applyControlEntrance(button);

    const status = document.createElement('span');
    status.className = 'demo-preview-element';
    status.style.cssText = `
      display: none;
      min-width: 0;
      max-width: 140px;
      color: rgba(248, 250, 252, 0.88);
      font-size: 11px;
      line-height: 1.3;
      text-align: left;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      white-space: normal;
    `;

    controls.appendChild(button);
    controls.appendChild(status);

    return { controls, button, status };
  }

  function resolveSpecifiedViewPane() {
    return (
      document.querySelector('.specified-vis-pane') ||
      Array.from(document.querySelectorAll('h2'))
        .find(node => node.textContent?.trim() === 'Specified View')
        ?.closest('div') ||
      null
    );
  }

  function resolveSpecifiedViewHeader(pane) {
    return (
      pane?.querySelector('h2') ||
      Array.from(document.querySelectorAll('h2')).find(node => node.textContent?.trim() === 'Specified View') ||
      null
    );
  }

  function resolveChartCanvas(pane) {
    return pane?.querySelector('.vega canvas') || pane?.querySelector('canvas') || null;
  }

  function resolveAnnotationTextarea(pane) {
    return pane?.querySelector('textarea.annotation') || pane?.querySelector('textarea') || null;
  }

  function resolveBookmarkControl(pane) {
    const candidates = Array.from(
      pane?.querySelectorAll(
        'button, [role="button"], [aria-label], [title], .bookmark, [ng-click], [data-va-element-id]',
      ) || [],
    );

    return (
      candidates.find(node => {
        const text = (node.textContent || '').trim().toLowerCase();
        const title = (node.getAttribute('title') || '').toLowerCase();
        const aria = (node.getAttribute('aria-label') || '').toLowerCase();
        const ngClick = (node.getAttribute('ng-click') || '').toLowerCase();
        return [text, title, aria, ngClick].some(value => value.includes('bookmark'));
      }) || null
    );
  }

  async function ensureAnnotationTextarea(pane) {
    let textarea = resolveAnnotationTextarea(pane);
    if (textarea) return textarea;

    const bookmarkControl = resolveBookmarkControl(pane);
    if (!bookmarkControl) {
      throw new Error('Bookmark control not found');
    }

    bookmarkControl.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));

    for (let attempt = 0; attempt < 10; attempt += 1) {
      await wait(150);
      textarea = resolveAnnotationTextarea(pane);
      if (textarea) return textarea;
    }

    throw new Error('Annotation textarea did not appear after bookmarking');
  }

  async function typewriterFill(element, text) {
    element.value = '';
    element.dispatchEvent(new Event('input', { bubbles: true }));

    for (let index = 0; index < text.length; index += 1) {
      await wait(15);
      element.value += text[index];
      element.dispatchEvent(new Event('input', { bubbles: true }));
    }

    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  async function requestChartDescription(imageDataUrl, prompt) {
    const response = await fetch(VISION_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        image: imageDataUrl,
        prompt,
      }),
    });

    const data = await response.json();
    if (!response.ok || !data?.success || !data?.text) {
      throw new Error(data?.error || 'Vision request failed');
    }

    return data.text;
  }

  window.VADemoInsertChartDescribeButton = () => {
    const pane = resolveSpecifiedViewPane();
    if (!pane) {
      console.warn('[InsertChartDescribeButton] Specified View pane not found');
      return { undo: () => {} };
    }

    const header = resolveSpecifiedViewHeader(pane);
    if (!header) {
      console.warn('[InsertChartDescribeButton] Specified View header not found');
      return { undo: () => {} };
    }

    const canvas = resolveChartCanvas(pane);
    if (!canvas) {
      console.warn('[InsertChartDescribeButton] Chart canvas not found');
      return { undo: () => {} };
    }

    const { controls, button, status } = buildControls();
    const originalParent = header.parentNode;
    const originalNextSibling = header.nextSibling;
    const originalHeaderMinWidth = header.style.minWidth || '';
    const row = createInlineRow(header, controls);
    header.style.minWidth = '0';

    const setStatus = message => {
      status.textContent = message || '';
      status.style.display = message ? 'block' : 'none';
    };

    const resetButton = () => {
      button.disabled = false;
      button.style.cursor = 'pointer';
      button.style.opacity = '1';
      button.textContent = 'Describe chart';
      setStatus('');
    };

    button.addEventListener('click', async () => {
      button.disabled = true;
      button.style.cursor = 'default';
      button.style.opacity = '0.7';
      button.textContent = 'Describing...';
      setStatus('Capturing chart');

      try {
        const imageDataUrl = canvas.toDataURL('image/jpeg', 0.92);
        setStatus('Preparing notes');
        const textarea = await ensureAnnotationTextarea(pane);
        setStatus('Sending chart to vision');

        const text = await requestChartDescription(
          imageDataUrl,
          'Describe this chart in 2-4 concise sentences for the annotation box. Focus on the main pattern, trend, or comparison visible in the chart.',
        );

        setStatus('Writing note');
        await typewriterFill(textarea, text);
        setStatus('Inserted chart description');
      } catch (error) {
        console.error('[InsertChartDescribeButton] Failed:', error);
        setStatus(error?.message || 'Could not describe chart');
      } finally {
        resetButton();
      }
    });

    return {
      undo: () => {
        if (originalParent) {
          originalParent.insertBefore(header, originalNextSibling);
        }
        header.style.minWidth = originalHeaderMinWidth;
        row?.remove();
      },
    };
  };
})();
