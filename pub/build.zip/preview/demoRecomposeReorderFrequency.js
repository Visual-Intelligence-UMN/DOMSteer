(() => {
  /**
   * VADemoRecomposeReorderFrequency - Monitors click frequency and reorders elements in real-time
   *
   * This script tracks how many times each element is clicked and dynamically reorders
   * them in descending order of click count (most clicked first).
   */
  window.VADemoRecomposeReorderFrequency = (example, elementMap) => {
    console.log('[RecomposeReorderFrequency] Called with:', { example, elementMap });
    const overlays = new Set();
    const modifiedElements = new Set();
    const originalPositions = new Map();
    const clickCounts = new Map();
    const badges = new Map();
    const originalBackgrounds = new Map();

    // Inject pulse animation style if not exists
    if (!document.getElementById('demo-pulse-animation')) {
      const style = document.createElement('style');
      style.id = 'demo-pulse-animation';
      style.className = 'demo-preview-element';
      style.textContent = `
        @keyframes demo-pulse {
          0% { transform: scale(1); }
          50% { transform: scale(1.05); }
          100% { transform: scale(1); }
        }
      `;
      document.head.appendChild(style);
      overlays.add(style);
    }

    // 1. Collect elements
    const elements = example.DOM_Manipulation.targets
      .map(target => {
        const element = elementMap.get(target.index);
        if (!element) {
          console.warn('[RecomposeReorderFrequency] No element found for index:', target.index);
          return null;
        }
        return { element, index: target.index };
      })
      .filter(Boolean);

    if (elements.length === 0) {
      console.warn('[RecomposeReorderFrequency] No elements found to reorder');
      return { undo: () => {} };
    }

    // 2. Store original positions
    elements.forEach(({ element }) => {
      originalPositions.set(element, {
        parent: element.parentElement,
        nextSibling: element.nextSibling,
      });
      clickCounts.set(element, 0);
    });

    // 3. Create wrapper (similar to existing reorder)
    const wrapper = document.createElement('div');
    wrapper.className = 'demo-preview-element';
    wrapper.style.cssText = `
      display: flex;
      flex-direction: column;
      gap: 6px;
      padding: 8px;
      border: 2px solid #10b981;
      border-radius: 6px;
      background: rgba(16, 185, 129, 0.05);
    `;

    // 4. Add click/drag listeners with badges
    elements.forEach(({ element }) => {
      // Store original position and background
      element.style.position = element.style.position || 'relative';
      element.dataset.demoOriginalPosition = element.style.position;
      const computedBg = window.getComputedStyle(element).backgroundColor;
      originalBackgrounds.set(element, element.style.backgroundColor || computedBg);

      // Create click count badge
      const badge = document.createElement('div');
      badge.className = 'demo-preview-element';
      badge.textContent = '0';
      badge.style.cssText = `
        position: absolute;
        top: -8px;
        right: -8px;
        background: #10b981;
        color: white;
        border-radius: 50%;
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
        font-weight: bold;
        z-index: 10001;
        pointer-events: none;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
      `;

      // Position badge on element
      element.style.position = 'relative';
      element.appendChild(badge);
      badges.set(element, badge);
      overlays.add(badge);

      // Add interaction handlers (click + drag)
      const incrementCount = eventType => {
        const count = clickCounts.get(element) + 1;
        clickCounts.set(element, count);
        badge.textContent = count.toString();

        console.log(`[RecomposeReorderFrequency] Element ${eventType}, new count:`, count);

        // Update background color based on frequency
        updateBackgroundColor(element, count);

        // Reorder immediately
        reorderByFrequency();
      };

      const clickHandler = () => incrementCount('clicked');
      const dragHandler = () => incrementCount('dragged');

      element.addEventListener('click', clickHandler);
      element.addEventListener('dragstart', dragHandler);
      element.dataset.demoFrequencyHandler = 'attached';
      element.dataset.demoDragHandler = 'attached';
      modifiedElements.add(element);
    });

    // 5. Move elements into wrapper
    const firstElement = elements[0].element;
    const insertionPoint = firstElement.parentElement;
    insertionPoint?.insertBefore(wrapper, firstElement);
    overlays.add(wrapper);

    elements.forEach(({ element }) => {
      wrapper.appendChild(element);
    });

    // 6. Update background color based on frequency
    const updateBackgroundColor = (element, count) => {
      // Calculate opacity based on frequency (higher = deeper)
      // Map count to opacity: 1 click = 0.05, 10+ clicks = 0.5
      const maxOpacity = 0.5;
      const opacity = Math.min(maxOpacity, count * 0.05);
      element.style.backgroundColor = `rgba(16, 185, 129, ${opacity})`;
    };

    // 7. Reorder function
    const reorderByFrequency = () => {
      const sorted = [...elements].sort((a, b) => {
        const countA = clickCounts.get(a.element) || 0;
        const countB = clickCounts.get(b.element) || 0;
        if (countB !== countA) return countB - countA; // Higher first
        return 0; // Stable sort
      });

      sorted.forEach(({ element }) => {
        wrapper.appendChild(element); // Reorder by appending
        // Pulse animation
        element.style.animation = 'demo-pulse 0.3s ease-out';
        setTimeout(() => {
          element.style.animation = '';
        }, 300);
      });

      console.log(
        '[RecomposeReorderFrequency] Reordered elements:',
        sorted.map(e => ({ index: e.index, count: clickCounts.get(e.element) })),
      );
    };

    console.log(
      '[RecomposeReorderFrequency] Setup complete, monitoring clicks and drags on',
      elements.length,
      'elements',
    );

    // 8. Return undo function
    return {
      undo: () => {
        console.log('[RecomposeReorderFrequency] undo() called');

        // Step 1: Remove badges first (before cloning)
        badges.forEach((badge, element) => {
          badge.remove();
        });
        badges.clear();

        // Step 2: Clone elements to remove event listeners and restore styles
        const clonedElements = new Map(); // old element -> cloned element
        elements.forEach(({ element, index }) => {
          if (element.dataset.demoFrequencyHandler || element.dataset.demoDragHandler) {
            // Get original styles before cloning
            const originalBg = originalBackgrounds.get(element);
            const originalPos = element.dataset.demoOriginalPosition;

            // Clone element (this removes all event listeners)
            const clone = element.cloneNode(true);

            // Restore original styles on clone
            if (originalBg !== undefined) {
              clone.style.backgroundColor = originalBg;
            }
            if (originalPos !== undefined) {
              clone.style.position = originalPos;
            }

            // Remove demo data attributes
            delete clone.dataset.demoFrequencyHandler;
            delete clone.dataset.demoDragHandler;
            delete clone.dataset.demoOriginalPosition;

            // Replace old element with clone
            element.parentNode?.replaceChild(clone, element);
            clonedElements.set(element, clone);

            console.log(`[RecomposeReorderFrequency] Restored element ${index}: bg=${originalBg}, pos=${originalPos}`);
          }
        });

        // Step 3: Restore original positions (using cloned elements)
        elements.forEach(({ element, index }) => {
          const clone = clonedElements.get(element);
          const targetElement = clone || element; // Use clone if available, otherwise original
          const original = originalPositions.get(element);

          if (original?.parent) {
            // Remove from current position
            if (targetElement.parentNode) {
              targetElement.parentNode.removeChild(targetElement);
            }

            // Insert at original position
            if (original.nextSibling?.parentNode) {
              original.parent.insertBefore(targetElement, original.nextSibling);
            } else {
              original.parent.appendChild(targetElement);
            }

            console.log(`[RecomposeReorderFrequency] Moved element ${index} back to original position`);
          }
        });

        // Step 4: Remove wrapper and cleanup
        overlays.forEach(node => node.remove());
        overlays.clear();

        // Step 5: Clear all tracking maps
        originalBackgrounds.clear();
        clickCounts.clear();
        originalPositions.clear();
        modifiedElements.clear();
        clonedElements.clear();

        console.log('[RecomposeReorderFrequency] Cleanup complete');
      },
    };
  };
})();
