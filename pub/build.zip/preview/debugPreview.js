/**
 * Debug Preview Helper
 *
 * Paste enriched handbook entries, reground by keyword match, and preview instantly.
 * No LLM, no embeddings, no API calls.
 *
 * Usage in service worker console:
 *   // After injecting this script, use from the PAGE console:
 *   window.VADebug.loadEntries([...entries...]);
 *   window.VADebug.list();                    // list all entries
 *   window.VADebug.preview(0);                // preview entry at index 0
 *   window.VADebug.preview(0, { position: 'right' }); // override config
 *   window.VADebug.clear();                   // clear current preview
 *   window.VADebug.groundAll();               // reground all entries by keyword
 */
(() => {
  const entries = [];
  let currentUndo = null;

  // ── Keyword-based element grounding (no embedding) ──
  function findElementByKeyword(uiDescription) {
    const desc = (uiDescription || '')
      .toLowerCase()
      .replace(/^\[.*?\]\s*/, '')
      .trim();
    if (!desc) return null;

    const keywords = desc.split(/\s+/).filter(w => w.length > 2);
    const allElements = document.querySelectorAll('*');
    let bestMatch = null;
    let bestScore = 0;

    for (const el of allElements) {
      const text = (el.textContent || '').toLowerCase().trim();
      const ariaLabel = (el.getAttribute('aria-label') || '').toLowerCase();
      const title = (el.getAttribute('title') || '').toLowerCase();
      const placeholder = (el.getAttribute('placeholder') || '').toLowerCase();
      const combined = `${text} ${ariaLabel} ${title} ${placeholder}`;

      let score = 0;
      for (const kw of keywords) {
        if (combined.includes(kw)) score++;
      }

      // Bonus for tag match
      const tagMatch = uiDescription.match(/^\[(.*?)\]/);
      if (tagMatch) {
        const tagHint = tagMatch[1].toLowerCase();
        const elTag = el.tagName.toLowerCase();
        const elRole = (el.getAttribute('role') || '').toLowerCase();
        if (tagHint.includes(elTag) || tagHint.includes(elRole) || (elTag === 'canvas' && tagHint.includes('canvas'))) {
          score += 2;
        }
      }

      // Prefer shorter text (more specific match)
      if (
        score > bestScore ||
        (score === bestScore && bestMatch && text.length < (bestMatch.textContent || '').length)
      ) {
        bestScore = score;
        bestMatch = el;
      }
    }

    return bestScore >= Math.min(2, keywords.length) ? bestMatch : null;
  }

  // ── Build element map from grounded entries ──
  function buildElementMap(entry) {
    const map = new Map();
    const targets = entry?.DOM_Manipulation?.targets || [];

    targets.forEach((target, i) => {
      // First try to find by keyword
      const el = findElementByKeyword(target.uiDescription);
      if (el) {
        map.set(target.index ?? i, el);
        console.log(`  ✓ [${target.index ?? i}] "${target.uiDescription}" → found`);
      } else {
        console.warn(`  ✗ [${target.index ?? i}] "${target.uiDescription}" → NOT FOUND`);
      }
    });

    return map;
  }

  // ── Public API ──
  window.VADebug = {
    loadEntries(data) {
      entries.length = 0;
      const arr = Array.isArray(data) ? data : data?.entries || [data];
      entries.push(...arr);
      console.log(`[VADebug] Loaded ${entries.length} entries`);
      this.list();
    },

    list() {
      entries.forEach((e, i) => {
        const targets = e?.DOM_Manipulation?.targets || [];
        console.log(`[${i}] ${e.domSubtype} | ${(e.assistance || '').slice(0, 60)}... | ${targets.length} targets`);
      });
    },

    groundAll() {
      console.log('[VADebug] Regrounding all entries by keyword...');
      entries.forEach((entry, i) => {
        console.log(`Entry ${i}: "${(entry.assistance || '').slice(0, 50)}"`);
        buildElementMap(entry);
      });
    },

    preview(index, configOverride) {
      if (index < 0 || index >= entries.length) {
        console.error(`[VADebug] Index ${index} out of range (0-${entries.length - 1})`);
        return;
      }

      // Clear previous preview
      if (currentUndo) {
        currentUndo();
        currentUndo = null;
      }

      const entry = entries[index];
      const map = buildElementMap(entry);

      if (map.size === 0) {
        console.error('[VADebug] No elements found for this entry. Try adjusting uiDescription.');
        return;
      }

      // Apply config override
      const example = JSON.parse(JSON.stringify(entry));
      if (configOverride) {
        example.DOM_Manipulation.configuration = {
          ...example.DOM_Manipulation.configuration,
          ...configOverride,
        };
      }

      console.log('[VADebug] Previewing:', example.domSubtype, '| targets:', map.size);
      console.log('[VADebug] Config:', example.DOM_Manipulation.configuration);

      // Call the preview renderer
      const result = window.VAShowDemoPreview?.(example, map);
      if (result?.undo) {
        currentUndo = result.undo;
        console.log('[VADebug] Preview active. Call VADebug.clear() to remove.');
      } else {
        console.warn('[VADebug] No undo returned from preview. Scripts may not be loaded.');
        console.log('[VADebug] Make sure demo scripts are injected first.');
      }
    },

    clear() {
      if (currentUndo) {
        currentUndo();
        currentUndo = null;
        console.log('[VADebug] Preview cleared.');
      } else {
        // Fallback: remove all demo elements
        document.querySelectorAll('.demo-preview-element').forEach(el => el.remove());
        console.log('[VADebug] Fallback cleanup done.');
      }
    },

    // Quick test: preview a single inline entry
    test(opts = {}) {
      const {
        message = 'This is a test tooltip.',
        position = 'right',
        selector = 'button, a, [role="button"], canvas',
        sequential = false,
      } = opts;

      const elements = document.querySelectorAll(selector);
      if (elements.length === 0) {
        console.error('[VADebug] No elements found for selector:', selector);
        return;
      }

      const map = new Map();
      const targets = [];
      const count = Math.min(elements.length, sequential ? 3 : 1);

      for (let i = 0; i < count; i++) {
        map.set(i, elements[i]);
        targets.push({
          index: i,
          uiDescription: elements[i].textContent?.trim().slice(0, 30) || elements[i].tagName,
          payload: {
            message: sequential ? `Step ${i + 1}: ${message}` : message,
            sequence: sequential ? i + 1 : null,
          },
        });
      }

      const example = {
        domSubtype: 'insert.overlay_tip',
        assistance: 'Debug test tooltip',
        DOM_Manipulation: {
          targets,
          configuration: { position, style: 'arrow', sequential },
        },
      };

      if (currentUndo) {
        currentUndo();
        currentUndo = null;
      }

      console.log('[VADebug] Quick test:', { count, sequential, position });
      const result = window.VAShowDemoPreview?.(example, map);
      if (result?.undo) currentUndo = result.undo;
    },

    // Get current entries for editing
    getEntry(index) {
      return entries[index];
    },

    // Update an entry and re-preview
    updateEntry(index, patch) {
      if (index < 0 || index >= entries.length) return;
      const entry = entries[index];
      Object.assign(entry, patch);
      if (patch.DOM_Manipulation) {
        Object.assign(entry.DOM_Manipulation, patch.DOM_Manipulation);
      }
      console.log('[VADebug] Entry updated. Call VADebug.preview(' + index + ') to re-preview.');
    },
  };

  console.log(`[VADebug] Ready. Commands:
  VADebug.loadEntries([...])     Load handbook entries
  VADebug.list()                 List loaded entries
  VADebug.groundAll()            Reground all by keyword
  VADebug.preview(0)             Preview entry 0
  VADebug.preview(0, {position:'left'})  Override config
  VADebug.clear()                Clear preview
  VADebug.test()                 Quick tooltip test
  VADebug.test({sequential:true}) Sequential test
  VADebug.getEntry(0)            Get entry for editing
  VADebug.updateEntry(0, {...})  Patch an entry`);
})();
