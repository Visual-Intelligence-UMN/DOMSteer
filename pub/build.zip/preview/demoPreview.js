(() => {
  function notifyDemoPreviewCleared(exampleId) {
    console.log('[DemoPreview] Notifying preview cleared:', exampleId);
    // CustomEvent — works from page world, content script listens on document
    document.dispatchEvent(new CustomEvent('va-demo-preview-cleared', { detail: { exampleId } }));
    // Also try chrome.runtime.sendMessage for extension context (may not be available in page world)
    try {
      if (typeof chrome !== 'undefined' && chrome?.runtime?.sendMessage) {
        chrome.runtime.sendMessage({ type: 'demo_preview_cleared', exampleId });
      }
    } catch {
      // Expected to fail in page world — CustomEvent handles it
    }
  }

  const SUBTYPE_HANDLERS = {
    'insert.overlay_tip': 'VADemoInsertOverlayTip',
    'insert.widget': 'VADemoInsertWidget',
    'insert.inline_control': 'VADemoInsertInlineControl',
    'mutate.highlight': 'VADemoMutateHighlight',
    'mutate.visibility': 'VADemoMutateVisibility',
    'mutate.representation': 'VADemoMutateRepresentation',
    'mutate.reframe': 'VADemoMutateReframe',
    'recompose.reorder': 'VADemoRecomposeReorder',
    'recompose.group': 'VADemoRecomposeGroup',
    'recompose.layout': 'VADemoRecomposeLayout',
  };

  const SCRIPT_KEY_HANDLERS = {
    'insert.inline_control:datavoyager_refine_interpret_chart': 'VADemoInsertDatavoyagerRefineInterpretButton',
    'insert.widget:tensorflow_how_to_use_guide': 'VADemoInsertTensorflowGuideBox',
    'insert.widget:tensorflow_snapshot_widget': 'VADemoInsertTensorflowSnapshotWidget',
    'mutate.representation:select_to_chip_selector': 'VADemoMutateSelectToChipSelector',
    'recompose.layout:tensorflow_data_row_layout': 'VADemoRecomposeTensorflowDataRow',
  };

  function getHandlerName(example) {
    const scriptKey = example?.DOM_Manipulation?.configuration?.scriptKey;
    if (scriptKey) {
      const scriptScopedHandler = SCRIPT_KEY_HANDLERS[`${example?.domSubtype}:${scriptKey}`];
      if (scriptScopedHandler && typeof window[scriptScopedHandler] === 'function') {
        return scriptScopedHandler;
      }
    }

    const targets = example?.DOM_Manipulation?.targets || [];
    const isTxgnnLegendCase =
      example?.domSubtype === 'recompose.layout' &&
      targets[0]?.uiDescription === '[svg] nodelink' &&
      targets.some(target => target.uiDescription === '[text] Node Types:');

    if (isTxgnnLegendCase && typeof window.VADemoRecomposeTxgnnLegend === 'function') {
      return 'VADemoRecomposeTxgnnLegend';
    }

    return SUBTYPE_HANDLERS[example?.domSubtype];
  }

  window.VADemoPreviewManager = window.VADemoPreviewManager || {
    // Map<exampleId, { undo: Function }>
    activePreviews: new Map(),

    preview(example, elementMapData) {
      const id = example.id || `anon-${Date.now()}`;
      console.log('[DemoPreview] preview() called:', { id, domSubtype: example.domSubtype });

      // If this exact example is already previewing, clear it first
      if (this.activePreviews.has(id)) {
        this.clearOne(id);
      }

      // Build element map from data
      const elementMap = new Map();
      for (const [index, entry] of Object.entries(elementMapData)) {
        let element = null;
        if (entry.selector) {
          element = document.querySelector(entry.selector);
        } else if (entry.elementId) {
          element = document.getElementById(entry.elementId);
        }
        if (element) {
          elementMap.set(parseInt(index, 10), element);
        }
      }
      console.log('[DemoPreview] Built element map with', elementMap.size, 'elements');

      // Lifecycle callback
      let notifiedEmpty = false;
      example.__vaOnEmpty = () => {
        if (!notifiedEmpty) {
          notifiedEmpty = true;
          console.log('[DemoPreview] Example auto-cleared:', id);
          this.activePreviews.delete(id);
          notifyDemoPreviewCleared(id);
        }
      };

      // Route to handler
      const handlerName = getHandlerName(example);
      let result = { undo: () => {} };
      if (handlerName && typeof window[handlerName] === 'function') {
        console.log(`[DemoPreview] Calling ${handlerName}`);
        result = window[handlerName](example, elementMap) || result;
      } else {
        console.warn('[DemoPreview] No handler for:', example.domSubtype);
      }

      this.activePreviews.set(id, result);
      console.log('[DemoPreview] Active previews:', this.activePreviews.size);
    },

    clearOne(id) {
      const entry = this.activePreviews.get(id);
      if (entry && typeof entry.undo === 'function') {
        console.log('[DemoPreview] Clearing preview:', id);
        entry.undo();
      }
      this.activePreviews.delete(id);
    },

    clearAll() {
      console.log('[DemoPreview] clearAll() — clearing', this.activePreviews.size, 'previews');
      for (const [id, entry] of this.activePreviews) {
        if (entry && typeof entry.undo === 'function') {
          entry.undo();
        }
      }
      this.activePreviews.clear();
    },

    // Legacy compat
    clear() {
      this.clearAll();
    },
  };

  window.VAClearDemoPreview = exampleId => {
    if (exampleId) {
      window.VADemoPreviewManager?.clearOne(exampleId);
    } else {
      window.VADemoPreviewManager?.clearAll();
    }
  };

  window.VAShowDemoPreview = (example, elementMapData) => {
    window.VADemoPreviewManager?.preview(example, elementMapData);
  };

  window.VANotifyDemoPreviewCleared = notifyDemoPreviewCleared;
})();
