(() => {
  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }

  function resolvePartialBox(rect, partialRegion) {
    const widthRatio = clamp(Number(partialRegion?.widthRatio) || 0.38, 0.1, 1);
    const heightRatio = clamp(Number(partialRegion?.heightRatio) || 0.32, 0.1, 1);
    const regionWidth = rect.width * widthRatio;
    const regionHeight = rect.height * heightRatio;
    const anchor = partialRegion?.anchor || 'top-left';

    let left = rect.left;
    let top = rect.top;

    if (anchor.includes('right')) {
      left = rect.right - regionWidth;
    } else if (anchor.includes('center')) {
      left = rect.left + (rect.width - regionWidth) / 2;
    }

    if (anchor.includes('bottom')) {
      top = rect.bottom - regionHeight;
    } else if (anchor.includes('middle') || anchor.includes('center')) {
      top = rect.top + (rect.height - regionHeight) / 2;
    }

    return {
      left,
      top,
      width: regionWidth,
      height: regionHeight,
      right: left + regionWidth,
      bottom: top + regionHeight,
    };
  }

  window.VADemoMutatePartialHighlight = (example, elementMap) => {
    const config = example.DOM_Manipulation.configuration || {};
    const showMessage = config.showMessage !== false;
    const overlays = new Set();
    const messages = [];
    let cleanedUp = false;
    let timeoutId;

    if (!document.getElementById('demo-partial-highlight-animation')) {
      const styleEl = document.createElement('style');
      styleEl.id = 'demo-partial-highlight-animation';
      styleEl.className = 'demo-preview-element';
      styleEl.textContent = `
        @keyframes demo-partial-highlight-pulse {
          0% {
            transform: scale(1);
            box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.12);
          }
          100% {
            transform: scale(1.02);
            box-shadow: 0 0 0 6px rgba(59, 130, 246, 0.08),
                        0 10px 28px rgba(59, 130, 246, 0.14);
          }
        }
      `;
      document.head.appendChild(styleEl);
      overlays.add(styleEl);
    }

    const partialBoxes = [];
    example.DOM_Manipulation.targets.forEach((target, index) => {
      const element = elementMap.get(target.index);
      if (!element) {
        return;
      }
      const rect = element.getBoundingClientRect();
      const partialBox = resolvePartialBox(rect, config.partialRegion);
      partialBoxes.push(partialBox);

      if (target.payload?.message) {
        const prefix = example.DOM_Manipulation.targets.length > 1 ? `${index + 1}. ` : '';
        messages.push(`${prefix}${target.payload.message}`);
      }
    });

    if (partialBoxes.length === 0) {
      return { undo: () => {} };
    }

    const backdrop = document.createElement('div');
    backdrop.className = 'demo-preview-element';
    backdrop.style.cssText = `
      position: fixed;
      inset: 0;
      background: rgba(15, 23, 42, 0.38);
      z-index: 9998;
      pointer-events: auto;
    `;
    backdrop.addEventListener('click', () => {
      clearTimeout(timeoutId);
      cleanup();
    });
    document.body.appendChild(backdrop);
    overlays.add(backdrop);

    partialBoxes.forEach(box => {
      const spotlight = document.createElement('div');
      spotlight.className = 'demo-preview-element';
      spotlight.style.cssText = `
        position: fixed;
        left: ${box.left}px;
        top: ${box.top}px;
        width: ${box.width}px;
        height: ${box.height}px;
        border-radius: 12px;
        border: 2px solid rgba(96, 165, 250, 0.92);
        background: rgba(191, 219, 254, 0.18);
        box-shadow: 0 0 0 9999px rgba(15, 23, 42, 0.16);
        pointer-events: none;
        z-index: 9999;
        animation: demo-partial-highlight-pulse 0.8s ease-out infinite alternate;
      `;
      document.body.appendChild(spotlight);
      overlays.add(spotlight);
    });

    let messageBox = null;
    if (showMessage && messages.length > 0) {
      const union = partialBoxes.reduce(
        (acc, box) => ({
          left: Math.min(acc.left, box.left),
          top: Math.min(acc.top, box.top),
          right: Math.max(acc.right, box.right),
          bottom: Math.max(acc.bottom, box.bottom),
        }),
        { left: Infinity, top: Infinity, right: 0, bottom: 0 },
      );
      const width = union.right - union.left;
      const viewportPadding = 16;
      const gap = 12;

      messageBox = document.createElement('div');
      messageBox.className = 'demo-preview-element';
      messageBox.style.cssText = `
        position: fixed;
        visibility: hidden;
        background: linear-gradient(135deg, rgba(239, 246, 255, 0.96) 0%, rgba(219, 234, 254, 0.92) 100%);
        backdrop-filter: blur(18px) saturate(160%);
        -webkit-backdrop-filter: blur(18px) saturate(160%);
        color: #1d4ed8;
        padding: 7px 24px 7px 11px;
        border-radius: 10px;
        border: 1px solid rgba(96, 165, 250, 0.45);
        font-size: 16px;
        font-weight: 500;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        z-index: 10000;
        pointer-events: auto;
        box-shadow: 0 12px 30px rgba(15, 23, 42, 0.14);
        max-width: 280px;
        line-height: 1.45;
      `;

      const messageContent = document.createElement('div');
      messageContent.innerHTML = messages.join('<br>');
      messageBox.appendChild(messageContent);

      const closeBtn = document.createElement('button');
      closeBtn.textContent = '×';
      closeBtn.style.cssText = `
        position: absolute;
        top: 5px;
        right: 6px;
        background: transparent;
        border: none;
        color: #1d4ed8;
        font-size: 14px;
        line-height: 1;
        cursor: pointer;
        padding: 0;
        width: 14px;
        height: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0.6;
      `;
      closeBtn.addEventListener('click', () => {
        clearTimeout(timeoutId);
        cleanup();
      });
      messageBox.appendChild(closeBtn);

      document.body.appendChild(messageBox);
      overlays.add(messageBox);

      const boxRect = messageBox.getBoundingClientRect();
      const preferredLeft = union.left + width / 2 - boxRect.width / 2;
      const left = clamp(preferredLeft, viewportPadding, window.innerWidth - boxRect.width - viewportPadding);
      const fitsAbove = union.top >= boxRect.height + gap + viewportPadding;
      const fitsBelow = window.innerHeight - union.bottom >= boxRect.height + gap + viewportPadding;
      const top = fitsAbove
        ? union.top - boxRect.height - gap
        : fitsBelow
          ? union.bottom + gap
          : clamp(
              union.top - boxRect.height - gap,
              viewportPadding,
              window.innerHeight - boxRect.height - viewportPadding,
            );

      messageBox.style.left = `${left}px`;
      messageBox.style.top = `${top}px`;
      messageBox.style.visibility = 'visible';
    }

    const cleanup = () => {
      if (cleanedUp) {
        return;
      }
      cleanedUp = true;

      if (messageBox) {
        messageBox.style.transition = 'opacity 0.2s ease-in';
        messageBox.style.opacity = '0';
      }
      if (backdrop) {
        backdrop.style.transition = 'opacity 0.2s ease-in';
        backdrop.style.opacity = '0';
      }

      setTimeout(() => {
        overlays.forEach(node => {
          if (node && typeof node.remove === 'function') {
            node.remove();
          }
        });
        overlays.clear();
        if (typeof example?.__vaOnEmpty === 'function') {
          example.__vaOnEmpty();
        }
      }, 220);
    };

    timeoutId = window.setTimeout(cleanup, config.duration || 2500);

    return {
      undo: cleanup,
    };
  };
})();
