(() => {
  function getStyleValue(element, property) {
    const computed = window.getComputedStyle?.(element);
    return computed?.[property] || element.style[property] || '';
  }

  function removeIdsRecursively(node) {
    if (!node || typeof node.removeAttribute !== 'function') {
      return;
    }
    node.removeAttribute('id');
    if (Array.isArray(node.children)) {
      node.children.forEach(child => removeIdsRecursively(child));
    }
  }

  function normalizeReplicaNode(node) {
    if (!node || !node.style) {
      return;
    }

    const style = node.style;
    style.position = 'relative';
    style.left = 'auto';
    style.top = 'auto';
    style.right = 'auto';
    style.bottom = 'auto';
    style.transform = 'none';
    style.margin = '0';
    style.maxWidth = '100%';
    style.maxHeight = '100%';
    style.pointerEvents = 'none';

    if (Array.isArray(node.children)) {
      node.children.forEach(child => normalizeReplicaNode(child));
    }
  }

  function prettifyLabel(label) {
    return String(label || '')
      .replace(/^canvas-/, '')
      .replace(/([a-z])([A-Z])/g, '$1 $2')
      .replace(/-/g, ' ');
  }

  function attachDragElevation(element, wrapper, interactionCleanups) {
    if (!element || !wrapper) {
      return;
    }

    const baseWrapperZIndex = wrapper.style.zIndex || '';
    const baseElementZIndex = element.style.zIndex || '';

    const activate = () => {
      wrapper.style.zIndex = '2147483644';
      element.style.zIndex = '2147483645';
    };

    const deactivate = () => {
      wrapper.style.zIndex = baseWrapperZIndex;
      element.style.zIndex = baseElementZIndex;
    };

    const startEvents = ['pointerdown', 'mousedown', 'touchstart', 'dragstart'];
    const endEvents = ['pointerup', 'mouseup', 'touchend', 'touchcancel', 'dragend'];

    startEvents.forEach(eventName => element.addEventListener(eventName, activate, true));
    endEvents.forEach(eventName => window.addEventListener(eventName, deactivate, true));

    interactionCleanups.push(() => {
      startEvents.forEach(eventName => element.removeEventListener(eventName, activate, true));
      endEvents.forEach(eventName => window.removeEventListener(eventName, deactivate, true));
      deactivate();
    });
  }

  function getPageBox(element) {
    const rect = element.getBoundingClientRect();
    return {
      left: rect.left + (window.scrollX || 0),
      top: rect.top + (window.scrollY || 0),
      right: rect.right + (window.scrollX || 0),
      bottom: rect.bottom + (window.scrollY || 0),
      width: rect.right - rect.left,
      height: rect.bottom - rect.top,
    };
  }

  function buildPositionedOverlay({ config, groupsMap, overlays, anchorElement }) {
    const groupColorPalette = [
      ['rgba(251, 191, 36, 0.24)', '#92400e'],
      ['rgba(249, 115, 22, 0.18)', '#9a3412'],
      ['rgba(56, 189, 248, 0.18)', '#0c4a6e'],
      ['rgba(52, 211, 153, 0.18)', '#065f46'],
    ];

    const overlayRoot = document.createElement('div');
    overlayRoot.className = 'demo-preview-element';
    overlayRoot.style.cssText = `
      position: absolute;
      inset: 0;
      pointer-events: none;
      z-index: 2147483646;
    `;

    if (document.body) {
      document.body.appendChild(overlayRoot);
    }
    overlays.add(overlayRoot);

    Array.from(groupsMap.entries()).forEach(([groupName, entries], groupIndex) => {
      const pageBoxes = entries.map(({ element }) => getPageBox(element));
      const labelReserve = 52;
      const paddingX = 10;
      const paddingY = 10;
      const left = Math.min(...pageBoxes.map(box => box.left)) - paddingX;
      const top = Math.min(...pageBoxes.map(box => box.top)) - paddingY;
      const right = Math.max(...pageBoxes.map(box => box.right)) + paddingX;
      const bottom = Math.max(...pageBoxes.map(box => box.bottom)) + paddingY;
      const [backgroundColor, labelColor] = groupColorPalette[groupIndex % groupColorPalette.length];
      const estimatedLabelWidth = Math.max(56, groupName.length * 7 + 22);
      const labelOffset = estimatedLabelWidth + 14;

      const container = document.createElement('div');
      container.className = 'demo-preview-element';
      container.style.cssText = `
        position: absolute;
        left: ${left}px;
        top: ${top}px;
        width: ${Math.max(48, right - left)}px;
        height: ${Math.max(40, bottom - top)}px;
        overflow: visible;
        border-radius: 18px;
        border: 1px solid rgba(251, 191, 36, 0.45);
        background: ${backgroundColor};
        box-shadow: 0 16px 34px rgba(15, 23, 42, 0.08);
      `;

      const label = document.createElement('div');
      label.className = 'demo-preview-element';
      label.textContent = groupName;
      label.style.cssText = `
        position: absolute;
        left: ${-labelOffset}px;
        top: 50%;
        transform: translateY(-50%);
        padding: 2px 8px;
        border-radius: 999px;
        background: rgba(255, 247, 237, 0.95);
        color: ${labelColor};
        font-size: 10px;
        font-weight: 700;
        white-space: nowrap;
        box-shadow: inset 0 0 0 1px rgba(251, 191, 36, 0.18);
      `;

      container.appendChild(label);
      overlayRoot.appendChild(container);
    });

    return {
      undo: () => {
        overlays.forEach(node => node.remove());
        overlays.clear();
      },
    };
  }

  function buildReplicaPanel({ example, config, groupsMap, overlays, anchorElement, fallbackInsertionPoint }) {
    const panel = document.createElement('div');
    panel.className = 'demo-preview-element';
    panel.style.cssText = `
      display: flex;
      flex-direction: column;
      gap: ${config.gap || 8}px;
      width: min(320px, 100%);
      margin: 8px 0 12px;
      padding: ${config.padding || 10}px;
      border: ${config.border === false ? '0' : '1px solid rgba(251, 191, 36, 0.35)'};
      border-radius: 16px;
      background: linear-gradient(180deg, rgba(255, 251, 235, 0.94) 0%, rgba(255, 247, 237, 0.9) 100%);
      box-shadow: 0 14px 34px rgba(15, 23, 42, 0.08);
      position: relative;
      z-index: 1;
    `;

    const heading = document.createElement('div');
    heading.className = 'demo-preview-element';
    heading.textContent = config.title || example.assistance || 'Grouped';
    heading.style.cssText = `
      font-size: 13px;
      font-weight: 700;
      color: #92400e;
      letter-spacing: 0.04em;
      text-transform: uppercase;
    `;
    panel.appendChild(heading);

    Array.from(groupsMap.entries()).forEach(([groupName, elements]) => {
      const section = document.createElement('section');
      section.className = 'demo-preview-element';
      section.style.cssText = `
        display: flex;
        flex-direction: column;
        gap: 8px;
        padding: 10px;
        border-radius: 12px;
        background: rgba(255, 255, 255, 0.72);
        border: 1px solid rgba(251, 191, 36, 0.18);
      `;

      const label = document.createElement('div');
      label.className = 'demo-preview-element';
      label.textContent = groupName;
      label.style.cssText = `
        font-size: 12px;
        font-weight: 700;
        color: #78350f;
      `;
      section.appendChild(label);

      const items = document.createElement('div');
      items.className = 'demo-preview-element';
      items.style.cssText = `
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
      `;

      elements.forEach(({ element, target }) => {
        const item = document.createElement('div');
        item.className = 'demo-preview-element';
        item.style.cssText = `
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 6px 8px;
          border-radius: 10px;
          background: rgba(255, 255, 255, 0.92);
          border: 1px solid rgba(148, 163, 184, 0.18);
        `;

        const thumb = document.createElement('div');
        thumb.className = 'demo-preview-element';
        thumb.style.cssText = `
          width: 34px;
          height: 34px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
          border-radius: 8px;
          background: rgba(241, 245, 249, 0.9);
        `;

        const replica = element.cloneNode(true);
        removeIdsRecursively(replica);
        normalizeReplicaNode(replica);
        thumb.appendChild(replica);

        const text = document.createElement('span');
        text.className = 'demo-preview-element';
        text.textContent = target.uiDescription || prettifyLabel(target.uiDescription);
        text.style.cssText = `
          font-size: 12px;
          line-height: 1.2;
          color: #334155;
        `;

        item.appendChild(thumb);
        item.appendChild(text);
        items.appendChild(item);
      });

      section.appendChild(items);
      panel.appendChild(section);
    });

    if (anchorElement?.parentElement) {
      anchorElement.parentElement.insertBefore(panel, anchorElement.nextSibling);
    } else if (fallbackInsertionPoint && fallbackInsertionPoint.parentElement) {
      fallbackInsertionPoint.parentElement.insertBefore(panel, fallbackInsertionPoint);
    }
    overlays.add(panel);

    return {
      undo: () => {
        overlays.forEach(node => node.remove());
        overlays.clear();
      },
    };
  }

  /**
   * VADemoRecomposeGroup - Physically groups elements into a container
   *
   * Configuration options:
   * - wrapper: 'panel' | 'section' | 'fieldset' - Container style (default: 'section')
   * - title: string - Title for the overall grouped area
   * - groups: [{ title, targetUiDescriptions }] - Explicit subgroup definitions
   * - gap: number - Space between items in pixels (default: 12)
   * - padding: number - Internal padding in pixels (default: 16)
   */
  window.VADemoRecomposeGroup = (example, elementMap) => {
    console.log('[RecomposeGroup] Called with:', { example, elementMap });
    const config = example.DOM_Manipulation.configuration || {};
    const overlays = new Set();
    const modifiedElements = new Set();
    const originalPositions = new Map();
    const originalStyles = new Map();
    const interactionCleanups = [];

    const targetsByIndex = new Map();
    example.DOM_Manipulation.targets.forEach(target => {
      const element = elementMap.get(target.index);
      if (!element) {
        console.warn('[RecomposeGroup] No element found for index:', target.index);
        return;
      }
      targetsByIndex.set(target.index, { element, index: target.index, target });
    });

    function resolveEntriesForDescriptions(descriptions) {
      const resolvedEntries = [];
      const seenElements = new Set();

      descriptions.forEach(description => {
        let resolved = null;

        if (typeof document.getElementById === 'function') {
          const byId = document.getElementById(description);
          if (byId) {
            const matchingTarget = example.DOM_Manipulation.targets.find(
              target => target.uiDescription === description,
            ) || {
              uiDescription: description,
            };
            resolved = {
              element: byId,
              index: matchingTarget.index ?? null,
              target: matchingTarget,
            };
          }
        }

        if (!resolved) {
          const matchingTarget = example.DOM_Manipulation.targets.find(target => target.uiDescription === description);
          if (matchingTarget) {
            resolved = targetsByIndex.get(matchingTarget.index) || null;
          }
        }

        if (resolved && !seenElements.has(resolved.element)) {
          seenElements.add(resolved.element);
          resolvedEntries.push(resolved);
        }
      });

      return resolvedEntries;
    }

    // 1. Group targets using explicit configuration.groups first, then fall back to legacy single-group behavior
    const groupsMap = new Map();
    const explicitGroups = Array.isArray(config.groups) ? config.groups : [];
    explicitGroups.forEach(group => {
      let entries = [];
      if (Array.isArray(group.targetUiDescriptions)) {
        entries = resolveEntriesForDescriptions(group.targetUiDescriptions);
      }
      if (entries.length === 0 && Array.isArray(group.targetIndices)) {
        entries = (group.targetIndices || []).map(index => targetsByIndex.get(index)).filter(Boolean);
      }
      if (entries.length > 0) {
        groupsMap.set(group.title || config.title || 'default', entries);
      }
    });

    if (groupsMap.size === 0) {
      example.DOM_Manipulation.targets.forEach(target => {
        const entry = targetsByIndex.get(target.index);
        if (!entry) {
          return;
        }
        const groupName = target.payload?.group || config.title || 'default';
        if (!groupsMap.has(groupName)) {
          groupsMap.set(groupName, []);
        }
        groupsMap.get(groupName).push(entry);
      });
    }

    if (groupsMap.size === 0) {
      console.warn('[RecomposeGroup] No elements to group');
      return { undo: () => {} };
    }

    const hasMultipleGroups = groupsMap.size > 1;
    console.log(`[RecomposeGroup] Found ${groupsMap.size} group(s)`);
    if (!hasMultipleGroups) {
      console.log('[RecomposeGroup] Single group mode (backward compatible)');
    }

    // Define color palette for multiple groups (golden-tinted variants)
    const groupPalettes = [
      {
        border: 'rgba(251, 191, 36, 0.48)',
        background: 'linear-gradient(135deg, rgba(251, 191, 36, 0.18) 0%, rgba(245, 158, 11, 0.1) 100%)',
        badgeBackground: 'rgba(251, 191, 36, 0.86)',
        badgeText: '#78350f',
        shadow: 'rgba(245, 158, 11, 0.16)',
      },
      {
        border: 'rgba(59, 130, 246, 0.42)',
        background: 'linear-gradient(135deg, rgba(96, 165, 250, 0.17) 0%, rgba(59, 130, 246, 0.08) 100%)',
        badgeBackground: 'rgba(59, 130, 246, 0.88)',
        badgeText: '#eff6ff',
        shadow: 'rgba(59, 130, 246, 0.14)',
      },
      {
        border: 'rgba(16, 185, 129, 0.42)',
        background: 'linear-gradient(135deg, rgba(110, 231, 183, 0.16) 0%, rgba(16, 185, 129, 0.08) 100%)',
        badgeBackground: 'rgba(16, 185, 129, 0.88)',
        badgeText: '#ecfdf5',
        shadow: 'rgba(16, 185, 129, 0.14)',
      },
      {
        border: 'rgba(168, 85, 247, 0.4)',
        background: 'linear-gradient(135deg, rgba(196, 181, 253, 0.16) 0%, rgba(168, 85, 247, 0.08) 100%)',
        badgeBackground: 'rgba(139, 92, 246, 0.9)',
        badgeText: '#f5f3ff',
        shadow: 'rgba(139, 92, 246, 0.14)',
      },
    ];

    const gap = config.gap || 8;
    const padding = config.padding || 8;

    // Get first element for insertion point
    const allElements = Array.from(groupsMap.values()).flat();
    const firstElement = allElements[0].element;
    const insertionPoint = firstElement.parentElement;
    const groupedDescriptions = new Set(
      Array.from(groupsMap.values())
        .flat()
        .map(({ target }) => target.uiDescription),
    );
    const anchorEntry = example.DOM_Manipulation.targets
      .filter(target => !groupedDescriptions.has(target.uiDescription))
      .map(target => targetsByIndex.get(target.index))
      .find(Boolean);
    const hasPositionedTargets = allElements.some(({ element }) => {
      const position = getStyleValue(element, 'position');
      return position === 'absolute' || position === 'fixed';
    });
    const mode = config.renderMode || (hasPositionedTargets ? 'positioned-overlay' : 'reparent');

    if (mode === 'replica-panel') {
      return buildReplicaPanel({
        example,
        config,
        groupsMap,
        overlays,
        anchorElement: anchorEntry?.element,
        fallbackInsertionPoint: firstElement,
      });
    }

    if (mode === 'positioned-overlay') {
      return buildPositionedOverlay({
        config,
        groupsMap,
        overlays,
        anchorElement: anchorEntry?.element,
      });
    }

    // Store original positions for all elements
    allElements.forEach(({ element }) => {
      const parent = element.parentElement;
      const nextSibling = element.nextSibling;
      originalPositions.set(element, { parent, nextSibling });
      originalStyles.set(element, {
        position: element.style.position || '',
        left: element.style.left || '',
        top: element.style.top || '',
        right: element.style.right || '',
        bottom: element.style.bottom || '',
        transform: element.style.transform || '',
        margin: element.style.margin || '',
        display: element.style.display || '',
        zIndex: element.style.zIndex || '',
      });
    });

    // Inject entrance animation keyframes
    if (!document.getElementById('demo-recompose-group-anim')) {
      const animStyle = document.createElement('style');
      animStyle.id = 'demo-recompose-group-anim';
      animStyle.className = 'demo-preview-element';
      animStyle.textContent = `
        @keyframes demo-group-wrapper-in {
          0% { opacity: 0; transform: translateY(8px) scale(0.97); }
          100% { opacity: 1; transform: translateY(0) scale(1); }
        }
        @keyframes demo-group-item-in {
          0% { opacity: 0; transform: translateX(-6px); }
          100% { opacity: 1; transform: translateX(0); }
        }
        @keyframes demo-group-badge-in {
          0% { opacity: 0; transform: translateY(-50%) scale(0.8); }
          100% { opacity: 1; transform: translateY(-50%) scale(1); }
        }
      `;
      document.head.appendChild(animStyle);
      overlays.add(animStyle);
    }

    // 2. Create wrapper for each group
    let lastWrapper = null;
    let globalItemIndex = 0;
    Array.from(groupsMap.entries()).forEach(([groupName, elements], groupIdx) => {
      const palette = groupPalettes[groupIdx % groupPalettes.length];
      const wrapperDelay = groupIdx * 120;

      // Create wrapper container
      const wrapper = document.createElement('div');
      wrapper.className = 'demo-preview-element';

      // Base wrapper styles — Apple liquid glass + entrance animation
      wrapper.style.cssText = `
        display: flex;
        flex-direction: column;
        gap: ${Math.max(4, gap - 4)}px;
        padding: 4px;
        padding-top: 14px;
        border: ${config.border === false ? '0' : `1px solid ${palette.border}`};
        border-radius: 8px;
        background: ${palette.background};
        backdrop-filter: blur(16px) saturate(160%);
        -webkit-backdrop-filter: blur(16px) saturate(160%);
        box-shadow: 0 4px 10px ${palette.shadow},
                    0 1px 4px rgba(0, 0, 0, 0.05),
                    inset 0 1px 0 rgba(255, 255, 255, 0.4);
        position: relative;
        margin: 4px 0 6px;
        overflow: visible;
        z-index: ${1000 + groupIdx};
        opacity: 0;
        animation: demo-group-wrapper-in 0.35s cubic-bezier(0.22, 1, 0.36, 1) ${wrapperDelay}ms forwards;
      `;

      // Add title badge — glass style + animation
      const titleBadge = document.createElement('div');
      titleBadge.className = 'demo-preview-element';
      titleBadge.textContent = groupName || config.title || 'Untitled Group';
      titleBadge.style.cssText = `
        position: absolute;
        top: 2px;
        left: 6px;
        background: ${palette.badgeBackground};
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        color: ${palette.badgeText};
        padding: 1px 6px;
        border-radius: 5px;
        font-size: 8px;
        font-weight: 700;
        line-height: 1.15;
        letter-spacing: 0;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        border: 1px solid rgba(255, 255, 255, 0.35);
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.08);
        max-width: calc(100% - 12px);
        overflow: hidden;
        text-overflow: ellipsis;
        opacity: 0;
        animation: demo-group-badge-in 0.3s ease-out ${wrapperDelay + 150}ms forwards;
      `;
      wrapper.appendChild(titleBadge);

      // Insert wrapper (first one at original position, others after previous wrapper)
      if (groupIdx === 0) {
        insertionPoint.insertBefore(wrapper, firstElement);
      } else {
        lastWrapper.parentElement.insertBefore(wrapper, lastWrapper.nextSibling);
      }
      overlays.add(wrapper);
      lastWrapper = wrapper;

      // Move elements into wrapper with staggered item animation
      elements.forEach(({ element }, itemIdx) => {
        const computedPosition = getStyleValue(element, 'position');
        if (computedPosition === 'absolute' || computedPosition === 'fixed') {
          element.style.position = 'relative';
          element.style.left = 'auto';
          element.style.top = 'auto';
          element.style.right = 'auto';
          element.style.bottom = 'auto';
          element.style.transform = 'none';
        }
        element.style.zIndex = '1';
        element.style.opacity = '0';
        element.style.animation = `demo-group-item-in 0.25s ease-out ${wrapperDelay + 200 + globalItemIndex * 40}ms forwards`;

        wrapper.appendChild(element);
        modifiedElements.add(element);
        attachDragElevation(element, wrapper, interactionCleanups);
        globalItemIndex++;
      });
    });

    // 8. Return undo function
    return {
      undo: () => {
        console.log('[RecomposeGroup] undo() called');

        // Restore elements to original positions
        modifiedElements.forEach(element => {
          const original = originalPositions.get(element);
          const originalStyle = originalStyles.get(element);
          if (original && original.parent) {
            if (original.nextSibling && original.nextSibling.parentNode) {
              original.parent.insertBefore(element, original.nextSibling);
            } else {
              original.parent.appendChild(element);
            }
          }

          // Clear animation styles added during grouping
          element.style.animation = '';
          element.style.opacity = '';

          if (originalStyle) {
            const styleKeys = [
              'position',
              'left',
              'top',
              'right',
              'bottom',
              'transform',
              'margin',
              'display',
              'zIndex',
            ];
            styleKeys.forEach(key => {
              const value = originalStyle[key];
              if (value) {
                element.style[key] = value;
              } else {
                element.style.removeProperty(key.replace(/[A-Z]/g, match => `-${match.toLowerCase()}`));
              }
            });
          }
        });

        groupsMap.clear();
        originalPositions.clear();
        originalStyles.clear();
        modifiedElements.clear();
        interactionCleanups.forEach(cleanupFn => cleanupFn());
        interactionCleanups.length = 0;

        // Remove all overlays (wrappers + badges)
        overlays.forEach(node => node.remove());
        overlays.clear();

        console.log('[RecomposeGroup] Cleanup complete');
      },
    };
  };
})();
