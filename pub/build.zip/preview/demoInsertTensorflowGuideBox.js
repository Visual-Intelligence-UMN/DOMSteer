(() => {
  function ensureGuideAnimation() {
    if (document.getElementById('va-demo-tensorflow-guide-animation')) return;
    const style = document.createElement('style');
    style.id = 'va-demo-tensorflow-guide-animation';
    style.className = 'demo-preview-element';
    style.textContent = `
      @keyframes va-demo-tensorflow-guide-shine {
        0%, 100% {
          box-shadow:
            0 10px 24px rgba(13, 148, 136, 0.08),
            0 0 0 0 rgba(45, 212, 191, 0);
        }
        50% {
          box-shadow:
            0 18px 32px rgba(13, 148, 136, 0.14),
            0 0 0 8px rgba(45, 212, 191, 0.16);
        }
      }

      .va-demo-tensorflow-guide-enter {
        opacity: 0;
        transform: translateY(18px) scale(0.985);
        filter: blur(6px);
      }

      .va-demo-tensorflow-guide-enter-active {
        opacity: 1;
        transform: translateY(0) scale(1);
        filter: blur(0);
        transition:
          opacity 320ms ease,
          transform 420ms cubic-bezier(0.22, 1, 0.36, 1),
          filter 360ms ease;
      }

      .va-demo-tensorflow-guide-shine {
        animation: va-demo-tensorflow-guide-shine 1.8s ease-in-out infinite;
      }
    `;
    document.head.appendChild(style);
  }

  function animateGuideBox(box) {
    ensureGuideAnimation();
    box.classList.add('va-demo-tensorflow-guide-enter');
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        box.classList.add('va-demo-tensorflow-guide-enter-active');
        setTimeout(() => {
          box.classList.add('va-demo-tensorflow-guide-shine');
        }, 120);
        setTimeout(() => {
          box.classList.remove('va-demo-tensorflow-guide-shine');
        }, 10000);
      });
    });
  }

  function findGuideAnchor(article) {
    return Array.from(article.querySelectorAll('.l--body, .l-body, div')).find(element =>
      /This Is Cool, Can I Repurpose It\?/i.test(element.textContent || ''),
    );
  }

  function buildGuideBox(config) {
    const guideConfig = config.guideBox || {};
    const box = document.createElement('div');
    box.id = 'va-how-to-use';
    box.className = 'demo-preview-element';
    box.style.cssText = `
      margin: 0 0 48px;
      padding: 20px 22px;
      border-radius: 16px;
      background: rgba(240, 253, 250, 0.92);
      border: 1px solid rgba(45, 212, 191, 0.42);
      box-shadow: 0 10px 24px rgba(13, 148, 136, 0.08);
      color: #0f766e;
    `;

    const title = guideConfig.title || 'How to Use This Playground';
    const paragraphs = guideConfig.paragraphs || [
      'Use the controls at the top to configure the network before or during training. Click Start to begin training. The decision boundary and output heatmap update in real time, and the play button changes to Pause so you can stop and resume at any point.',
      'Choose a dataset such as Circle, XOR, Gaussian, or Spiral, then adjust the training split, noise, and batch size in the Data panel. In the network diagram, use the + and − controls to add or remove hidden layers and to change the number of neurons in each layer.',
      'Hover over any neuron or connection to inspect its activation pattern or weight value. You can also use Regenerate to create a fresh random starting point and compare how different settings affect learning.',
    ];

    box.innerHTML = `
      <h3 style="margin:0 0 12px;font-size:24px;line-height:1.2;font-weight:700;color:#0f766e;">
        ${title}
      </h3>
      ${paragraphs
        .map(
          (paragraph, index) => `
        <p style="margin:${index === paragraphs.length - 1 ? '0' : '0 0 12px'};font-size:15px;line-height:1.72;color:#334155;">
          ${paragraph}
        </p>`,
        )
        .join('')}
    `;

    return box;
  }

  window.VADemoInsertTensorflowGuideBox = example => {
    const article = document.querySelector('#article-text');
    if (!article) return { undo: () => {} };

    const anchor = findGuideAnchor(article);
    if (!anchor || !anchor.parentElement) return { undo: () => {} };

    const config = example?.DOM_Manipulation?.configuration || {};
    const box = buildGuideBox(config);
    anchor.parentElement.insertBefore(box, anchor);
    animateGuideBox(box);

    return {
      undo: () => {
        box.classList.remove('va-demo-tensorflow-guide-enter');
        box.classList.remove('va-demo-tensorflow-guide-enter-active');
        box.classList.remove('va-demo-tensorflow-guide-shine');
        box.remove();
      },
    };
  };
})();
