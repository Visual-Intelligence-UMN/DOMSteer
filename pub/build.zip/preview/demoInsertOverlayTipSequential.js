(() => {
  /**
   * VADemoInsertOverlayTipSequential - Sequential tooltip display mode
   * Shows tooltips group by group with progression
   */
  window.VADemoInsertOverlayTipSequential = (example, elementMap) => {
    console.log('[InsertOverlayTipSequential] Called with:', { example, elementMap });
    const config = example.DOM_Manipulation.configuration || {};
    const highlightDurationMs = 16000;
    const shineCycle = 'demo-shine 1.8s cubic-bezier(0.4, 0, 0.2, 1) infinite';
    const overlays = new Set();
    const timeouts = new Set();
    const modifiedElements = new Set();
    const tooltipsBySequence = new Map();
    const firstTooltipPerSequence = new Map(); // Track first tooltip in each sequence
    const visibleTooltipPerSequence = new Set();
    let currentSequence = 1;
    let maxSequence = 0;
    let notifiedEmpty = false;

    // Add shine animation style if not exists
    if (!document.getElementById('demo-shine-animation')) {
      const styleEl = document.createElement('style');
      styleEl.id = 'demo-shine-animation';
      styleEl.className = 'demo-preview-element';
      styleEl.textContent = `
      @keyframes demo-shine {
        0%, 100% {
          box-shadow: 0 0 0 0 rgba(20, 184, 166, 0.16),
                      0 0 0 2px rgba(20, 184, 166, 0.14),
                      0 0 0 4px rgba(20, 184, 166, 0.08);
        }
        40%, 60% {
          box-shadow: 0 0 0 4px rgba(20, 184, 166, 0.88),
                      0 0 0 10px rgba(20, 184, 166, 0.4),
                      0 0 0 16px rgba(20, 184, 166, 0.18);
        }
      }
      `;
      document.head.appendChild(styleEl);
      overlays.add(styleEl);
    }

    // Group targets by sequence
    const sequenceGroups = new Map();
    example.DOM_Manipulation.targets.forEach(target => {
      const seq = target.payload?.sequence || 1;
      if (!sequenceGroups.has(seq)) {
        sequenceGroups.set(seq, []);
      }
      sequenceGroups.get(seq).push(target);
      maxSequence = Math.max(maxSequence, seq);
    });

    console.log(`[InsertOverlayTipSequential] Found ${sequenceGroups.size} sequences, max: ${maxSequence}`);

    // Process all targets
    example.DOM_Manipulation.targets.forEach((target, targetIdx) => {
      const element = elementMap.get(target.index);
      if (!element) {
        console.warn('[InsertOverlayTipSequential] No element found for index:', target.index);
        return;
      }

      const sequence = target.payload?.sequence || 1;
      const isLastSequence = sequence === maxSequence;
      const rawMessage = (target.payload?.message || '').trim();
      const canDisplayMessage = rawMessage !== '' && !visibleTooltipPerSequence.has(sequence);
      const hasMessage = canDisplayMessage;

      // Store original styles
      element.classList.add('demo-preview-element');
      element.dataset.demoOriginalOutline = element.style.outline || '';
      element.dataset.demoOriginalBoxShadow = element.style.boxShadow || '';
      element.dataset.demoOriginalAnimation = element.style.animation || '';
      modifiedElements.add(element);

      // Skip tooltip creation if no message
      if (!hasMessage) {
        console.log(`[InsertOverlayTipSequential] Skipping tooltip for element ${target.index} (no message)`);

        // Still track element by sequence (for highlighting only)
        if (!tooltipsBySequence.has(sequence)) {
          tooltipsBySequence.set(sequence, []);
        }
        tooltipsBySequence.get(sequence).push({
          label: null, // No tooltip
          element,
        });
        return;
      }

      visibleTooltipPerSequence.add(sequence);

      // Create label with message - Apple liquid design
      const label = document.createElement('div');
      label.className = 'demo-preview-element';
      label.style.cssText = `
        position: absolute;
        background: linear-gradient(135deg, rgba(248, 250, 252, 0.92) 0%, rgba(240, 253, 250, 0.9) 100%);
        backdrop-filter: blur(20px) saturate(180%);
        -webkit-backdrop-filter: blur(20px) saturate(180%);
        color: #0f172a;
        padding: 8px 12px 24px 12px;
        border-radius: 12px;
        border: 1px solid rgba(13, 148, 136, 0.35);
        font-size: 16px;
        line-height: 1.45;
        font-weight: 500;
        z-index: 10000;
        pointer-events: auto;
        box-shadow: 0 14px 36px rgba(15, 23, 42, 0.16),
                    0 6px 16px rgba(15, 23, 42, 0.1),
                    inset 0 1px 0 rgba(255, 255, 255, 0.5),
                    inset 0 -1px 0 rgba(0, 0, 0, 0.05);
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        max-width: 250px;
        word-wrap: break-word;
      `;

      const messageText = document.createElement('span');
      messageText.textContent = rawMessage;
      label.appendChild(messageText);

      // Only add Next button to the FIRST TOOLTIP in each sequence group
      // (not first target, since first target might have no message)
      const isFirstTooltipInSequence = !firstTooltipPerSequence.has(sequence);

      if (isFirstTooltipInSequence) {
        // Mark this sequence as having a tooltip
        firstTooltipPerSequence.set(sequence, true);
        const buttonText = isLastSequence ? 'Close' : 'Next';

        const nextBtn = document.createElement('button');
        nextBtn.textContent = buttonText;
        nextBtn.style.cssText = `
          position: absolute;
          bottom: 6px;
          right: 6px;
          background: linear-gradient(135deg, rgba(45, 212, 191, 0.82) 0%, rgba(13, 148, 136, 0.76) 100%);
          backdrop-filter: blur(10px);
          -webkit-backdrop-filter: blur(10px);
          border: 0.5px solid rgba(255, 255, 255, 0.4);
          color: #0f172a;
          font-size: 10px;
          font-weight: 600;
          padding: 3px 8px;
          border-radius: 6px;
          cursor: pointer;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          line-height: 1.2;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1),
                      inset 0 1px 0 rgba(255, 255, 255, 0.4);
        `;

        nextBtn.addEventListener('mouseenter', () => {
          nextBtn.style.background =
            'linear-gradient(135deg, rgba(45, 212, 191, 0.92) 0%, rgba(13, 148, 136, 0.86) 100%)';
          nextBtn.style.transform = 'scale(1.05)';
          nextBtn.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.5)';
        });
        nextBtn.addEventListener('mouseleave', () => {
          nextBtn.style.background =
            'linear-gradient(135deg, rgba(45, 212, 191, 0.82) 0%, rgba(13, 148, 136, 0.76) 100%)';
          nextBtn.style.transform = 'scale(1)';
          nextBtn.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.4)';
        });

        nextBtn.addEventListener('click', e => {
          e.stopPropagation();
          if (isLastSequence) {
            cleanup();
          } else {
            advanceSequence();
          }
        });

        label.appendChild(nextBtn);
      }

      // Position label near the element — offset within sequence to avoid stacking
      const rect = element.getBoundingClientRect();
      const position = config.position || 'right';
      const existingInSeq = (tooltipsBySequence.get(sequence) || []).length;
      const seqOffset = existingInSeq * 64; // vertical offset per tooltip in same sequence

      switch (position) {
        case 'top':
          label.style.left = `${rect.left + window.scrollX}px`;
          label.style.bottom = `${window.innerHeight - rect.top - window.scrollY + 10 + seqOffset}px`;
          break;
        case 'bottom':
          label.style.left = `${rect.left + window.scrollX}px`;
          label.style.top = `${rect.bottom + window.scrollY + 10 + seqOffset}px`;
          break;
        case 'right':
          label.style.left = `${rect.right + window.scrollX + 10}px`;
          label.style.top = `${rect.top + window.scrollY + seqOffset}px`;
          break;
        case 'left':
          label.style.right = `${window.innerWidth - rect.left - window.scrollX + 10}px`;
          label.style.top = `${rect.top + window.scrollY + seqOffset}px`;
          break;
      }

      document.body.appendChild(label);

      // Clamp to viewport — flip to left if overflowing right edge
      const labelRect = label.getBoundingClientRect();
      if (labelRect.right > window.innerWidth - 8) {
        label.style.left = '';
        label.style.right = `${window.innerWidth - rect.left - window.scrollX + 10}px`;
      }
      if (labelRect.bottom > window.innerHeight - 8) {
        label.style.top = '';
        label.style.bottom = `${window.innerHeight - rect.top - window.scrollY + 10}px`;
      }
      overlays.add(label);

      // Track tooltip by sequence
      if (!tooltipsBySequence.has(sequence)) {
        tooltipsBySequence.set(sequence, []);
      }
      tooltipsBySequence.get(sequence).push({
        label,
        element,
      });
    });

    // Show only the first sequence initially
    tooltipsBySequence.forEach((items, seq) => {
      if (seq === 1) {
        // Show first sequence
        items.forEach(({ label, element }) => {
          if (label) {
            label.style.display = 'block';
          }
          element.style.outline = '3px solid rgba(20, 184, 166, 0.82)';
          element.style.animation = shineCycle;
        });

        // Remove animation after the longer guided-reading window.
        const timeoutId = setTimeout(() => {
          items.forEach(({ element }) => {
            element.style.animation = element.dataset.demoOriginalAnimation || '';
          });
        }, highlightDurationMs);
        timeouts.add(timeoutId);
      } else {
        // Hide other sequences
        items.forEach(({ label }) => {
          if (label) {
            label.style.display = 'none';
          }
        });
      }
    });

    // Sequence advancement function
    const advanceSequence = () => {
      console.log(`[InsertOverlayTipSequential] Advancing from sequence ${currentSequence} to ${currentSequence + 1}`);

      // Fade out current sequence
      const currentItems = tooltipsBySequence.get(currentSequence);
      if (currentItems) {
        currentItems.forEach(({ label, element }) => {
          if (label) {
            label.style.transition = 'opacity 0.3s ease-out';
            label.style.opacity = '0';

            setTimeout(() => {
              label.style.display = 'none';
            }, 300);
          }

          // Clear animation on element
          element.style.animation = '';

          setTimeout(() => {
            // Restore element
            element.style.outline = element.dataset.demoOriginalOutline || '';
          }, 300);
        });
      }

      // Increment and show next
      currentSequence++;
      const nextItems = tooltipsBySequence.get(currentSequence);
      if (nextItems) {
        setTimeout(() => {
          nextItems.forEach(({ label, element }) => {
            if (label) {
              label.style.display = 'block';
              label.style.opacity = '0';

              setTimeout(() => {
                label.style.transition = 'opacity 0.3s ease-in';
                label.style.opacity = '1';
              }, 50);
            }

            // Apply element highlight
            element.style.outline = '3px solid rgba(20, 184, 166, 0.82)';
            element.style.animation = shineCycle;

            // Remove animation after the longer guided-reading window.
            const timeoutId = setTimeout(() => {
              element.style.animation = element.dataset.demoOriginalAnimation || '';
            }, highlightDurationMs);
            timeouts.add(timeoutId);
          });
        }, 300);
      }
    };

    const cleanup = () => {
      console.log('[InsertOverlayTipSequential] Cleanup called');
      notifiedEmpty = true;

      // Clear all timeouts
      timeouts.forEach(timeoutId => clearTimeout(timeoutId));
      timeouts.clear();

      // Restore all modified elements
      modifiedElements.forEach(element => {
        if (element.dataset.demoOriginalOutline !== undefined) {
          element.style.outline = element.dataset.demoOriginalOutline;
          delete element.dataset.demoOriginalOutline;
        }
        if (element.dataset.demoOriginalBoxShadow !== undefined) {
          element.style.boxShadow = element.dataset.demoOriginalBoxShadow;
          delete element.dataset.demoOriginalBoxShadow;
        }
        if (element.dataset.demoOriginalAnimation !== undefined) {
          element.style.animation = element.dataset.demoOriginalAnimation;
          delete element.dataset.demoOriginalAnimation;
        }
        element.classList.remove('demo-preview-element');
      });
      modifiedElements.clear();

      // Remove all overlay elements
      overlays.forEach(node => node.remove());
      overlays.clear();

      // Clear state
      sequenceGroups.clear();
      tooltipsBySequence.clear();
    };

    console.log('[InsertOverlayTipSequential] Setup complete');

    return {
      undo: cleanup,
    };
  };
})();
