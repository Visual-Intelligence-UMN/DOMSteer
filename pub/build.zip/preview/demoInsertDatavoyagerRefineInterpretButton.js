(() => {
  function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function ensureControlAnimation() {
    if (document.getElementById('demo-control-animation')) return;
    const el = document.createElement('style');
    el.id = 'demo-control-animation';
    el.className = 'demo-preview-element';
    el.textContent = `
      @keyframes demo-control-backdrop-in {
        0% { opacity: 0; }
        100% { opacity: 1; }
      }
      @keyframes demo-control-glow {
        0%, 100% {
          box-shadow: 0 0 4px 1px rgba(20, 184, 166, 0.22),
                      0 0 12px 4px rgba(13, 148, 136, 0.08);
          outline-color: rgba(20, 184, 166, 0.55);
        }
        50% {
          box-shadow: 0 0 8px 3px rgba(20, 184, 166, 0.34),
                      0 0 20px 8px rgba(13, 148, 136, 0.12);
          outline-color: rgba(13, 148, 136, 0.9);
        }
      }
    `;
    document.head.appendChild(el);
  }

  function applyControlEntrance(el) {
    const backdrop = document.createElement('div');
    backdrop.className = 'demo-preview-element';
    backdrop.style.cssText = `
      position: fixed;
      inset: 0;
      background: rgba(8, 47, 73, 0.12);
      z-index: 9998;
      pointer-events: none;
      animation: demo-control-backdrop-in 0.3s ease-out forwards;
    `;
    document.body.appendChild(backdrop);

    const originalPosition = el.style.position || '';
    const originalZIndex = el.style.zIndex || '';
    const originalOutline = el.style.outline || '';
    const originalOutlineOffset = el.style.outlineOffset || '';
    const originalTransform = el.style.transform || '';

    el.style.position = 'relative';
    el.style.zIndex = '9999';
    el.style.outline = '2.5px solid rgba(20, 184, 166, 0.82)';
    el.style.outlineOffset = '4px';
    el.style.transform = 'scale(1.05)';
    el.style.transition = 'transform 0.35s cubic-bezier(0.22, 1, 0.36, 1), box-shadow 0.25s ease';
    el.style.animation = 'demo-control-glow 1s ease-in-out infinite';

    setTimeout(() => {
      el.style.transform = originalTransform || 'scale(1)';
      el.style.animation = 'none';
      el.style.outline = originalOutline;
      el.style.outlineOffset = originalOutlineOffset;
      backdrop.style.transition = 'opacity 0.35s ease-in';
      backdrop.style.opacity = '0';

      setTimeout(() => {
        el.style.position = originalPosition;
        el.style.zIndex = originalZIndex;
        backdrop.remove();
      }, 360);
    }, 1600);
  }

  function createInlineRow(header, controls) {
    const row = document.createElement('div');
    row.className = 'demo-preview-element';
    row.style.cssText = `
      display: flex;
      align-items: center;
      gap: 8px;
      width: fit-content;
      max-width: 100%;
      margin: 0 0 6px;
      min-width: 0;
      flex-wrap: wrap;
    `;

    const parent = header.parentNode;
    if (!parent) return null;

    parent.insertBefore(row, header);
    row.appendChild(header);
    row.appendChild(controls);
    return row;
  }

  function collectDescriptors(node) {
    if (!node) return [];
    return [
      node.textContent || '',
      node.getAttribute?.('title') || '',
      node.getAttribute?.('aria-label') || '',
      node.getAttribute?.('ng-click') || '',
      node.getAttribute?.('data-tooltip') || '',
    ]
      .join(' ')
      .toLowerCase();
  }

  function findClickable(patterns) {
    const normalized = patterns.map(pattern => pattern.toLowerCase());
    const candidates = Array.from(
      document.querySelectorAll('button, a, [role="button"], [aria-label], [title], [ng-click], [data-va-element-id]'),
    );

    return (
      candidates.find(node => {
        const haystack = collectDescriptors(node);
        return normalized.every(pattern => haystack.includes(pattern));
      }) || null
    );
  }

  function pulseElement(element) {
    if (!element) return () => {};

    const originalOutline = element.style.outline || '';
    const originalOutlineOffset = element.style.outlineOffset || '';
    const originalTransition = element.style.transition || '';
    const originalBoxShadow = element.style.boxShadow || '';

    element.style.transition = 'outline-color 0.2s ease, box-shadow 0.2s ease';
    element.style.outline = '2px solid rgba(20, 184, 166, 0.85)';
    element.style.outlineOffset = '3px';
    element.style.boxShadow = '0 0 0 6px rgba(45, 212, 191, 0.16)';

    return () => {
      element.style.outline = originalOutline;
      element.style.outlineOffset = originalOutlineOffset;
      element.style.transition = originalTransition;
      element.style.boxShadow = originalBoxShadow;
    };
  }

  async function clickLikeUser(element) {
    if (!element) return;
    element.scrollIntoView?.({ block: 'center', inline: 'center', behavior: 'smooth' });
    await wait(220);
    element.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true, cancelable: true }));
    element.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true }));
    element.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
    await wait(40);
    element.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
    if (typeof element.click === 'function') {
      element.click();
    }
  }

  function resolveTargetElement(example, elementMap, uiDescription, fallbackPatterns = []) {
    const target = example?.DOM_Manipulation?.targets?.find(item => item.uiDescription === uiDescription);
    const mapped = target ? elementMap.get(target.index) : null;
    if (mapped) return mapped;
    if (fallbackPatterns.length > 0) return findClickable(fallbackPatterns);
    return null;
  }

  function findLogScaleControl() {
    return (
      findClickable(['log scale type']) ||
      findClickable(['log', 'scale']) ||
      Array.from(document.querySelectorAll('button, label, [role="button"], [role="menuitem"]')).find(node => {
        const text = (node.textContent || '').trim().toLowerCase();
        return text === 'log' || text.includes('log scale');
      }) ||
      null
    );
  }

  window.VADemoInsertDatavoyagerRefineInterpretButton = (example, elementMap) => {
    const anchor =
      resolveTargetElement(example, elementMap, '[text] Specified View') ||
      Array.from(document.querySelectorAll('h2')).find(node => node.textContent?.trim() === 'Specified View') ||
      null;

    if (!anchor) {
      console.warn('[InsertDatavoyagerRefineInterpretButton] Specified View anchor not found');
      return { undo: () => {} };
    }

    ensureControlAnimation();

    const controls = document.createElement('div');
    controls.className = 'demo-preview-element';
    controls.style.cssText = `
      display: inline-flex;
      align-items: center;
      gap: 8px;
      flex-wrap: wrap;
      width: auto;
      max-width: 100%;
      min-width: 0;
    `;

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'demo-preview-element';
    button.textContent = 'Refine Chart';
    button.style.cssText = `
      margin: 0;
      padding: 6px 11px;
      background: linear-gradient(135deg, rgba(204, 251, 241, 0.98) 0%, rgba(153, 246, 228, 0.96) 100%);
      color: #0f766e;
      border: 1px solid rgba(13, 148, 136, 0.24);
      border-radius: 999px;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
      white-space: nowrap;
      box-sizing: border-box;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      box-shadow: 0 8px 18px rgba(15, 118, 110, 0.1);
    `;
    applyControlEntrance(button);

    const toggleWrap = document.createElement('label');
    toggleWrap.className = 'demo-preview-element';
    toggleWrap.style.display = 'none';

    const toggle = document.createElement('input');
    toggle.type = 'checkbox';
    toggle.checked = false;

    const status = document.createElement('span');
    status.className = 'demo-preview-element';
    status.style.cssText = `
      display: none;
      min-width: 0;
      max-width: 180px;
      color: #0f766e;
      font-size: 11px;
      line-height: 1.35;
      text-align: left;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      white-space: normal;
    `;

    controls.append(button, toggleWrap, status);

    const originalParent = anchor.parentNode;
    const originalNextSibling = anchor.nextSibling;
    const originalAnchorMinWidth = anchor.style.minWidth || '';
    const row = createInlineRow(anchor, controls);
    anchor.style.minWidth = '0';

    const setStatus = message => {
      status.textContent = message || '';
      status.style.display = message ? 'block' : 'none';
    };

    const resetButton = () => {
      button.disabled = false;
      button.style.cursor = 'pointer';
      button.style.opacity = '1';
      button.textContent = 'Refine Chart';
    };

    button.addEventListener('click', async () => {
      const categoricalControl =
        resolveTargetElement(example, elementMap, '[link button] add-field Categorical Fields', [
          'add-field',
          'categorical fields',
        ]) || findClickable(['categorical', 'field']);
      const yAxisControl = resolveTargetElement(
        example,
        elementMap,
        '[link button] Y-Axis Properties Y-Axis Properties',
        ['y-axis properties'],
      );

      if (!categoricalControl) {
        setStatus('Could not find the categorical-field control.');
        return;
      }

      button.disabled = true;
      button.style.cursor = 'default';
      button.style.opacity = '0.7';
      button.textContent = 'Applying...';

      try {
        let clearPulse = pulseElement(categoricalControl);
        setStatus('Adding the first categorical field');
        await clickLikeUser(categoricalControl);
        clearPulse();

        await wait(420);
        clearPulse = pulseElement(categoricalControl);
        setStatus('Adding the second categorical field');
        await clickLikeUser(categoricalControl);
        clearPulse();

        await wait(420);

        if (toggle.checked) {
          if (!yAxisControl) {
            setStatus('Added categorical refinements. Could not find Y-Axis Properties for log scale.');
          } else {
            let clearAxisPulse = pulseElement(yAxisControl);
            setStatus('Opening Y-Axis Properties');
            await clickLikeUser(yAxisControl);
            clearAxisPulse();

            await wait(420);

            const logScaleControl = findLogScaleControl();
            if (logScaleControl) {
              const clearLogPulse = pulseElement(logScaleControl);
              setStatus('Switching Y axis to log scale');
              await clickLikeUser(logScaleControl);
              clearLogPulse();
              await wait(260);
              setStatus('Applied categorical grouping and log-y refinement.');
            } else {
              setStatus('Added categorical refinements. Log scale option did not appear.');
            }
          }
        } else {
          setStatus('Applied the categorical refinements. Next, compare the grouped patterns in the chart.');
        }
      } catch (error) {
        console.error('[InsertDatavoyagerRefineInterpretButton] Failed:', error);
        setStatus(error?.message || 'Could not run the refinement steps.');
      } finally {
        resetButton();
      }
    });

    return {
      undo: () => {
        if (originalParent) {
          originalParent.insertBefore(anchor, originalNextSibling);
        }
        anchor.style.minWidth = originalAnchorMinWidth;
        row?.remove();
      },
    };
  };
})();
