(() => {
  window.VADemoMutateRepresentation = (example, elementMap) => {
    console.log('[MutateRepresentation] Called with:', { example, elementMap });

    const target = example.DOM_Manipulation.targets[0];
    if (!target) {
      console.warn('[MutateRepresentation] No target found');
      return { undo: () => {} };
    }

    const element = elementMap.get(target.index);
    if (!element) {
      console.warn('[MutateRepresentation] No element found for index:', target.index);
      console.warn('[MutateRepresentation] Available indices:', Array.from(elementMap.keys()));
      console.warn('[MutateRepresentation] Trying to query element directly...');

      // Try to find element directly in case it's in DOM but not in map
      const directElement = document.querySelector(`[data-va-element-id="va-auto-id-${target.index}"]`);
      if (directElement) {
        console.warn('[MutateRepresentation] Found element directly in DOM, but not in elementMap');
        console.warn('[MutateRepresentation] Element details:', {
          tagName: directElement.tagName,
          id: directElement.id,
          display: directElement.style.display,
          parentNode: directElement.parentNode?.tagName,
          isConnected: directElement.isConnected,
        });
      } else {
        console.error('[MutateRepresentation] Element not found in DOM either!');
      }

      return { undo: () => {} };
    }

    console.log('[MutateRepresentation] Element found:', {
      tagName: element.tagName,
      id: element.id,
      currentDisplay: element.style.display,
      computedDisplay: window.getComputedStyle(element).display,
      isConnected: element.isConnected,
      parentNode: element.parentNode?.tagName,
    });

    const overlays = new Set();
    const modifiedElements = new Set();

    // Get configuration
    const config = example.DOM_Manipulation.configuration || {};
    const from = config.from || target.payload?.from;
    const to = config.to || target.payload?.to;
    const spacing = config.spacing || 8;

    console.log('[MutateRepresentation] Configuration:', { from, to, spacing });

    // Check if element is already modified from a previous preview
    if (element.classList.contains('demo-preview-element')) {
      console.warn(
        '[MutateRepresentation] Element already has demo-preview-element class, may be from previous preview',
      );
    }

    element.classList.add('demo-preview-element');

    // Store original styles (use computed style if inline style is empty)
    element.dataset.demoOriginalOutline = element.style.outline || '';

    // Preserve only the original inline display style so undo removes demo-only changes.
    if (!element.dataset.demoOriginalDisplay) {
      element.dataset.demoOriginalDisplay = element.style.display || '';
      console.log('[MutateRepresentation] Stored original display:', element.dataset.demoOriginalDisplay);
    } else {
      console.warn(
        '[MutateRepresentation] Element already has demoOriginalDisplay, keeping existing:',
        element.dataset.demoOriginalDisplay,
      );
    }

    element.style.outline = '2px dashed #f59e0b';
    modifiedElements.add(element);

    // Perform actual transformation
    if (from === 'dropdown' && to === 'button-group') {
      // Extract options from dropdown
      const options = Array.from(element.options || element.querySelectorAll('option'));

      if (options.length > 0) {
        console.log('[MutateRepresentation] Transforming dropdown with', options.length, 'options');

        // Create button group container
        const buttonGroup = document.createElement('div');
        buttonGroup.className = 'demo-preview-element';
        buttonGroup.style.cssText = `
          display: flex;
          gap: ${spacing}px;
          flex-wrap: wrap;
          align-items: center;
        `;

        // Get current dropdown value for initial button state
        const currentValue = element.value;
        console.log('[MutateRepresentation] Current dropdown value:', currentValue);

        // Create button for each option
        options.forEach((option, idx) => {
          const button = document.createElement('button');
          button.textContent = option.textContent;
          button.value = option.value;
          button.style.cssText = `
            padding: 4px 8px;
            border: 2px solid #f59e0b;
            background: white;
            color: #78350f;
            border-radius: 6px;
            cursor: pointer;
            font-size: 12px;
            font-family: inherit;
            font-weight: 500;
            transition: all 0.2s;
            white-space: nowrap;
            line-height: 1.2;
          `;

          // Highlight button that matches current dropdown value
          const isSelected = option.value === currentValue || (idx === 0 && !currentValue);
          if (isSelected) {
            button.style.background = '#f59e0b';
            button.style.color = 'white';
            console.log('[MutateRepresentation] Highlighting button:', option.value);
          }

          button.addEventListener('click', () => {
            console.log('[MutateRepresentation] Button clicked:', button.value);

            // Update the underlying dropdown value
            element.value = button.value;

            // Dispatch change event so other code can react
            const changeEvent = new Event('change', { bubbles: true });
            element.dispatchEvent(changeEvent);

            // Update button visual states
            buttonGroup.querySelectorAll('button').forEach(b => {
              b.style.background = 'white';
              b.style.color = '#78350f';
            });
            button.style.background = '#f59e0b';
            button.style.color = 'white';

            console.log('[MutateRepresentation] Dropdown value updated to:', element.value);
          });

          // Hover effect
          button.addEventListener('mouseenter', () => {
            if (button.style.background !== 'rgb(245, 158, 11)') {
              button.style.background = '#fef3c7';
            }
          });
          button.addEventListener('mouseleave', () => {
            if (button.style.background !== 'rgb(245, 158, 11)') {
              button.style.background = 'white';
            }
          });

          buttonGroup.appendChild(button);
        });

        // Hide original dropdown and insert button group
        element.style.display = 'none';
        element.parentNode.insertBefore(buttonGroup, element);
        overlays.add(buttonGroup);

        console.log('[MutateRepresentation] Created button group with', options.length, 'buttons');
        console.log('[MutateRepresentation] Element state after transformation:', {
          display: element.style.display,
          isConnected: element.isConnected,
          parentNode: element.parentNode?.tagName,
          hasAttribute: element.hasAttribute('data-va-element-id'),
        });
      }
    } else if (from === 'dropdown' && to === 'slider') {
      const options = Array.from(element.options || element.querySelectorAll('option'));

      if (options.length > 0) {
        const currentIndex = Math.max(
          0,
          options.findIndex(option => option.value === element.value),
        );

        const sliderWrap = document.createElement('div');
        sliderWrap.className = 'demo-preview-element';
        sliderWrap.style.cssText = `
          display: grid;
          gap: 6px;
          min-width: 220px;
          padding: 8px 10px;
          border-radius: 10px;
          border: 1px solid rgba(245, 158, 11, 0.28);
          background: rgba(255, 255, 255, 0.9);
          box-shadow: 0 8px 24px rgba(245, 158, 11, 0.14);
        `;

        const sliderLabel = document.createElement('div');
        sliderLabel.style.cssText = 'font-size: 11px; font-weight: 600; color: #78350f;';
        sliderLabel.textContent = `Learning rate: ${options[currentIndex]?.textContent || element.value}`;

        const slider = document.createElement('input');
        slider.type = 'range';
        slider.min = '0';
        slider.max = String(options.length - 1);
        slider.step = '1';
        slider.value = String(currentIndex);
        slider.style.cssText = 'width: 100%; accent-color: #f59e0b; cursor: pointer;';

        const ticks = document.createElement('div');
        ticks.style.cssText = `
          display: flex;
          justify-content: space-between;
          gap: 6px;
          font-size: 10px;
          color: #92400e;
        `;

        options.forEach(option => {
          const tick = document.createElement('span');
          tick.textContent = option.textContent;
          tick.style.cssText = 'white-space: nowrap;';
          ticks.appendChild(tick);
        });

        const syncSelection = nextIndex => {
          const selectedOption = options[nextIndex];
          if (!selectedOption) return;
          sliderLabel.textContent = `Learning rate: ${selectedOption.textContent}`;
          element.selectedIndex = nextIndex;
          element.value = selectedOption.value;
          element.dispatchEvent(new Event('change', { bubbles: true }));
        };

        slider.addEventListener('input', () => {
          syncSelection(Number(slider.value));
        });

        sliderWrap.appendChild(sliderLabel);
        sliderWrap.appendChild(slider);
        sliderWrap.appendChild(ticks);

        element.style.display = 'none';
        element.parentNode.insertBefore(sliderWrap, element);
        overlays.add(sliderWrap);
      }
    }

    return {
      undo: () => {
        console.log(
          '[MutateRepresentation] undo() called, cleaning up',
          modifiedElements.size,
          'elements and',
          overlays.size,
          'overlays',
        );

        modifiedElements.forEach(node => {
          console.log('[MutateRepresentation] Restoring element:', {
            tagName: node.tagName,
            id: node.id,
            originalDisplay: node.dataset.demoOriginalDisplay,
            currentDisplay: node.style.display,
            isConnected: node.isConnected,
          });

          // Restore outline
          if (node.dataset.demoOriginalOutline !== undefined) {
            if (node.dataset.demoOriginalOutline === '') {
              node.style.removeProperty('outline');
            } else {
              node.style.outline = node.dataset.demoOriginalOutline;
            }
            delete node.dataset.demoOriginalOutline;
          }

          // Restore display
          if (node.dataset.demoOriginalDisplay !== undefined) {
            // If original was empty string, remove the inline style completely
            if (node.dataset.demoOriginalDisplay === '') {
              node.style.removeProperty('display');
            } else {
              node.style.display = node.dataset.demoOriginalDisplay;
            }
            delete node.dataset.demoOriginalDisplay;
          }

          // Remove demo class
          node.classList.remove('demo-preview-element');

          console.log('[MutateRepresentation] Element restored:', {
            tagName: node.tagName,
            display: node.style.display,
            computedDisplay: window.getComputedStyle(node).display,
            hasAttribute: node.hasAttribute('data-va-element-id'),
            isConnected: node.isConnected,
          });
        });
        modifiedElements.clear();

        console.log('[MutateRepresentation] Removing', overlays.size, 'overlay elements');
        overlays.forEach(node => {
          console.log('[MutateRepresentation] Removing overlay:', node.tagName, node.className);
          node.remove();
        });
        overlays.clear();

        console.log('[MutateRepresentation] Cleanup complete - element should be findable now');
      },
    };
  };
})();
