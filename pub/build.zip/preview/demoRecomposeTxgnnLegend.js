(() => {
  function ensureTxgnnLegendAnimation() {
    if (document.getElementById('va-demo-txgnn-legend-animation')) return;
    const style = document.createElement('style');
    style.id = 'va-demo-txgnn-legend-animation';
    style.className = 'demo-preview-element';
    style.textContent = `
      .va-demo-txgnn-legend-chip-enter {
        opacity: 0;
        transform: translateY(10px) scale(0.96);
      }

      .va-demo-txgnn-legend-chip-enter-active {
        opacity: 1;
        transform: translateY(0) scale(1);
        transition:
          opacity 240ms ease,
          transform 360ms cubic-bezier(0.22, 1, 0.36, 1);
      }

      .va-demo-txgnn-anchor-focus {
        animation: va-demo-txgnn-anchor-pulse 1.2s ease-in-out 2;
      }

      @keyframes va-demo-txgnn-anchor-pulse {
        0%, 100% {
          box-shadow: 0 0 0 3px rgba(96, 165, 250, 0.08);
        }
        50% {
          box-shadow: 0 0 0 6px rgba(96, 165, 250, 0.16),
                      0 0 22px rgba(59, 130, 246, 0.14);
        }
      }
    `;
    document.head.appendChild(style);
  }

  function animateLegendRecompose(legendContainer, orderedWrappers, firstRect) {
    ensureTxgnnLegendAnimation();

    const lastRect = legendContainer.getBoundingClientRect();
    const deltaX = firstRect.left - lastRect.left;
    const deltaY = firstRect.top - lastRect.top;

    legendContainer.style.transformOrigin = 'top left';
    legendContainer.style.transition = 'none';
    legendContainer.style.transform = `translate(${deltaX}px, ${deltaY}px)`;

    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        legendContainer.style.transition =
          'transform 520ms cubic-bezier(0.22, 1, 0.36, 1), box-shadow 260ms ease, opacity 260ms ease';
        legendContainer.style.transform = 'translate(0, 0)';
      });
    });

    orderedWrappers.forEach((wrapper, index) => {
      wrapper.classList.add('va-demo-txgnn-legend-chip-enter');
      setTimeout(() => {
        wrapper.classList.add('va-demo-txgnn-legend-chip-enter-active');
      }, 120 + index * 45);
    });
  }

  function getUiLabel(target, fallback = '') {
    const label = target?.uiDescription?.replace(/^\[[^\]]+\]\s*/, '').trim();
    return label || fallback;
  }

  function normalizeLabel(text) {
    return (text || '').replace(/\s+/g, ' ').replace(/[:]+$/, '').trim().toLowerCase();
  }

  function findLegendContainer(titleSource) {
    if (!titleSource) return document.querySelector('.nodeTypes');
    if (titleSource.matches?.('.nodeTypes')) return titleSource;
    return titleSource.closest?.('.nodeTypes') || document.querySelector('.nodeTypes');
  }

  function findLegendWrapper(container, target) {
    const wanted = normalizeLabel(getUiLabel(target));
    if (!container || !wanted) return null;

    const wrappers = Array.from(container.children).filter(
      node => node.tagName?.toLowerCase() === 'div' && node.querySelector?.('span'),
    );

    const exact = wrappers.find(node => normalizeLabel(node.textContent) === wanted);
    if (exact) return exact;

    const partial = wrappers.find(node => normalizeLabel(node.textContent).includes(wanted));
    return partial || null;
  }

  function rememberInlineStyle(element, property) {
    return element.style[property] || '';
  }

  window.VADemoRecomposeTxgnnLegend = (example, elementMap) => {
    const modifiedElements = new Set();

    const [anchorTarget, titleTarget, ...itemTargets] = example?.DOM_Manipulation?.targets || [];
    const anchor = anchorTarget ? elementMap.get(anchorTarget.index) : null;
    const titleSource = titleTarget ? elementMap.get(titleTarget.index) : null;
    const legendContainer = findLegendContainer(titleSource);

    if (!anchor || !legendContainer) {
      return { undo: () => {} };
    }

    const insertionAnchor =
      anchor.closest?.('.ant-tabs-content-holder') || anchor.closest?.('[role="tabpanel"]') || anchor.parentElement;
    const insertionParent = insertionAnchor?.parentElement || null;
    const originalParent = legendContainer.parentNode;
    const originalNextSibling = legendContainer.nextSibling;
    const originalChildren = Array.from(legendContainer.children);
    const originalTransform = rememberInlineStyle(legendContainer, 'transform');
    const originalTransition = rememberInlineStyle(legendContainer, 'transition');
    const firstRect = legendContainer.getBoundingClientRect();

    const originalContainerStyles = {
      display: rememberInlineStyle(legendContainer, 'display'),
      flexWrap: rememberInlineStyle(legendContainer, 'flexWrap'),
      alignItems: rememberInlineStyle(legendContainer, 'alignItems'),
      gap: rememberInlineStyle(legendContainer, 'gap'),
      margin: rememberInlineStyle(legendContainer, 'margin'),
      padding: rememberInlineStyle(legendContainer, 'padding'),
      border: rememberInlineStyle(legendContainer, 'border'),
      borderRadius: rememberInlineStyle(legendContainer, 'borderRadius'),
      background: rememberInlineStyle(legendContainer, 'background'),
      boxShadow: rememberInlineStyle(legendContainer, 'boxShadow'),
      position: rememberInlineStyle(legendContainer, 'position'),
      zIndex: rememberInlineStyle(legendContainer, 'zIndex'),
      width: rememberInlineStyle(legendContainer, 'width'),
      maxWidth: rememberInlineStyle(legendContainer, 'maxWidth'),
    };

    const titleBreak = Array.from(legendContainer.children).find(node => node.tagName?.toLowerCase() === 'br');
    const originalBreakDisplay = titleBreak?.style?.display || '';

    const orderedWrappers = itemTargets
      .map(target => findLegendWrapper(legendContainer, target))
      .filter((node, index, arr) => node && arr.indexOf(node) === index);

    const originalWrapperStyles = new Map(
      orderedWrappers.map(wrapper => [
        wrapper,
        {
          marginLeft: wrapper.style.marginLeft || '',
          marginRight: wrapper.style.marginRight || '',
          display: wrapper.style.display || '',
        },
      ]),
    );

    const existingBadge = legendContainer.querySelector?.('[data-demo-txgnn-legend-badge="true"]');
    if (existingBadge) {
      existingBadge.remove();
    }

    if (insertionParent && insertionAnchor) {
      insertionParent.insertBefore(legendContainer, insertionAnchor);
    }

    legendContainer.classList.add('demo-preview-element');
    legendContainer.dataset.demoOriginalOutline = legendContainer.style.outline || '';
    legendContainer.dataset.demoOriginalOutlineOffset = legendContainer.style.outlineOffset || '';
    legendContainer.style.outline = '';
    legendContainer.style.outlineOffset = '';
    legendContainer.style.display = 'flex';
    legendContainer.style.flexWrap = 'wrap';
    legendContainer.style.alignItems = 'center';
    legendContainer.style.gap = '10px 12px';
    legendContainer.style.margin = '0 10px 10px';
    legendContainer.style.padding = '10px 14px';
    legendContainer.style.border = '2px dashed #94a3b8';
    legendContainer.style.borderRadius = '16px';
    legendContainer.style.background = 'rgba(226, 232, 240, 0.96)';
    legendContainer.style.boxShadow = '0 18px 40px rgba(15, 23, 42, 0.16)';
    legendContainer.style.position = 'relative';
    legendContainer.style.zIndex = '1';
    legendContainer.style.maxWidth = 'calc(100% - 20px)';
    modifiedElements.add(legendContainer);

    if (titleBreak) {
      titleBreak.style.display = 'none';
    }

    orderedWrappers.forEach(wrapper => {
      wrapper.classList.add('demo-preview-element');
      wrapper.style.marginLeft = '0';
      wrapper.style.marginRight = '0';
      wrapper.style.display = 'inline-flex';
      legendContainer.appendChild(wrapper);
      modifiedElements.add(wrapper);
    });

    const badge = document.createElement('div');
    badge.className = 'demo-preview-element';
    badge.setAttribute('data-demo-txgnn-legend-badge', 'true');
    badge.textContent = 'Reordered Colored NodeTypes';
    badge.style.cssText = `
      position: absolute;
      right: 12px;
      top: -14px;
      padding: 2px 10px;
      border-radius: 999px;
      background: rgba(29, 78, 216, 0.96);
      border: 1px solid rgba(191, 219, 254, 0.38);
      color: white;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.08em;
      z-index: 3;
      box-shadow: 0 10px 24px rgba(30, 64, 175, 0.24);
      transform: translateZ(0);
    `;
    legendContainer.appendChild(badge);

    anchor.classList.add('demo-preview-element');
    anchor.dataset.demoOriginalOutline = anchor.style.outline || '';
    anchor.dataset.demoOriginalOutlineOffset = anchor.style.outlineOffset || '';
    anchor.style.outline = '';
    anchor.style.outlineOffset = '';
    anchor.classList.add('va-demo-txgnn-anchor-focus');
    modifiedElements.add(anchor);

    animateLegendRecompose(legendContainer, orderedWrappers, firstRect);

    return {
      undo: () => {
        badge.remove();

        if (titleBreak) {
          titleBreak.style.display = originalBreakDisplay;
        }

        originalChildren.forEach(child => {
          if (child !== badge) {
            legendContainer.appendChild(child);
          }
        });

        originalWrapperStyles.forEach((styles, wrapper) => {
          wrapper.style.marginLeft = styles.marginLeft;
          wrapper.style.marginRight = styles.marginRight;
          wrapper.style.display = styles.display;
          wrapper.classList.remove('demo-preview-element');
        });

        if (originalParent) {
          if (originalNextSibling) {
            originalParent.insertBefore(legendContainer, originalNextSibling);
          } else {
            originalParent.appendChild(legendContainer);
          }
        }

        legendContainer.style.display = originalContainerStyles.display;
        legendContainer.style.flexWrap = originalContainerStyles.flexWrap;
        legendContainer.style.alignItems = originalContainerStyles.alignItems;
        legendContainer.style.gap = originalContainerStyles.gap;
        legendContainer.style.margin = originalContainerStyles.margin;
        legendContainer.style.padding = originalContainerStyles.padding;
        legendContainer.style.border = originalContainerStyles.border;
        legendContainer.style.borderRadius = originalContainerStyles.borderRadius;
        legendContainer.style.background = originalContainerStyles.background;
        legendContainer.style.boxShadow = originalContainerStyles.boxShadow;
        legendContainer.style.position = originalContainerStyles.position;
        legendContainer.style.zIndex = originalContainerStyles.zIndex;
        legendContainer.style.width = originalContainerStyles.width;
        legendContainer.style.maxWidth = originalContainerStyles.maxWidth;
        legendContainer.style.transform = originalTransform;
        legendContainer.style.transition = originalTransition;

        modifiedElements.forEach(element => {
          if (element.dataset.demoOriginalOutline !== undefined) {
            element.style.outline = element.dataset.demoOriginalOutline;
            delete element.dataset.demoOriginalOutline;
          }
          if (element.dataset.demoOriginalOutlineOffset !== undefined) {
            element.style.outlineOffset = element.dataset.demoOriginalOutlineOffset;
            delete element.dataset.demoOriginalOutlineOffset;
          }
          element.classList.remove('va-demo-txgnn-anchor-focus');
          element.classList.remove('va-demo-txgnn-legend-chip-enter');
          element.classList.remove('va-demo-txgnn-legend-chip-enter-active');
          element.classList.remove('demo-preview-element');
        });
        modifiedElements.clear();
      },
    };
  };
})();
