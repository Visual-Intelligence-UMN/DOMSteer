(() => {
  function ensureChipSelectorAnimation() {
    if (document.getElementById('va-chip-selector-animation')) return;
    const style = document.createElement('style');
    style.id = 'va-chip-selector-animation';
    style.className = 'demo-preview-element';
    style.textContent = `
      @keyframes va-chip-selector-source-pulse {
        0%, 100% {
          outline-color: rgba(245, 158, 11, 0.82);
          box-shadow:
            0 0 0 3px rgba(245, 158, 11, 0.08),
            0 0 0 7px rgba(245, 158, 11, 0.04);
        }
        50% {
          outline-color: rgba(245, 158, 11, 1);
          box-shadow:
            0 0 0 3px rgba(245, 158, 11, 0.22),
            0 0 0 9px rgba(245, 158, 11, 0.12),
            0 0 18px 6px rgba(245, 158, 11, 0.14);
        }
      }

      .va-chip-selector-source-focus {
        position: relative;
        z-index: 9999;
        outline: 3px solid rgba(245, 158, 11, 0.92);
        outline-offset: 5px;
        border-radius: 10px;
        animation: va-chip-selector-source-pulse 1s ease-in-out 2;
        transition: opacity 220ms ease, transform 260ms ease;
      }

      .va-chip-selector-source-exit {
        opacity: 0;
        transform: translateY(-4px) scale(0.98);
      }

      .va-chip-selector-enter {
        opacity: 0;
        transform: translateY(12px) scale(0.97);
        filter: blur(6px);
      }

      .va-chip-selector-enter-active {
        opacity: 1;
        transform: translateY(0) scale(1);
        filter: blur(0);
        transition:
          opacity 260ms ease,
          transform 360ms cubic-bezier(0.22, 1, 0.36, 1),
          filter 320ms ease;
      }

      .va-chip-selector-chip-enter {
        opacity: 0;
        transform: translateY(10px) scale(0.94);
      }

      .va-chip-selector-chip-enter-active {
        opacity: 1;
        transform: translateY(0) scale(1);
        transition:
          opacity 220ms ease,
          transform 320ms cubic-bezier(0.22, 1, 0.36, 1);
      }

      .va-chip-selector-tip-enter {
        opacity: 0;
        transform: translateY(-6px) scale(0.98);
      }

      .va-chip-selector-tip-enter-active {
        opacity: 1;
        transform: translateY(0) scale(1);
        transition:
          opacity 240ms ease,
          transform 320ms cubic-bezier(0.22, 1, 0.36, 1);
      }
    `;
    document.head.appendChild(style);
  }

  function animateChipSelector(wrap, row) {
    ensureChipSelectorAnimation();

    wrap.classList.add('va-chip-selector-enter');
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        wrap.classList.add('va-chip-selector-enter-active');
      });
    });

    Array.from(row.querySelectorAll('button')).forEach((button, index) => {
      button.classList.add('va-chip-selector-chip-enter');
      setTimeout(() => {
        button.classList.add('va-chip-selector-chip-enter-active');
      }, 40 + index * 35);
    });
  }

  function normalizeOptionLabel(text) {
    return (text || '').trim().replace(/\s*\([^)]*\)\s*$/, '');
  }

  function findOptionButton(container, wantedLabel) {
    const normalizedWanted = (wantedLabel || '').trim().toLowerCase();
    return Array.from(container.querySelectorAll('button')).find(button =>
      button.textContent.trim().toLowerCase().startsWith(normalizedWanted),
    );
  }

  function buildTip(theme, message) {
    const themes = {
      gold: {
        background: 'rgba(250, 204, 21, 0.9)',
        border: '1px solid rgba(202, 138, 4, 0.42)',
        color: '#713f12',
        shadow: '0 12px 24px rgba(161, 98, 7, 0.14)',
      },
      teal: {
        background: 'rgba(153, 246, 228, 0.9)',
        border: '1px solid rgba(13, 148, 136, 0.32)',
        color: '#115e59',
        shadow: '0 12px 24px rgba(15, 118, 110, 0.12)',
      },
    };
    const palette = themes[theme] || themes.gold;

    const tip = document.createElement('div');
    tip.id = 'va-chip-selector-overlay-tip';
    tip.className = 'demo-preview-element';
    tip.textContent = message;
    tip.style.cssText = `
      position: fixed;
      width: 220px;
      padding: 8px 10px;
      border-radius: 10px;
      background: ${palette.background};
      border: ${palette.border};
      color: ${palette.color};
      font-size: 12px;
      line-height: 1.4;
      box-shadow: ${palette.shadow};
      backdrop-filter: blur(6px);
      -webkit-backdrop-filter: blur(6px);
      z-index: 999999;
      pointer-events: none;
    `;

    const arrow = document.createElement('div');
    arrow.style.cssText = `
      position: absolute;
      left: 14px;
      top: -6px;
      width: 12px;
      height: 12px;
      background: ${palette.background};
      border-left: ${palette.border};
      border-top: ${palette.border};
      transform: rotate(45deg);
      border-radius: 2px;
    `;
    tip.appendChild(arrow);
    return tip;
  }

  function resolveTargetSelect(target, elementMap) {
    const mapped = target ? elementMap.get(target.index) : null;
    if (mapped?.tagName === 'SELECT') return mapped;

    return (
      document.querySelector('select.form-select.rounded-md.py-1.bg-white.border.border-slate-300.text-ellipsis.max-w-64') ||
      document.querySelector('select.form-select.text-ellipsis.max-w-64') ||
      document.querySelector('select.form-select') ||
      Array.from(document.querySelectorAll('select')).find(el =>
        Array.from(el.options || []).some(opt =>
          /title|country|province|description|points|price|variety|designation|projection_x|projection_y/i.test(
            opt.textContent || '',
          ),
        ),
      ) ||
      mapped ||
      null
    );
  }

  window.VADemoMutateSelectToChipSelector = (example, elementMap) => {
    const target = example?.DOM_Manipulation?.targets?.[0];
    if (!target) return { undo: () => {} };

    document.getElementById('va-field-selector-wrap')?.remove();
    document.getElementById('va-dropdown-hint')?.remove();
    document.getElementById('va-chip-selector-overlay-tip')?.remove();

    const select = resolveTargetSelect(target, elementMap);
    if (!select) return { undo: () => {} };

    const config = example.DOM_Manipulation.configuration || {};
    const optionCounts = config.optionCounts || {};
    const hintText = config.hint || 'Hint: click a field below to recolor the current view.';
    const overlayTipConfig = config.overlayTip || null;
    const showOverlayTip = overlayTipConfig?.show === true;

    const optionEls = Array.from(select.querySelectorAll('option')).filter(option => {
      const value = (option.value || '').trim();
      const text = (option.textContent || '').trim();
      return value && value !== 'undefined' && text && text !== '--';
    });
    if (!optionEls.length) return { undo: () => {} };

    const wrap = document.createElement('div');
    wrap.id = 'va-field-selector-wrap';
    wrap.className = 'demo-preview-element';
    wrap.style.cssText = `
      display: flex;
      flex-direction: column;
      gap: 6px;
      margin-top: 4px;
      max-width: 880px;
    `;

    const row = document.createElement('div');
    row.style.cssText = `
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    `;

    const hint = document.createElement('div');
    hint.id = 'va-dropdown-hint';
    hint.className = 'demo-preview-element';
    hint.textContent = hintText;
    hint.style.cssText = `
      font-size: 12px;
      line-height: 1.4;
      color: #64748b;
    `;

    const originalDisplay = select.style.display || '';
    const originalMaxWidth = select.style.maxWidth || '';
    const originalPosition = select.style.position || '';
    const originalZIndex = select.style.zIndex || '';
    const originalOutline = select.style.outline || '';
    const originalOutlineOffset = select.style.outlineOffset || '';
    const originalBorderRadius = select.style.borderRadius || '';
    const originalBoxShadow = select.style.boxShadow || '';
    const originalTransition = select.style.transition || '';
    const originalOpacity = select.style.opacity || '';
    const originalTransform = select.style.transform || '';
    const currentValue = select.value;
    let revealTimeoutId = null;

    optionEls.forEach(option => {
      const label = normalizeOptionLabel(option.textContent || '');
      const key = label.trim().toLowerCase();
      const count = optionCounts[key];

      const button = document.createElement('button');
      button.type = 'button';
      button.dataset.value = option.value;
      button.textContent = count != null ? `${label} (${count})` : label;
      button.style.cssText = `
        padding: 6px 10px;
        border-radius: 999px;
        border: 1px solid ${option.value === currentValue ? 'rgba(180, 83, 9, 0.42)' : 'rgba(217, 119, 6, 0.26)'};
        background: ${
          option.value === currentValue
            ? 'linear-gradient(135deg, rgba(245, 158, 11, 0.96) 0%, rgba(217, 119, 6, 0.92) 100%)'
            : 'linear-gradient(135deg, rgba(255, 251, 235, 0.96) 0%, rgba(255, 247, 237, 0.98) 100%)'
        };
        color: ${option.value === currentValue ? 'white' : '#78350f'};
        font-size: 12px;
        font-weight: 700;
        cursor: pointer;
        white-space: nowrap;
        box-shadow: ${option.value === currentValue ? '0 8px 18px rgba(180, 83, 9, 0.16)' : '0 1px 2px rgba(15, 23, 42, 0.04)'};
        transition: transform 160ms ease, box-shadow 180ms ease, background 180ms ease, color 180ms ease;
      `;
      button.addEventListener('mouseenter', () => {
        if (button.dataset.value === select.value) return;
        button.style.transform = 'translateY(-1px)';
        button.style.boxShadow = '0 6px 16px rgba(217, 119, 6, 0.12)';
        button.style.borderColor = 'rgba(217, 119, 6, 0.34)';
      });
      button.addEventListener('mouseleave', () => {
        if (button.dataset.value === select.value) return;
        button.style.transform = '';
        button.style.boxShadow = '0 1px 2px rgba(15, 23, 42, 0.04)';
        button.style.borderColor = 'rgba(217, 119, 6, 0.26)';
      });

      button.addEventListener('click', () => {
        select.value = option.value;
        select.dispatchEvent(new Event('change', { bubbles: true }));

        Array.from(row.querySelectorAll('button')).forEach(other => {
          const active = other.dataset.value === option.value;
          other.style.background = active
            ? 'linear-gradient(135deg, rgba(245, 158, 11, 0.96) 0%, rgba(217, 119, 6, 0.92) 100%)'
            : 'linear-gradient(135deg, rgba(255, 251, 235, 0.96) 0%, rgba(255, 247, 237, 0.98) 100%)';
          other.style.color = active ? 'white' : '#78350f';
          other.style.borderColor = active ? 'rgba(180, 83, 9, 0.42)' : 'rgba(217, 119, 6, 0.26)';
          other.style.boxShadow = active ? '0 8px 18px rgba(180, 83, 9, 0.16)' : '0 1px 2px rgba(15, 23, 42, 0.04)';
          other.style.transform = '';
        });
      });

      row.appendChild(button);
    });

    wrap.append(row, hint);

    select.style.position = originalPosition || 'relative';
    select.style.zIndex = '9999';
    select.style.transition = 'opacity 220ms ease, transform 260ms ease';
    select.classList.add('va-chip-selector-source-focus');

    let tip = null;
    if (showOverlayTip && overlayTipConfig?.option && overlayTipConfig?.message) {
      const optionButton = findOptionButton(row, overlayTipConfig.option);
      if (optionButton) {
        tip = buildTip(overlayTipConfig.theme, overlayTipConfig.message);
        document.body.appendChild(tip);
        const rect = optionButton.getBoundingClientRect();
        const left = Math.min(rect.left, window.innerWidth - 236);
        tip.style.left = `${Math.max(8, left)}px`;
        tip.style.top = `${rect.bottom + 10}px`;
      }
    }

    const revealWrap = () => {
      select.classList.add('va-chip-selector-source-exit');

      revealTimeoutId = window.setTimeout(() => {
        select.style.display = 'none';
        select.style.maxWidth = '220px';
        select.insertAdjacentElement('afterend', wrap);
        animateChipSelector(wrap, row);
      }, 520);
    };

    revealWrap();

    return {
      undo: () => {
        if (revealTimeoutId) {
          clearTimeout(revealTimeoutId);
        }
        wrap.remove();
        tip?.remove();
        select.style.display = originalDisplay;
        select.style.maxWidth = originalMaxWidth;
        select.style.position = originalPosition;
        select.style.zIndex = originalZIndex;
        select.style.outline = originalOutline;
        select.style.outlineOffset = originalOutlineOffset;
        select.style.borderRadius = originalBorderRadius;
        select.style.boxShadow = originalBoxShadow;
        select.style.transition = originalTransition;
        select.style.opacity = originalOpacity;
        select.style.transform = originalTransform;
        select.classList.remove('va-chip-selector-source-focus');
        select.classList.remove('va-chip-selector-source-exit');
      },
    };
  };
})();
