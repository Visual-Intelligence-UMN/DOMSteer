(() => {
  window.VADemoRecomposeLayout = (example, elementMap) => {
    const config = example.DOM_Manipulation.configuration || {};
    const overlays = new Set();
    const modifiedElements = new Set();

    // Read configuration
    const from = config.from || 'list';
    const to = config.to || 'grid';
    const columns = config.columns || 2;
    const gap = config.gap || 4;

    console.log('[RecomposeLayout] Configuration:', { from, to, columns, gap });

    example.DOM_Manipulation.targets.forEach(target => {
      const element = elementMap.get(target.index);
      if (!element) return;

      element.classList.add('demo-preview-element');

      // Store original styles
      element.dataset.demoOriginalOutline = element.style.outline || '';
      element.dataset.demoOriginalDisplay = element.style.display || '';
      element.dataset.demoOriginalGridTemplateColumns = element.style.gridTemplateColumns || '';
      element.dataset.demoOriginalGap = element.style.gap || '';
      element.dataset.demoOriginalFlexDirection = element.style.flexDirection || '';

      // Apply visual outline
      element.style.outline = '2px dashed #ec4899';

      // Apply actual layout changes
      if (to === 'grid') {
        element.style.display = 'grid';
        element.style.gridTemplateColumns = `repeat(${columns}, 1fr)`;
        element.style.gap = `${gap}px`;
      } else if (to === 'flex-row') {
        element.style.display = 'flex';
        element.style.flexDirection = 'row';
        element.style.gap = `${gap}px`;
      } else if (to === 'flex-column') {
        element.style.display = 'flex';
        element.style.flexDirection = 'column';
        element.style.gap = `${gap}px`;
      }

      modifiedElements.add(element);
    });

    // Add layout indicator
    const indicator = document.createElement('div');
    indicator.className = 'demo-preview-element';
    indicator.textContent = `Layout: ${config.from || '?'} → ${config.to || '?'}`;
    indicator.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: rgba(236, 72, 153, 0.95);
      color: white;
      padding: 12px 16px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: bold;
      z-index: 10001;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    `;
    document.body.appendChild(indicator);
    overlays.add(indicator);

    return {
      undo: () => {
        modifiedElements.forEach(element => {
          // Restore all original styles
          if (element.dataset.demoOriginalOutline !== undefined) {
            element.style.outline = element.dataset.demoOriginalOutline;
            delete element.dataset.demoOriginalOutline;
          }
          if (element.dataset.demoOriginalDisplay !== undefined) {
            element.style.display = element.dataset.demoOriginalDisplay;
            delete element.dataset.demoOriginalDisplay;
          }
          if (element.dataset.demoOriginalGridTemplateColumns !== undefined) {
            element.style.gridTemplateColumns = element.dataset.demoOriginalGridTemplateColumns;
            delete element.dataset.demoOriginalGridTemplateColumns;
          }
          if (element.dataset.demoOriginalGap !== undefined) {
            element.style.gap = element.dataset.demoOriginalGap;
            delete element.dataset.demoOriginalGap;
          }
          if (element.dataset.demoOriginalFlexDirection !== undefined) {
            element.style.flexDirection = element.dataset.demoOriginalFlexDirection;
            delete element.dataset.demoOriginalFlexDirection;
          }
          element.classList.remove('demo-preview-element');
        });
        modifiedElements.clear();

        overlays.forEach(node => node.remove());
        overlays.clear();
      },
    };
  };
})();
