(() => {
  /**
   * VADemoInsertWidget - Widget demonstration using iframe srcdoc
   * Mimics the logic from generatedWidget.js to avoid CSP issues
   */

  function looksLikeHtmlSnippet(code) {
    const trimmed = code.trim();
    return /^<([a-z][^>\s/]*)[\s>]/i.test(trimmed) && /<\/[a-z][^>]*>\s*$/i.test(trimmed);
  }

  function escapeForTemplateLiteral(code) {
    return code.replace(/\\/g, '\\\\').replace(/`/g, '\\`').replace(/\$\{/g, '\\${');
  }

  function normalizeWidgetCode(code, runtime) {
    if (runtime !== 'react-jsx') {
      throw new Error(`Unsupported widget runtime: ${runtime}`);
    }

    const trimmed = code.trim();
    if (!trimmed) return '';

    if (looksLikeHtmlSnippet(trimmed)) {
      return `render(String.raw\`${escapeForTemplateLiteral(trimmed)}\`);`;
    }

    return trimmed;
  }

  function escapeForInlineScript(code) {
    return code.replace(/<\/script/gi, '<\\/script');
  }

  /**
   * Build iframe srcdoc HTML with React/Babel environment
   * @param {string} code - Widget code to execute
   * @returns {string} Complete HTML document for iframe
   */
  function buildWidgetSrcdoc(code, runtime) {
    const executableCode = escapeForInlineScript(normalizeWidgetCode(code, runtime));
    const reactCdn = 'https://unpkg.com/react@18/umd/react.development.js';
    const reactDomCdn = 'https://unpkg.com/react-dom@18/umd/react-dom.development.js';
    const babelCdn = 'https://unpkg.com/@babel/standalone@7.23.9/babel.min.js';

    return `
      <!doctype html>
      <html>
        <head>
          <meta charset="utf-8" />
          <style>
            *, *::before, *::after { box-sizing: border-box; }
            body {
              margin: 0;
              padding: 10px;
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
              background: #f8fafc !important;
              color: #0f172a;
              font-size: 13px;
              zoom: 0.7;
            }
            div:not(button):not([role="button"]),
            section, table, thead, tbody, tr, td, th,
            main, article, header, footer, nav, p, span, h1, h2, h3, h4, h5, h6 {
              background: transparent !important;
              background-color: transparent !important;
            }
            #loading {
              color: #0f766e;
              font-size: 11px;
              padding: 6px;
            }
            #root {
              display: block;
            }
          </style>
        </head>
        <body>
          <div id="loading">Loading widget...</div>
          <div id="root"></div>

          <script>
            console.log('[Widget iframe] Starting to load scripts...');
          </script>

          <script crossorigin src="${reactCdn}" onload="console.log('[Widget] React loaded')" onerror="console.error('[Widget] Failed to load React')"></script>
          <script crossorigin src="${reactDomCdn}" onload="console.log('[Widget] ReactDOM loaded')" onerror="console.error('[Widget] Failed to load ReactDOM')"></script>
          <script src="${babelCdn}" onload="console.log('[Widget] Babel loaded')" onerror="console.error('[Widget] Failed to load Babel')"></script>

          <script>
            console.log('[Widget] Executing widget code...');

            // Hide loading message
            const loadingEl = document.getElementById('loading');
            if (loadingEl) loadingEl.style.display = 'none';

            // Provide render helper (globally accessible)
            window.render = element => {
              console.log('[Widget] render() called with:', element);
              const rootEl = document.getElementById('root');
              if (!rootEl) {
                console.error('[Widget] Root element not found!');
                return;
              }

              // For string content
              if (typeof element === 'string') {
                rootEl.innerHTML = element;
                return;
              }

              // For DOM elements
              if (element && element.nodeType) {
                rootEl.innerHTML = '';
                rootEl.appendChild(element);
                return;
              }

              // For React elements
              if (!rootEl.__root) {
                rootEl.__root = ReactDOM.createRoot(rootEl);
              }
              rootEl.__root.render(element);
            };

            // Provide demo API stubs (globally accessible)
            window.getScreenshotDataUrl = async () => {
              console.warn('[Widget] getScreenshotDataUrl not implemented in demo');
              return 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
            };

            window.callLLM = async (params) => {
              console.warn('[Widget] callLLM not implemented in demo', params);
              return 'Demo response - LLM not available in preview mode';
            };

          </script>

          <script type="text/babel" data-presets="react">
            // Import from window scope (single declaration to avoid redeclaration errors)
            const { render, getScreenshotDataUrl, callLLM } = window;

            // Execute widget code
            try {
              ${executableCode}
              console.log('[Widget] Widget code executed successfully');
            } catch (err) {
              console.error('[Widget] Preview error:', err);
              const rootEl = document.getElementById('root');
              rootEl.innerHTML = '<div style="color:#991b1b; font-size: 13px; padding: 8px; background: #fef2f2; border: 1px solid #fecaca; border-radius: 4px;"><strong>Widget Error:</strong><br>' + (err?.message || err) + '</div>';
            }
          </script>
        </body>
      </html>`;
  }

  /**
   * Attach drag behavior to widget
   * @param {HTMLElement} dragHandle - Element to drag from (header)
   * @param {HTMLElement} host - Element to move (widget container)
   */
  function attachDrag(dragHandle, host) {
    if (!dragHandle || !host) return;

    const clamp = (val, min, max) => Math.max(min, Math.min(val, max));

    const startDrag = event => {
      event.preventDefault();
      event.stopPropagation();

      const hostRect = host.getBoundingClientRect();
      const startX = event.clientX;
      const startY = event.clientY;
      const startLeft = hostRect.left;
      const startTop = hostRect.top;

      const onMove = moveEvent => {
        moveEvent.preventDefault();
        moveEvent.stopPropagation();

        const deltaX = moveEvent.clientX - startX;
        const deltaY = moveEvent.clientY - startY;

        const nextLeft = clamp(startLeft + deltaX, 0, window.innerWidth - hostRect.width);
        const nextTop = clamp(startTop + deltaY, 0, window.innerHeight - hostRect.height);

        host.style.left = `${nextLeft}px`;
        host.style.top = `${nextTop}px`;
        host.style.right = '';
        host.style.transform = 'none';
      };

      const endDrag = () => {
        window.removeEventListener('mousemove', onMove, true);
        window.removeEventListener('mouseup', endDrag, true);
      };

      window.addEventListener('mousemove', onMove, true);
      window.addEventListener('mouseup', endDrag, true);
    };

    dragHandle.addEventListener('mousedown', startDrag);
  }

  window.VADemoInsertWidget = (example, elementMap) => {
    console.log('[InsertWidget] Called with:', { example, elementMap });

    const target = example.DOM_Manipulation.targets[0];
    if (!target) return { undo: () => {} };

    const element = elementMap.get(target.index);
    if (!element) return { undo: () => {} };

    const config = example.DOM_Manipulation.configuration || {};
    const detail = config.detail || {};
    const widgetTitle = detail.title || target.payload?.title || 'Widget';
    const widgetCode = detail.code || '';
    const widgetRuntime = detail.runtime || 'react-jsx';
    const widgetPosition = config.position || 'sidebar';

    console.log('[InsertWidget] Widget title:', widgetTitle);
    console.log('[InsertWidget] Has code:', !!widgetCode.trim());
    console.log('[InsertWidget] Widget runtime:', widgetRuntime);

    // Create widget container
    const widget = document.createElement('div');
    widget.id = 'demo-preview-container';
    widget.className = 'demo-preview-element';
    widget.style.cssText = `
      position: fixed;
      z-index: 10001;
      pointer-events: auto;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    `;

    let backdrop = null;
    if (widgetPosition === 'modal') {
      backdrop = document.createElement('div');
      backdrop.className = 'demo-preview-element';
      backdrop.style.cssText = `
        position: fixed;
        inset: 0;
        z-index: 10000;
        background: rgba(15, 23, 42, 0.18);
        backdrop-filter: blur(7px);
        -webkit-backdrop-filter: blur(7px);
        pointer-events: none;
      `;
      document.body.appendChild(backdrop);
      widget.style.top = '50%';
      widget.style.left = '50%';
      widget.style.transform = 'translate(-50%, -50%)';
    } else if (widgetPosition === 'overlay') {
      const rect = element.getBoundingClientRect();
      widget.style.top = `${Math.max(16, rect.top + 12)}px`;
      widget.style.left = `${Math.max(16, rect.left + 12)}px`;
    } else {
      widget.style.top = '70px';
      widget.style.right = '12px';
    }

    // Create shell (rounded container — Apple liquid glass)
    const shell = document.createElement('div');
    shell.style.cssText = `
      background: linear-gradient(180deg, rgba(248, 250, 252, 0.95) 0%, rgba(240, 253, 250, 0.9) 100%);
      backdrop-filter: blur(24px) saturate(160%);
      -webkit-backdrop-filter: blur(24px) saturate(160%);
      color: #0f172a;
      border-radius: 14px;
      border: 1px solid rgba(13, 148, 136, 0.35);
      box-shadow: 0 24px 56px rgba(15, 23, 42, 0.22),
                  0 10px 24px rgba(15, 23, 42, 0.14),
                  inset 0 1px 0 rgba(255, 255, 255, 0.6);
      width: fit-content;
      max-width: ${widgetPosition === 'modal' ? '560px' : '400px'};
      overflow: hidden;
    `;

    // Create header
    const header = document.createElement('div');
    header.className = 'widget-header';
    header.style.cssText = `
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      padding: 8px 12px;
      background: linear-gradient(135deg, rgba(45, 212, 191, 0.48) 0%, rgba(13, 148, 136, 0.42) 100%);
      color: #0f172a;
      font-size: 12px;
      font-weight: 600;
      cursor: ${config.draggable !== false ? 'move' : 'default'};
      user-select: none;
      border-bottom: 1px solid rgba(20, 184, 166, 0.2);
    `;

    const title = document.createElement('span');
    title.textContent = widgetTitle;
    header.appendChild(title);

    // Create button row
    const buttonRow = document.createElement('div');
    buttonRow.style.cssText = 'display: flex; gap: 6px;';

    const removeWidget = () => {
      if (backdrop) backdrop.remove();
      widget.remove();
    };

    const createButton = (text, onClick) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = text;
      btn.style.cssText = `
        background: rgba(255, 255, 255, 0.4);
        color: #0f172a;
        border: 1px solid rgba(13, 148, 136, 0.28);
        border-radius: 6px;
        padding: 3px 7px;
        font-size: 10px;
        cursor: pointer;
        line-height: 1;
        transition: background 0.15s ease;
      `;
      btn.addEventListener('click', onClick);
      btn.addEventListener('mouseenter', () => {
        btn.style.background = 'rgba(45, 212, 191, 0.28)';
      });
      btn.addEventListener('mouseleave', () => {
        btn.style.background = 'rgba(255, 255, 255, 0.4)';
      });
      return btn;
    };

    // Collapse button
    const collapseBtn = createButton('➖', e => {
      e.preventDefault();
      e.stopPropagation();
      const isCollapsed = body.style.display === 'none';
      if (isCollapsed) {
        body.style.display = '';
        collapseBtn.textContent = '➖';
      } else {
        body.style.display = 'none';
        collapseBtn.textContent = '➕';
      }
    });
    buttonRow.appendChild(collapseBtn);

    // Close button (if closable)
    if (config.closable !== false) {
      const closeBtn = createButton('✖', e => {
        e.preventDefault();
        e.stopPropagation();
        removeWidget();
        console.log('[InsertWidget] Widget closed, notifying...');
        if (typeof example?.__vaOnEmpty === 'function') {
          example.__vaOnEmpty();
        }
      });
      closeBtn.style.borderRadius = '50%';
      closeBtn.style.width = '22px';
      closeBtn.style.height = '22px';
      closeBtn.style.padding = '0';
      closeBtn.style.display = 'flex';
      closeBtn.style.alignItems = 'center';
      closeBtn.style.justifyContent = 'center';
      buttonRow.appendChild(closeBtn);
    }

    header.appendChild(buttonRow);

    // Create body
    const body = document.createElement('div');
    body.style.cssText = 'padding: 0; width: fit-content; height: fit-content; background: rgba(248, 250, 252, 0.72);';

    // Create iframe with widget code
    if (widgetCode.trim()) {
      const iframe = document.createElement('iframe');
      iframe.style.cssText = `
        width: ${widgetPosition === 'modal' ? '520px' : '380px'};
        height: ${widgetPosition === 'modal' ? '360px' : '280px'};
        border: none;
        display: block;
        background: rgba(248, 250, 252, 0.88);
        border-radius: 0 0 13px 13px;
      `;
      iframe.sandbox = 'allow-scripts allow-same-origin';

      const srcdocContent = buildWidgetSrcdoc(widgetCode, widgetRuntime);
      console.log('[InsertWidget] Setting iframe srcdoc, length:', srcdocContent.length);

      iframe.srcdoc = srcdocContent;

      // Log when iframe loads
      iframe.onload = () => {
        console.log('[InsertWidget] Iframe loaded successfully');
      };

      iframe.onerror = error => {
        console.error('[InsertWidget] Iframe error:', error);
      };

      body.appendChild(iframe);
    } else {
      // Fallback message
      const fallback = document.createElement('div');
      fallback.style.cssText = 'padding: 12px; color: #0f766e; font-size: 11px; font-style: italic;';
      fallback.textContent = 'No widget code provided in configuration.detail.code';
      body.appendChild(fallback);
    }

    // Assemble widget
    shell.appendChild(header);
    shell.appendChild(body);
    widget.appendChild(shell);
    document.body.appendChild(widget);

    // Attach drag if enabled
    if (config.draggable !== false) {
      attachDrag(header, widget);
    }

    return {
      undo: () => {
        console.log('[InsertWidget] undo() called');
        removeWidget();
      },
    };
  };
})();
