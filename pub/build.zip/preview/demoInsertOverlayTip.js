(() => {
  window.VADemoInsertOverlayTip = (example, elementMap) => {
    console.log('[InsertOverlayTip] Called with:', { example, elementMap });
    const config = example.DOM_Manipulation.configuration || {};
    const highlightDurationMs = 16000;
    const shineCycle = 'demo-shine 1.8s cubic-bezier(0.4, 0, 0.2, 1) infinite';

    // DEFENSIVE: Check if sequential mode - delegate to separate script
    const sequential = config.sequential === true;
    console.log(`[InsertOverlayTip] Sequential mode: ${sequential}`);

    if (sequential) {
      console.log('[InsertOverlayTip] Delegating to sequential script...');
      if (typeof window.VADemoInsertOverlayTipSequential === 'function') {
        return window.VADemoInsertOverlayTipSequential(example, elementMap);
      } else {
        console.error('[InsertOverlayTip] Sequential script not loaded!');
        return { undo: () => {} };
      }
    }

    // Original non-sequential logic (ignores payload.sequence)
    const overlays = new Set();
    const timeouts = new Set();
    const modifiedElements = new Set();
    const visibleMessages = new Set();
    let activeCount = 0;
    let notifiedEmpty = false;

    const maybeNotifyEmpty = () => {
      activeCount--;
      if (activeCount <= 0 && !notifiedEmpty && typeof example?.__vaOnEmpty === 'function') {
        console.log('[InsertOverlayTip] All tooltips closed, notifying...');
        notifiedEmpty = true;
        example.__vaOnEmpty();
      }
    };

    // Add shine animation style if not exists
    if (!document.getElementById('demo-shine-animation')) {
      const styleEl = document.createElement('style');
      styleEl.id = 'demo-shine-animation';
      styleEl.className = 'demo-preview-element';
      styleEl.textContent = `
        @keyframes demo-shine {
          0%, 100% {
            box-shadow: 0 0 0 0 rgba(20, 184, 166, 0.16),
                        0 0 0 2px rgba(20, 184, 166, 0.14),
                        0 0 0 4px rgba(20, 184, 166, 0.08);
          }
          40%, 60% {
            box-shadow: 0 0 0 4px rgba(20, 184, 166, 0.88),
                        0 0 0 10px rgba(20, 184, 166, 0.4),
                        0 0 0 16px rgba(20, 184, 166, 0.18);
          }
        }
      `;
      document.head.appendChild(styleEl);
      overlays.add(styleEl);
    }

    example.DOM_Manipulation.targets.forEach(target => {
      console.log('[InsertOverlayTip] Processing target:', target);
      const element = elementMap.get(target.index);
      console.log('[InsertOverlayTip] Element for index', target.index, ':', element);
      if (!element) {
        console.warn('[InsertOverlayTip] No element found for index:', target.index);
        return;
      }

      const message = (target.payload?.message || '').trim();
      if (!message) {
        console.log('[InsertOverlayTip] Skipping target with empty message:', target.index);
        return;
      }
      if (visibleMessages.has(message)) {
        console.log('[InsertOverlayTip] Skipping duplicate non-sequential tooltip message:', message);
        return;
      }
      visibleMessages.add(message);

      activeCount++;

      // Store original styles
      element.classList.add('demo-preview-element');
      element.dataset.demoOriginalOutline = element.style.outline || '';
      element.dataset.demoOriginalBoxShadow = element.style.boxShadow || '';
      element.dataset.demoOriginalAnimation = element.style.animation || '';
      modifiedElements.add(element);

      // Keep the target visibly active long enough for slower walkthrough reading.
      element.style.outline = '3px solid rgba(20, 184, 166, 0.82)';
      element.style.animation = shineCycle;

      // Remove animation after the longer guided-reading window, keep outline.
      const timeoutId = setTimeout(() => {
        element.style.animation = element.dataset.demoOriginalAnimation || '';
      }, highlightDurationMs);
      timeouts.add(timeoutId);

      // Create label with message — Apple liquid design (matches sequential style)
      const label = document.createElement('div');
      label.className = 'demo-preview-element';
      label.style.cssText = `
        position: absolute;
        background: linear-gradient(135deg, rgba(248, 250, 252, 0.92) 0%, rgba(240, 253, 250, 0.9) 100%);
        backdrop-filter: blur(20px) saturate(180%);
        -webkit-backdrop-filter: blur(20px) saturate(180%);
        color: #0f172a;
        padding: 8px 28px 8px 12px;
        border-radius: 12px;
        border: 1px solid rgba(13, 148, 136, 0.35);
        font-size: 16px;
        line-height: 1.45;
        font-weight: 500;
        z-index: 10000;
        pointer-events: auto;
        box-shadow: 0 14px 36px rgba(15, 23, 42, 0.16),
                    0 6px 16px rgba(15, 23, 42, 0.1),
                    inset 0 1px 0 rgba(255, 255, 255, 0.5),
                    inset 0 -1px 0 rgba(0, 0, 0, 0.05);
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        max-width: 250px;
        word-wrap: break-word;
      `;

      const messageText = document.createElement('span');
      messageText.textContent = message;
      label.appendChild(messageText);

      // Add close button
      const closeBtn = document.createElement('button');
      closeBtn.textContent = '×';
      closeBtn.style.cssText = `
        position: absolute;
        top: 6px;
        right: 8px;
        background: transparent;
        border: none;
        color: #0f766e;
        font-size: 16px;
        line-height: 1;
        cursor: pointer;
        padding: 0;
        width: 16px;
        height: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0.6;
        transition: opacity 0.2s ease;
      `;
      const restoreElement = () => {
        if (element.dataset.demoOriginalOutline !== undefined) {
          element.style.outline = element.dataset.demoOriginalOutline;
          delete element.dataset.demoOriginalOutline;
        }
        if (element.dataset.demoOriginalBoxShadow !== undefined) {
          element.style.boxShadow = element.dataset.demoOriginalBoxShadow;
          delete element.dataset.demoOriginalBoxShadow;
        }
        if (element.dataset.demoOriginalAnimation !== undefined) {
          element.style.animation = element.dataset.demoOriginalAnimation;
          delete element.dataset.demoOriginalAnimation;
        }
        element.classList.remove('demo-preview-element');
        modifiedElements.delete(element);
      };

      closeBtn.addEventListener('click', e => {
        e.stopPropagation();
        restoreElement();
        overlays.delete(label);
        label.remove();
        maybeNotifyEmpty();
      });
      label.appendChild(closeBtn);

      // Position label near the element
      const rect = element.getBoundingClientRect();
      const position = config.position || 'top';

      switch (position) {
        case 'top':
          label.style.left = `${rect.left + window.scrollX}px`;
          label.style.bottom = `${window.innerHeight - rect.top - window.scrollY + 10}px`;
          break;
        case 'bottom':
          label.style.left = `${rect.left + window.scrollX}px`;
          label.style.top = `${rect.bottom + window.scrollY + 10}px`;
          break;
        case 'right':
          label.style.left = `${rect.right + window.scrollX + 10}px`;
          label.style.top = `${rect.top + window.scrollY}px`;
          break;
        case 'left':
          label.style.right = `${window.innerWidth - rect.left - window.scrollX + 10}px`;
          label.style.top = `${rect.top + window.scrollY}px`;
          break;
      }

      document.body.appendChild(label);
      overlays.add(label);
    });

    console.log('[InsertOverlayTip] Created', overlays.size, 'overlay elements');
    if (activeCount === 0 && !notifiedEmpty && typeof example?.__vaOnEmpty === 'function') {
      console.log('[InsertOverlayTip] No visible tooltips created, notifying...');
      notifiedEmpty = true;
      example.__vaOnEmpty();
    }

    return {
      undo: () => {
        console.log('[InsertOverlayTip] undo() called');
        notifiedEmpty = true;

        // Clear all timeouts
        timeouts.forEach(timeoutId => clearTimeout(timeoutId));
        timeouts.clear();

        // Restore all modified elements
        modifiedElements.forEach(element => {
          if (element.dataset.demoOriginalOutline !== undefined) {
            element.style.outline = element.dataset.demoOriginalOutline;
            delete element.dataset.demoOriginalOutline;
          }
          if (element.dataset.demoOriginalBoxShadow !== undefined) {
            element.style.boxShadow = element.dataset.demoOriginalBoxShadow;
            delete element.dataset.demoOriginalBoxShadow;
          }
          if (element.dataset.demoOriginalAnimation !== undefined) {
            element.style.animation = element.dataset.demoOriginalAnimation;
            delete element.dataset.demoOriginalAnimation;
          }
          element.classList.remove('demo-preview-element');
        });
        modifiedElements.clear();

        // Remove all overlay elements
        overlays.forEach(node => node.remove());
        overlays.clear();
      },
    };
  };
})();
