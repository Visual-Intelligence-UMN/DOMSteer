(() => {
  function ensureZoomStyles() {
    if (document.getElementById('demo-txgnn-zoom-style')) return;
    const style = document.createElement('style');
    style.id = 'demo-txgnn-zoom-style';
    style.className = 'demo-preview-element';
    style.textContent = `
      @keyframes demo-txgnn-zoom-pulse {
        0%, 100% {
          box-shadow:
            0 0 0 3px rgba(45, 212, 191, 0.22),
            0 0 18px 4px rgba(20, 184, 166, 0.14),
            0 14px 32px rgba(15, 118, 110, 0.16);
        }
        50% {
          box-shadow:
            0 0 0 6px rgba(45, 212, 191, 0.28),
            0 0 28px 8px rgba(20, 184, 166, 0.18),
            0 18px 40px rgba(15, 118, 110, 0.22);
        }
      }
      @keyframes demo-txgnn-zoom-target-glow {
        0%, 100% {
          box-shadow: 0 0 0 3px rgba(45, 212, 191, 0.16),
                      0 0 18px rgba(20, 184, 166, 0.12);
          outline-color: rgba(20, 184, 166, 0.55);
        }
        50% {
          box-shadow: 0 0 0 8px rgba(45, 212, 191, 0.2),
                      0 0 28px rgba(20, 184, 166, 0.18);
          outline-color: rgba(20, 184, 166, 0.92);
        }
      }
    `;
    document.head.appendChild(style);
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function buildZoomButton(label) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'demo-preview-element';
    button.textContent = label;
    button.style.cssText = `
      width: 30px;
      height: 30px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      border-radius: 8px;
      border: 1px solid rgba(20, 184, 166, 0.36);
      background: linear-gradient(135deg, rgba(236, 254, 255, 0.98) 0%, rgba(204, 251, 241, 0.94) 100%);
      color: #115e59;
      font-size: 18px;
      font-weight: 700;
      line-height: 1;
      cursor: pointer;
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      box-shadow: inset 0 1px 0 rgba(255,255,255,0.75), 0 1px 8px rgba(20, 184, 166, 0.08);
    `;
    return button;
  }

  function roundScale(value) {
    return Math.round(value * 100) / 100;
  }

  window.VADemoInsertTxgnnZoom = (example, elementMap) => {
    ensureZoomStyles();

    const target = example?.DOM_Manipulation?.targets?.[0];
    if (!target) return { undo: () => {} };

    const anchoredElement = elementMap.get(target.index);
    if (!anchoredElement) return { undo: () => {} };

    const targetElement =
      (anchoredElement.matches?.('svg.nodelink') && anchoredElement) ||
      anchoredElement.querySelector?.('svg.nodelink') ||
      anchoredElement.querySelector?.('svg') ||
      anchoredElement;

    const rect = targetElement.getBoundingClientRect();
    const floatingBar = document.querySelector('.vabrowser-floating-bar-shell, .vabrowser-floating-bar');
    const floatingBarRect = floatingBar?.getBoundingClientRect?.() || null;

    const control = document.createElement('div');
    control.className = 'demo-preview-element va-demo-txgnn-zoom';
    control.style.cssText = `
      position: absolute;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 6px;
      border-radius: 12px;
      border: 1px solid rgba(20, 184, 166, 0.34);
      background: linear-gradient(135deg, rgba(236, 254, 255, 0.98) 0%, rgba(204, 251, 241, 0.92) 100%);
      box-shadow: 0 0 0 1px rgba(45, 212, 191, 0.14), 0 14px 32px rgba(15, 118, 110, 0.16);
      backdrop-filter: blur(14px);
      -webkit-backdrop-filter: blur(14px);
      z-index: 10001;
      animation: demo-txgnn-zoom-pulse 1.7s ease-in-out infinite;
    `;

    const minusButton = buildZoomButton('−');
    const plusButton = buildZoomButton('+');
    control.append(minusButton, plusButton);

    const targetOutline = targetElement.style.outline || '';
    const targetOutlineOffset = targetElement.style.outlineOffset || '';
    const targetBoxShadow = targetElement.style.boxShadow || '';
    const targetAnimation = targetElement.style.animation || '';
    const targetTransform = targetElement.style.transform || '';
    const targetTransformOrigin = targetElement.style.transformOrigin || '';
    const targetTransition = targetElement.style.transition || '';
    targetElement.classList.add('demo-preview-element');
    targetElement.style.outline = '3px solid rgba(20, 184, 166, 0.82)';
    targetElement.style.outlineOffset = '3px';
    targetElement.style.animation = 'demo-txgnn-zoom-target-glow 1.8s ease-in-out infinite';
    targetElement.style.transformOrigin = 'top left';
    targetElement.style.transition = 'transform 180ms ease';

    let zoomScale = 1;

    const applyZoom = () => {
      targetElement.style.transform = `scale(${zoomScale})`;
      zoomBadge.textContent = `Zoom ${Math.round(zoomScale * 100)}%`;
    };

    let left = rect.left + window.scrollX + 12;
    let top = rect.top + window.scrollY + 12;

    const estimatedWidth = 82;
    const estimatedHeight = 44;
    if (
      floatingBarRect &&
      left < floatingBarRect.right + 12 &&
      left + estimatedWidth > floatingBarRect.left - 12 &&
      top < floatingBarRect.bottom + 12 &&
      top + estimatedHeight > floatingBarRect.top - 12
    ) {
      left = rect.right + window.scrollX - estimatedWidth - 12;
      top = rect.top + window.scrollY + 12;
    }

    left = clamp(left, window.scrollX + 8, window.scrollX + window.innerWidth - estimatedWidth - 8);
    top = clamp(top, window.scrollY + 8, window.scrollY + window.innerHeight - estimatedHeight - 8);

    control.style.left = `${left}px`;
    control.style.top = `${top}px`;
    document.body.appendChild(control);

    const zoomBadge = document.createElement('div');
    zoomBadge.className = 'demo-preview-element';
    zoomBadge.textContent = 'Zoom 100%';
    zoomBadge.style.cssText = `
      position: absolute;
      left: ${left}px;
      top: ${top - 26}px;
      padding: 2px 8px;
      border-radius: 999px;
      background: linear-gradient(135deg, rgba(13, 148, 136, 0.94) 0%, rgba(15, 118, 110, 0.92) 100%);
      color: #f0fdfa;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      z-index: 10001;
      pointer-events: none;
      box-shadow: 0 10px 24px rgba(15, 118, 110, 0.18);
    `;
    document.body.appendChild(zoomBadge);

    minusButton.addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      zoomScale = Math.max(0.6, roundScale(zoomScale - 0.15));
      applyZoom();
    });

    plusButton.addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      zoomScale = Math.min(1.9, roundScale(zoomScale + 0.15));
      applyZoom();
    });

    return {
      undo: () => {
        control.remove();
        zoomBadge.remove();
        targetElement.style.outline = targetOutline;
        targetElement.style.outlineOffset = targetOutlineOffset;
        targetElement.style.boxShadow = targetBoxShadow;
        targetElement.style.animation = targetAnimation;
        targetElement.style.transform = targetTransform;
        targetElement.style.transformOrigin = targetTransformOrigin;
        targetElement.style.transition = targetTransition;
      },
    };
  };
})();
