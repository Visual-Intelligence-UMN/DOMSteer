(() => {
  function createInlineRow(header, input) {
    const row = document.createElement('div');
    row.className = 'demo-preview-element';
    row.style.cssText = `
      display: grid;
      grid-template-columns: auto minmax(0, 1fr);
      align-items: center;
      justify-content: space-between;
      column-gap: 10px;
      width: 100%;
      margin: 0 0 6px;
      min-width: 0;
    `;

    const parent = header.parentNode;
    if (!parent) return null;

    parent.insertBefore(row, header);
    row.appendChild(header);
    row.appendChild(input);
    return row;
  }

  // Shared entrance animation (same ID as demoInsertInlineControl)
  function ensureControlAnimation() {
    if (document.getElementById('demo-control-animation')) return;
    const el = document.createElement('style');
    el.id = 'demo-control-animation';
    el.className = 'demo-preview-element';
    el.textContent = `
      @keyframes demo-control-backdrop-in { 0% { opacity: 0; } 100% { opacity: 1; } }
      @keyframes demo-control-glow {
        0%, 100% { box-shadow: 0 0 4px 1px rgba(20,184,166,0.28), 0 0 12px 4px rgba(20,184,166,0.1); outline-color: rgba(20,184,166,0.6); }
        50% { box-shadow: 0 0 8px 3px rgba(20,184,166,0.45), 0 0 20px 8px rgba(20,184,166,0.18); outline-color: rgba(20,184,166,1); }
      }
    `;
    document.head.appendChild(el);
  }

  function applyControlEntrance(el) {
    const backdrop = document.createElement('div');
    backdrop.className = 'demo-preview-element';
    backdrop.style.cssText =
      'position:fixed;inset:0;background:rgba(0,0,0,0.3);z-index:9998;pointer-events:none;animation:demo-control-backdrop-in 0.3s ease-out forwards;';
    document.body.appendChild(backdrop);

    const origPosition = el.style.position || '';
    const origZIndex = el.style.zIndex || '';
    const origOutline = el.style.outline || '';
    const origOutlineOffset = el.style.outlineOffset || '';
    const origBorderRadius = el.style.borderRadius || '';
    const origTransform = el.style.transform || '';
    const origBg = el.style.backgroundColor || '';

    el.style.position = 'relative';
    el.style.zIndex = '9999';
    el.style.outline = '2.5px solid rgba(20,184,166,0.9)';
    el.style.outlineOffset = '4px';
    el.style.borderRadius = el.style.borderRadius || '6px';
    el.style.transform = 'scale(1.06)';
    el.style.backgroundColor = 'rgba(240,253,250,0.96)';
    el.style.transition =
      'transform 0.4s cubic-bezier(0.22,1,0.36,1), background-color 0.4s ease, box-shadow 0.3s ease';
    el.style.animation = 'demo-control-glow 1s ease-in-out infinite';

    setTimeout(() => {
      el.style.transform = origTransform || 'scale(1)';
      el.style.backgroundColor = origBg || '';
      el.style.animation = 'none';
      el.style.outline = origOutline;
      el.style.outlineOffset = origOutlineOffset;
      el.style.boxShadow = '';
      backdrop.style.transition = 'opacity 0.4s ease-in';
      backdrop.style.opacity = '0';
      setTimeout(() => {
        el.style.position = origPosition;
        el.style.zIndex = origZIndex;
        el.style.borderRadius = origBorderRadius;
        el.style.transition = 'background 0.2s, box-shadow 0.2s, border-color 0.2s';
        backdrop.remove();
      }, 420);
    }, 1800);
  }

  function buildSearchInput() {
    ensureControlAnimation();
    const input = document.createElement('input');
    input.className = 'demo-preview-element';
    input.type = 'text';
    input.placeholder = 'Search fields';
    input.setAttribute('aria-label', 'Search fields');
    input.style.cssText = `
      width: 100%;
      min-width: 0;
      max-width: 100%;
      margin: 0;
      padding: 5px 9px;
      background: white;
      color: #111827;
      border: 1.5px solid rgba(20, 184, 166, 0.45);
      border-radius: 6px;
      font-size: 12px;
      box-sizing: border-box;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    `;
    applyControlEntrance(input);
    // Focus glow on interact
    input.addEventListener('focus', () => {
      input.style.borderColor = 'rgba(20, 184, 166, 0.8)';
      input.style.boxShadow = '0 0 6px 2px rgba(20, 184, 166, 0.25)';
    });
    input.addEventListener('blur', () => {
      input.style.borderColor = 'rgba(20, 184, 166, 0.4)';
      input.style.boxShadow = '0 0 4px 1px rgba(20, 184, 166, 0.14)';
    });
    return input;
  }

  function resolveFieldsHeader() {
    return (
      document.querySelector('h3[data-va-element-id="va-auto-id-28"]') ||
      Array.from(document.querySelectorAll('h3')).find(node => node.textContent?.trim() === 'Fields') ||
      null
    );
  }

  function resolveFieldsList(header) {
    const next = header?.nextElementSibling;
    if (!next) return null;
    if (next.matches('div.schema')) return next;
    if (next.tagName === 'DIV' && next.getAttribute('field-defs')) return next;
    return null;
  }

  window.VADemoInsertSearchBar = (example, elementMap) => {
    const targetIndex = example?.DOM_Manipulation?.targets?.[0]?.index;
    const targetElement = typeof targetIndex === 'number' ? elementMap?.get?.(targetIndex) : null;
    const header = targetElement || resolveFieldsHeader();
    if (!header) {
      console.warn('[InsertSearchBar] Fields header not found');
      return { undo: () => {} };
    }

    const list = resolveFieldsList(header);
    if (!list) {
      console.warn('[InsertSearchBar] Fields list container not found');
      return { undo: () => {} };
    }

    const items = Array.from(list.querySelectorAll('schema-list-item'));
    if (items.length === 0) {
      console.warn('[InsertSearchBar] No schema-list-item nodes found');
      return { undo: () => {} };
    }

    const input = buildSearchInput();
    const originalParent = header.parentNode;
    const originalNextSibling = header.nextSibling;
    const originalOrder = Array.from(list.children);
    const originalStyles = new Map(
      items.map(item => [
        item,
        {
          background: item.style.background || '',
          outline: item.style.outline || '',
          opacity: item.style.opacity || '',
        },
      ]),
    );

    const row = createInlineRow(header, input);
    header.style.minWidth = '0';

    const restoreStyles = () => {
      items.forEach(item => {
        const original = originalStyles.get(item);
        if (!original) return;
        item.style.background = original.background;
        item.style.outline = original.outline;
        item.style.opacity = original.opacity;
      });
    };

    const restoreOrder = () => {
      originalOrder.forEach(item => {
        if (item.parentNode === list) {
          list.appendChild(item);
        }
      });
    };

    const applyFilter = rawValue => {
      const query = String(rawValue || '')
        .trim()
        .toLowerCase();

      if (!query) {
        restoreStyles();
        restoreOrder();
        return;
      }

      const matches = [];
      const nonMatches = [];

      items.forEach(item => {
        const text = (item.textContent || '').toLowerCase();
        const isMatch = text.includes(query);

        if (isMatch) {
          item.style.background = 'rgba(20, 184, 166, 0.1)';
          item.style.outline = '2px solid rgba(20, 184, 166, 0.68)';
          item.style.opacity = '1';
          matches.push(item);
        } else {
          item.style.background = originalStyles.get(item)?.background || '';
          item.style.outline = originalStyles.get(item)?.outline || '';
          item.style.opacity = '0.45';
          nonMatches.push(item);
        }
      });

      matches.concat(nonMatches).forEach(item => {
        if (item.parentNode === list) {
          list.appendChild(item);
        }
      });
    };

    input.addEventListener('input', event => {
      applyFilter(event.target.value);
    });

    return {
      undo: () => {
        restoreStyles();
        restoreOrder();
        if (originalParent) {
          originalParent.insertBefore(header, originalNextSibling);
        }
        row?.remove();
        input.remove();
      },
    };
  };
})();
