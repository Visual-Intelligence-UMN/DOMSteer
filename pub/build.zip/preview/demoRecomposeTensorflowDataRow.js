(() => {
  function ensureAnimationStyles() {
    if (document.getElementById('va-demo-tensorflow-recompose-animation')) return;

    const style = document.createElement('style');
    style.id = 'va-demo-tensorflow-recompose-animation';
    style.className = 'demo-preview-element';
    style.textContent = `
      .va-demo-tensorflow-enter {
        opacity: 0;
        transform: translateY(18px);
      }

      .va-demo-tensorflow-enter-active {
        opacity: 1;
        transform: translateY(0);
        transition:
          opacity 260ms ease,
          transform 420ms cubic-bezier(0.22, 1, 0.36, 1);
      }
    `;
    document.head.appendChild(style);
  }

  function animateIn(element, delay = 0) {
    if (!element) return;
    element.classList.add('va-demo-tensorflow-enter');
    requestAnimationFrame(() => {
      setTimeout(() => {
        element.classList.add('va-demo-tensorflow-enter-active');
      }, delay);
    });
  }

  function rememberStyles(element, properties) {
    return Object.fromEntries(properties.map(property => [property, element.style[property] || '']));
  }

  function restoreStyles(element, styles) {
    Object.entries(styles).forEach(([property, value]) => {
      element.style[property] = value;
    });
  }

  function restoreNode(node, parent, nextSibling) {
    if (!node || !parent) return;
    if (nextSibling && nextSibling.parentNode === parent) {
      parent.insertBefore(node, nextSibling);
    } else {
      parent.appendChild(node);
    }
  }

  window.VADemoRecomposeTensorflowDataRow = example => {
    ensureAnimationStyles();
    const config = example?.DOM_Manipulation?.configuration || {};
    const main = document.querySelector('#main-part');
    const article = document.querySelector('#article-text');
    const dataCol = document.querySelector('.column.data');
    const featuresCol = document.querySelector('.column.features');
    const hiddenCol = document.querySelector('.column.hidden-layers');
    const outputCol = document.querySelector('.column.output');

    if (!dataCol || !featuresCol || !hiddenCol || !outputCol) {
      return { undo: () => {} };
    }

    const mainParent = main?.parentNode || null;
    const mainNextSibling = main?.nextSibling || null;
    const articleParent = article?.parentNode || null;
    const articleNextSibling = article?.nextSibling || null;
    const originalMainStyles = main ? rememberStyles(main, ['width', 'maxWidth', 'minWidth']) : null;
    const originalArticleStyles = article
      ? rememberStyles(article, [
          'width',
          'maxWidth',
          'minWidth',
          'marginTop',
          'position',
          'top',
          'alignSelf',
          'overflowWrap',
          'wordBreak',
          'whiteSpace',
        ])
      : null;

    let sideBySideWrap = null;
    if (main && article && mainParent) {
      sideBySideWrap = document.createElement('div');
      sideBySideWrap.id = 'va-side-by-side-wrap';
      sideBySideWrap.className = 'demo-preview-element';
      sideBySideWrap.style.cssText = `
        display: grid;
        grid-template-columns: minmax(0, 1.35fr) minmax(360px, 0.9fr);
        column-gap: 40px;
        align-items: start;
        width: calc(100vw - 48px);
        max-width: 1600px;
        margin: 0 24px 24px;
        box-sizing: border-box;
      `;

      mainParent.insertBefore(sideBySideWrap, main);
      sideBySideWrap.append(main, article);

      main.style.width = '100%';
      main.style.maxWidth = 'none';
      main.style.minWidth = '0';

      article.style.width = '100%';
      article.style.maxWidth = 'none';
      article.style.minWidth = '0';
      article.style.marginTop = '0';
      article.style.position = 'sticky';
      article.style.top = '24px';
      article.style.alignSelf = 'start';
      article.style.overflowWrap = 'break-word';
      article.style.wordBreak = 'break-word';
      article.style.whiteSpace = 'normal';

      Array.from(article.querySelectorAll('*')).forEach(element => {
        element.dataset.demoOriginalMaxWidth = element.style.maxWidth || '';
        element.dataset.demoOriginalMinWidth = element.style.minWidth || '';
        element.dataset.demoOriginalWhiteSpace = element.style.whiteSpace || '';
        element.dataset.demoOriginalOverflowWrap = element.style.overflowWrap || '';
        element.dataset.demoOriginalWordBreak = element.style.wordBreak || '';
        element.style.maxWidth = '100%';
        element.style.minWidth = '0';
        element.style.whiteSpace = 'normal';
        element.style.overflowWrap = 'break-word';
        element.style.wordBreak = 'break-word';
      });

      animateIn(sideBySideWrap);
    }

    const columnParent = dataCol.parentNode;
    const originalDataNextSibling = dataCol.nextSibling;
    const originalFeaturesNextSibling = featuresCol.nextSibling;
    const originalHiddenNextSibling = hiddenCol.nextSibling;
    const originalOutputNextSibling = outputCol.nextSibling;
    const originalColumnStyles = new Map(
      [dataCol, featuresCol, hiddenCol, outputCol].map(column => [
        column,
        rememberStyles(column, ['width', 'maxWidth', 'minWidth', 'margin', 'display']),
      ]),
    );

    const topWrap = document.createElement('div');
    topWrap.id = 'va-packed-columns-wrap';
    topWrap.className = 'demo-preview-element';
    topWrap.style.cssText = `
      width: 100%;
      margin: 0 0 56px;
    `;

    const bottomRow = document.createElement('div');
    bottomRow.id = 'va-packed-bottom-row';
    bottomRow.className = 'demo-preview-element';
    bottomRow.style.cssText = `
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1.25fr) minmax(0, 1fr);
      align-items: start;
      column-gap: 36px;
      row-gap: 34px;
      width: 100%;
      margin-top: 30px;
      padding-top: 22px;
    `;

    columnParent.insertBefore(topWrap, dataCol);
    topWrap.append(dataCol, bottomRow);
    bottomRow.append(featuresCol, hiddenCol, outputCol);

    dataCol.style.width = '100%';
    dataCol.style.maxWidth = '100%';
    dataCol.style.margin = '0';
    dataCol.style.display = 'block';

    [featuresCol, hiddenCol, outputCol].forEach(column => {
      column.style.width = '100%';
      column.style.minWidth = '0';
      column.style.margin = '0';
    });

    animateIn(topWrap, 40);
    animateIn(dataCol, 90);
    animateIn(featuresCol, 150);
    animateIn(hiddenCol, 210);
    animateIn(outputCol, 270);

    const originalDataChildren = Array.from(dataCol.children);
    const dataset = dataCol.querySelector('.ui-dataset');
    const controlsWrap = dataset?.nextElementSibling || null;
    const train = controlsWrap?.querySelector('.ui-percTrainData') || null;
    const noise = controlsWrap?.querySelector('.ui-noise') || null;
    const batch = controlsWrap?.querySelector('.ui-batchSize') || null;
    const button = controlsWrap?.querySelector('#data-regen-button') || null;
    const originalControlsChildren = controlsWrap ? Array.from(controlsWrap.children) : [];
    const dataChildStyles = new Map();
    [dataset, controlsWrap, train, noise, batch, button].filter(Boolean).forEach(element => {
      dataChildStyles.set(
        element,
        rememberStyles(element, [
          'width',
          'maxWidth',
          'margin',
          'padding',
          'display',
          'flexDirection',
          'alignSelf',
          'justifyContent',
          'gap',
          'minWidth',
          'whiteSpace',
        ]),
      );
    });

    let dataControlsRow = null;
    let controlsStack = null;
    let slidersRow = null;
    let datasetList = null;
    let originalDatasetItems = [];
    const datasetItemStyles = new Map();

    if (dataset && controlsWrap && train && noise && batch && button) {
      dataControlsRow = document.createElement('div');
      dataControlsRow.id = 'va-data-controls-row';
      dataControlsRow.className = 'demo-preview-element';
      dataControlsRow.style.cssText = `
        display: flex;
        flex-wrap: wrap;
        align-items: flex-end;
        justify-content: flex-start;
        gap: 28px;
        margin-top: 18px;
        margin-bottom: 36px;
        width: 100%;
      `;

      controlsStack = document.createElement('div');
      controlsStack.id = 'va-controls-stack';
      controlsStack.className = 'demo-preview-element';
      controlsStack.style.cssText = `
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        justify-content: flex-start;
        gap: 12px;
      `;

      slidersRow = document.createElement('div');
      slidersRow.id = 'va-sliders-row';
      slidersRow.className = 'demo-preview-element';
      slidersRow.style.cssText = `
        display: flex;
        flex-wrap: nowrap;
        align-items: flex-end;
        justify-content: flex-start;
        gap: 18px;
        min-width: fit-content;
      `;

      dataCol.appendChild(dataControlsRow);
      dataControlsRow.appendChild(dataset);
      dataControlsRow.appendChild(controlsStack);
      controlsStack.append(button, slidersRow);
      slidersRow.append(train, noise, batch);

      dataset.style.width = 'fit-content';
      dataset.style.maxWidth = '100%';
      dataset.style.margin = '0';
      dataset.style.padding = '0';
      dataset.style.display = 'flex';
      dataset.style.flexDirection = 'column';
      dataset.style.alignSelf = 'flex-start';

      const prompt = dataset.querySelector('p');
      if (prompt) {
        prompt.dataset.demoOriginalMargin = prompt.style.margin || '';
        prompt.dataset.demoOriginalFontSize = prompt.style.fontSize || '';
        prompt.dataset.demoOriginalFontWeight = prompt.style.fontWeight || '';
        prompt.style.margin = '0 0 10px';
        prompt.style.fontSize = '14px';
        prompt.style.fontWeight = '600';
      }

      datasetList = dataset.querySelector('.dataset-list');
      if (datasetList) {
        originalDatasetItems = Array.from(datasetList.children);
        originalDatasetItems.forEach(item => {
          datasetItemStyles.set(
            item,
            rememberStyles(item, ['display', 'flexDirection', 'alignItems', 'justifyContent', 'margin']),
          );
        });

        datasetList.dataset.demoOriginalDisplay = datasetList.style.display || '';
        datasetList.dataset.demoOriginalFlexWrap = datasetList.style.flexWrap || '';
        datasetList.dataset.demoOriginalAlignItems = datasetList.style.alignItems || '';
        datasetList.dataset.demoOriginalJustifyContent = datasetList.style.justifyContent || '';
        datasetList.dataset.demoOriginalGap = datasetList.style.gap || '';
        datasetList.dataset.demoOriginalWidth = datasetList.style.width || '';

        datasetList.style.display = 'flex';
        datasetList.style.flexWrap = 'wrap';
        datasetList.style.alignItems = 'center';
        datasetList.style.justifyContent = 'flex-start';
        datasetList.style.gap = '10px';
        datasetList.style.width = 'auto';

        const datasetOrder = config.datasetOrder || ['Circle', 'Exclusive or', 'Gaussian', 'Spiral'];
        const hiddenDatasets = new Set(config.hideDatasets || ['Plane', 'Multi gaussian']);
        const lookup = new Map(
          originalDatasetItems.map(item => [String(item.getAttribute('title') || '').trim(), item]),
        );

        originalDatasetItems.forEach(item => {
          const title = String(item.getAttribute('title') || '').trim();
          item.style.margin = '0';
          if (hiddenDatasets.has(title)) {
            item.style.display = 'none';
          } else {
            item.style.display = 'inline-flex';
            item.style.flexDirection = 'column';
            item.style.alignItems = 'center';
            item.style.justifyContent = 'center';
          }
        });

        datasetOrder.forEach(name => {
          const item = lookup.get(name);
          if (item) datasetList.appendChild(item);
        });
      }

      [train, noise, batch].forEach(section => {
        section.style.display = 'flex';
        section.style.flexDirection = 'column';
        section.style.justifyContent = 'flex-end';
        section.style.margin = '0';
        section.style.minWidth = '110px';
      });

      button.style.margin = '0';
      button.style.alignSelf = 'flex-start';
      button.style.whiteSpace = 'nowrap';

      controlsWrap.remove();

      animateIn(dataControlsRow, 120);
    }

    return {
      undo: () => {
        if (dataControlsRow) {
          if (datasetList) {
            originalDatasetItems.forEach(item => {
              datasetList.appendChild(item);
              restoreStyles(item, datasetItemStyles.get(item) || {});
            });
            datasetList.style.display = datasetList.dataset.demoOriginalDisplay || '';
            datasetList.style.flexWrap = datasetList.dataset.demoOriginalFlexWrap || '';
            datasetList.style.alignItems = datasetList.dataset.demoOriginalAlignItems || '';
            datasetList.style.justifyContent = datasetList.dataset.demoOriginalJustifyContent || '';
            datasetList.style.gap = datasetList.dataset.demoOriginalGap || '';
            datasetList.style.width = datasetList.dataset.demoOriginalWidth || '';
            delete datasetList.dataset.demoOriginalDisplay;
            delete datasetList.dataset.demoOriginalFlexWrap;
            delete datasetList.dataset.demoOriginalAlignItems;
            delete datasetList.dataset.demoOriginalJustifyContent;
            delete datasetList.dataset.demoOriginalGap;
            delete datasetList.dataset.demoOriginalWidth;
          }

          controlsStack?.remove();
          slidersRow?.remove();
          dataControlsRow.remove();

          if (controlsWrap) {
            originalControlsChildren.forEach(child => controlsWrap.appendChild(child));
          }

          originalDataChildren.forEach(child => dataCol.appendChild(child));

          dataChildStyles.forEach((styles, element) => restoreStyles(element, styles));
          const prompt = dataset?.querySelector('p');
          if (prompt) {
            prompt.style.margin = prompt.dataset.demoOriginalMargin || '';
            prompt.style.fontSize = prompt.dataset.demoOriginalFontSize || '';
            prompt.style.fontWeight = prompt.dataset.demoOriginalFontWeight || '';
            delete prompt.dataset.demoOriginalMargin;
            delete prompt.dataset.demoOriginalFontSize;
            delete prompt.dataset.demoOriginalFontWeight;
          }
        }

        topWrap.remove();

        restoreNode(dataCol, columnParent, originalDataNextSibling);
        restoreNode(featuresCol, columnParent, originalFeaturesNextSibling);
        restoreNode(hiddenCol, columnParent, originalHiddenNextSibling);
        restoreNode(outputCol, columnParent, originalOutputNextSibling);

        originalColumnStyles.forEach((styles, column) => restoreStyles(column, styles));
        [dataCol, featuresCol, hiddenCol, outputCol].forEach(column => {
          column.classList.remove('va-demo-tensorflow-enter');
          column.classList.remove('va-demo-tensorflow-enter-active');
        });

        if (sideBySideWrap) {
          sideBySideWrap.remove();
          restoreNode(main, mainParent, mainNextSibling);
          restoreNode(article, articleParent, articleNextSibling);
          if (main && originalMainStyles) restoreStyles(main, originalMainStyles);
          if (article && originalArticleStyles) restoreStyles(article, originalArticleStyles);

          if (article) {
            Array.from(article.querySelectorAll('*')).forEach(element => {
              element.style.maxWidth = element.dataset.demoOriginalMaxWidth || '';
              element.style.minWidth = element.dataset.demoOriginalMinWidth || '';
              element.style.whiteSpace = element.dataset.demoOriginalWhiteSpace || '';
              element.style.overflowWrap = element.dataset.demoOriginalOverflowWrap || '';
              element.style.wordBreak = element.dataset.demoOriginalWordBreak || '';
              delete element.dataset.demoOriginalMaxWidth;
              delete element.dataset.demoOriginalMinWidth;
              delete element.dataset.demoOriginalWhiteSpace;
              delete element.dataset.demoOriginalOverflowWrap;
              delete element.dataset.demoOriginalWordBreak;
            });
          }
        }

        topWrap.classList.remove('va-demo-tensorflow-enter');
        topWrap.classList.remove('va-demo-tensorflow-enter-active');
      },
    };
  };
})();
