(() => {
  function anchorRect(anchor) {
    if (!anchor) return null;
    if (anchor.nodeType === Node.TEXT_NODE) {
      const range = document.createRange();
      range.selectNodeContents(anchor);
      const rects = range.getClientRects();
      return rects && rects[0] ? rects[0] : null;
    }
    if (anchor.getBoundingClientRect) {
      return anchor.getBoundingClientRect();
    }
    return null;
  }

  window.VADecorateDOM = plan => {
    console.log('[VA] Decorate DOM: plan', plan);
    const anchors = plan?.anchors || [];
    const durationMs = plan?.lifecycle?.durationMs;
    const boxes = [];
    const timeouts = new Set();
    const intervals = new Set();
    const intervalByBox = new Map();
    let notifiedEmpty = false;
    const maybeNotifyEmpty = () => {
      if (!notifiedEmpty && boxes.length === 0 && typeof plan?.__vaOnEmpty === 'function') {
        notifiedEmpty = true;
        plan.__vaOnEmpty();
      }
    };
    const removeBox = box => {
      const index = boxes.indexOf(box);
      if (index !== -1) {
        boxes.splice(index, 1);
      }
      const intervalId = intervalByBox.get(box);
      if (intervalId) {
        clearInterval(intervalId);
        intervals.delete(intervalId);
        intervalByBox.delete(box);
      }
      box.remove();
      maybeNotifyEmpty();
    };
    anchors.forEach(anchor => {
      const rect = anchorRect(anchor);
      if (!rect) return;
      const box = document.createElement('div');
      box.style.position = 'fixed';
      box.style.left = `${rect.left}px`;
      box.style.top = `${rect.top}px`;
      box.style.width = `${rect.width}px`;
      box.style.height = `${rect.height}px`;
      box.style.border = '2px solid #38bdf8';
      box.style.boxShadow = '0 0 0 4px rgba(56, 189, 248, 0.2)';
      box.style.borderRadius = '8px';
      box.style.pointerEvents = 'none';
      box.style.boxSizing = 'border-box';
      box.style.zIndex = '2147483647';
      box.dataset.vaAssist = 'decorate';
      document.body.appendChild(box);
      boxes.push(box);

      if (durationMs) {
        const badge = document.createElement('div');
        const totalSeconds = Math.ceil(durationMs / 1000);
        badge.textContent = `${totalSeconds}s`;
        badge.style.position = 'absolute';
        badge.style.top = '-8px';
        badge.style.right = '-8px';
        badge.style.padding = '2px 6px';
        badge.style.borderRadius = '999px';
        badge.style.background = 'rgba(15, 23, 42, 0.95)';
        badge.style.color = '#e2e8f0';
        badge.style.fontSize = '10px';
        badge.style.lineHeight = '1';
        badge.style.fontFamily = 'Inter, system-ui, -apple-system, sans-serif';
        badge.style.border = '1px solid rgba(148, 163, 184, 0.35)';
        box.appendChild(badge);

        const start = Date.now();
        const intervalId = window.setInterval(() => {
          const elapsed = Date.now() - start;
          const remaining = Math.max(0, durationMs - elapsed);
          badge.textContent = `${Math.ceil(remaining / 1000)}s`;
        }, 250);
        intervals.add(intervalId);
        intervalByBox.set(box, intervalId);

        const timeoutId = window.setTimeout(() => {
          removeBox(box);
        }, durationMs);
        timeouts.add(timeoutId);
      }
    });

    return {
      undo: () => {
        notifiedEmpty = true;
        timeouts.forEach(timeoutId => clearTimeout(timeoutId));
        intervals.forEach(intervalId => clearInterval(intervalId));
        intervalByBox.clear();
        boxes.forEach(box => box.remove());
        boxes.length = 0;
      },
    };
  };
})();
