(() => {
  function resolveAnchor(target, selectorMapData, textNodeMapData) {
    if (!target) return null;
    if (target.kind === 'interactive') {
      const selector = selectorMapData?.[target.index];
      if (!selector) return null;
      try {
        return document.querySelector(selector);
      } catch (err) {
        return null;
      }
    }
    if (target.kind === 'text') {
      const entry = textNodeMapData?.[target.index];
      if (!entry?.selector || !entry?.text) return null;
      let container = null;
      try {
        container = document.querySelector(entry.selector);
      } catch (err) {
        container = null;
      }
      if (!container) return null;
      const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
      let current = walker.nextNode();
      while (current) {
        if (current.textContent && current.textContent.includes(entry.text)) {
          return current;
        }
        current = walker.nextNode();
      }
      return null;
    }
    return null;
  }

  function getLifecycleDefaults(type) {
    if (type === 'dom_guidance') {
      return { trigger: 'hover', dismissable: true };
    }
    if (type === 'dom_highlight') {
      return { trigger: 'immediate', durationMs: 6000 };
    }
    if (type === 'direct_action') {
      return { trigger: 'immediate' };
    }
    return { trigger: 'immediate', dismissable: true };
  }

  function resolveStrategy(opportunity) {
    const type = opportunity?.type;
    const targets = Array.isArray(opportunity?.targets) ? opportunity.targets : [];
    const hasTextTarget = targets.some(target => target.kind === 'text');

    if (type === 'direct_action') return 'actuate';
    if (type === 'dom_highlight') return 'decorate';
    if (type === 'dom_guidance') return hasTextTarget ? 'overlay' : 'decorate';
    if (type === 'dom_annotation') return hasTextTarget ? 'mutate' : 'overlay';
    if (type === 'dom_rearrange' || type === 'dom_filter_view') return 'mutate';
    return 'overlay';
  }

  window.VAAdaptAssistance = (opportunity, selectorMapData, textNodeMapData) => {
    console.log('[VA] Adapt Assistance: opportunity', opportunity);
    const targets = Array.isArray(opportunity?.targets) ? opportunity.targets : [];
    const anchors = targets.map(target => resolveAnchor(target, selectorMapData, textNodeMapData)).filter(Boolean);

    if (!anchors.length) {
      return [];
    }

    const plan = {
      strategy: resolveStrategy(opportunity),
      anchors,
      payload: {
        text: opportunity?.action || '',
      },
      lifecycle: getLifecycleDefaults(opportunity?.type),
    };

    return [plan];
  };
})();
