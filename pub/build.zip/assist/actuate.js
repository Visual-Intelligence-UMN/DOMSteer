(() => {
  window.VAActuateDOM = plan => {
    const message = plan?.payload?.text || '';
    console.log('[VA] Actuate plan:', message, plan);
    return { undo: () => {} };
  };
})();
