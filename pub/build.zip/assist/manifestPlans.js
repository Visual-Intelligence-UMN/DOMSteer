(() => {
  function notifyPreviewCleared() {
    try {
      if (typeof chrome !== 'undefined' && chrome?.runtime?.sendMessage) {
        chrome.runtime.sendMessage({ type: 'preview_opportunity_cleared' });
      }
    } catch (error) {
      // ignore
    }
  }

  function renderPlan(plan) {
    switch (plan?.strategy) {
      case 'decorate':
        return window.VADecorateDOM?.(plan);
      case 'mutate':
        return window.VAMutateDOM?.(plan);
      case 'actuate':
        return window.VAActuateDOM?.(plan);
      case 'overlay':
      default:
        return window.VARenderOverlay?.(plan);
    }
  }

  window.VARenderOverlayPlans = (plans, _rootDom) => {
    if (!Array.isArray(plans)) {
      return { undo: () => {} };
    }

    let autoClearCount = 0;
    let clearedCount = 0;
    const onPlanEmpty = () => {
      clearedCount += 1;
      if (clearedCount >= autoClearCount) {
        notifyPreviewCleared();
      }
    };

    const handles = plans
      .map(plan => {
        const shouldTrack = plan?.strategy === 'overlay' || plan?.strategy === 'decorate';
        if (shouldTrack) {
          autoClearCount += 1;
          plan.__vaOnEmpty = onPlanEmpty;
        }
        return renderPlan(plan);
      })
      .filter(handle => handle && typeof handle.undo === 'function');

    return {
      undo: () => {
        handles.forEach(handle => handle.undo());
        handles.length = 0;
      },
    };
  };

  window.VAAssistRenderManager = window.VAAssistRenderManager || {
    active: null,
    preview(plans, rootDom) {
      this.clear();
      this.active = window.VARenderOverlayPlans?.(plans, rootDom) || null;
    },
    clear() {
      if (this.active) {
        this.active.undo();
        this.active = null;
      }
    },
  };

  window.VAClearAssistance = () => {
    window.VAAssistRenderManager?.clear?.();
  };

  window.VAManifestPlans = (plans, rootDom) => {
    window.VAAssistRenderManager?.preview(plans, rootDom);
  };
})();
