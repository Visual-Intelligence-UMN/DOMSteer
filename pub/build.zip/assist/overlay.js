(() => {
  function anchorRect(anchor) {
    if (!anchor) return null;
    if (anchor.nodeType === Node.TEXT_NODE) {
      const range = document.createRange();
      range.selectNodeContents(anchor);
      const rects = range.getClientRects();
      return rects && rects[0] ? rects[0] : null;
    }
    if (anchor.getBoundingClientRect) {
      return anchor.getBoundingClientRect();
    }
    return null;
  }

  window.VARenderOverlay = plan => {
    console.log('[VA] Render Overlay: plan', plan);
    const anchors = plan?.anchors || [];
    const trigger = plan?.lifecycle?.trigger || 'immediate';
    const durationMs = plan?.lifecycle?.durationMs;
    const overlays = new Set();
    const timeouts = new Set();
    const listenerCleanup = [];
    let notifiedEmpty = false;
    const maybeNotifyEmpty = () => {
      if (!notifiedEmpty && overlays.size === 0 && typeof plan?.__vaOnEmpty === 'function') {
        notifiedEmpty = true;
        plan.__vaOnEmpty();
      }
    };
    const removeOverlay = container => {
      if (!container) return;
      overlays.delete(container);
      container.remove();
      maybeNotifyEmpty();
    };
    const showOverlay = (anchor, payloadText) => {
      const rect = anchorRect(anchor);
      if (!rect) return;
      const container = document.createElement('div');
      const closeBtn = document.createElement('button');
      container.style.position = 'fixed';
      container.style.left = `${rect.left}px`;
      container.style.top = `${Math.max(0, rect.top - 32)}px`;
      container.style.maxWidth = '260px';
      container.style.padding = '6px 8px';
      container.style.fontSize = '11px';
      container.style.borderRadius = '8px';
      container.style.background = 'rgba(15, 23, 42, 0.95)';
      container.style.color = '#e2e8f0';
      container.style.border = '1px solid rgba(148, 163, 184, 0.35)';
      container.style.fontFamily = 'Inter, system-ui, -apple-system, sans-serif';
      container.style.zIndex = '2147483647';
      container.style.pointerEvents = 'auto';
      container.textContent = payloadText || plan?.payload?.text || '';

      closeBtn.type = 'button';
      closeBtn.textContent = '×';
      closeBtn.style.position = 'absolute';
      closeBtn.style.top = '2px';
      closeBtn.style.right = '6px';
      closeBtn.style.border = 'none';
      closeBtn.style.background = 'transparent';
      closeBtn.style.color = '#e2e8f0';
      closeBtn.style.cursor = 'pointer';
      closeBtn.style.fontSize = '12px';
      closeBtn.style.lineHeight = '1';
      closeBtn.addEventListener('click', () => removeOverlay(container));

      container.appendChild(closeBtn);
      document.body.appendChild(container);
      overlays.add(container);

      if (durationMs) {
        const timeoutId = window.setTimeout(() => {
          removeOverlay(container);
        }, durationMs);
        timeouts.add(timeoutId);
      }
      return container;
    };

    // Use per-anchor payloads if available (for dom_annotation)
    const perAnchorPayloads = plan?.perAnchorPayloads || [];

    anchors.forEach((anchor, index) => {
      // Use per-anchor payload if available, otherwise fall back to general payload
      const payloadText = perAnchorPayloads[index] || plan?.payload?.text || '';
      showOverlay(anchor, payloadText);
    });

    return {
      undo: () => {
        notifiedEmpty = true;
        listenerCleanup.forEach(clean => clean());
        timeouts.forEach(timeoutId => clearTimeout(timeoutId));
        overlays.forEach(node => node.remove());
        overlays.clear();
      },
    };
  };
})();
