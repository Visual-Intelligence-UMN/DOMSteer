(() => {
  function anchorElement(anchor) {
    if (!anchor) return null;
    if (anchor.nodeType === Node.TEXT_NODE) {
      return anchor.parentElement;
    }
    return anchor;
  }

  window.VAMutateDOM = plan => {
    const anchors = plan?.anchors || [];
    const mutated = [];
    anchors.forEach(anchor => {
      const element = anchorElement(anchor);
      if (!element) return;
      mutated.push({
        element,
        outline: element.style.outline,
        outlineOffset: element.style.outlineOffset,
        vaMutated: element.dataset.vaMutated,
        vaAssist: element.dataset.vaAssist,
      });
      element.dataset.vaMutated = 'true';
      element.dataset.vaAssist = 'mutate';
      element.style.outline = '2px dashed rgba(234, 179, 8, 0.9)';
      element.style.outlineOffset = '2px';
    });

    return {
      undo: () => {
        mutated.forEach(entry => {
          entry.element.style.outline = entry.outline;
          entry.element.style.outlineOffset = entry.outlineOffset;
          if (entry.vaMutated === undefined) {
            delete entry.element.dataset.vaMutated;
          } else {
            entry.element.dataset.vaMutated = entry.vaMutated;
          }
          if (entry.vaAssist === undefined) {
            delete entry.element.dataset.vaAssist;
          } else {
            entry.element.dataset.vaAssist = entry.vaAssist;
          }
        });
        mutated.length = 0;
      },
    };
  };
})();
