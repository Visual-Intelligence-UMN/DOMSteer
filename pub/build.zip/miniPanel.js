(() => {
  const MINI_PANEL_ID = 'nanobrowser-mini-panel';
  const PANEL_Z_INDEX = 2147483646; // Just under the highlight overlay (2147483647)

  /**
   * Adds or updates a minimal side panel that sits above the page and shows the total number of highlighted elements.
   *
   * @param {number} totalInteractive - Total highlighted interactive elements.
   */
  function attachDrag(dragHandle, host) {
    if (!dragHandle || !host) return;

    const clamp = (val, min, max) => Math.max(min, Math.min(val, max));

    const startDrag = event => {
      event.preventDefault();
      event.stopPropagation();

      const hostRect = host.getBoundingClientRect();
      const startX = event.clientX;
      const startY = event.clientY;
      const startLeft = hostRect.left;
      const startTop = hostRect.top;

      const onMove = moveEvent => {
        moveEvent.preventDefault();
        moveEvent.stopPropagation();

        const deltaX = moveEvent.clientX - startX;
        const deltaY = moveEvent.clientY - startY;

        const nextLeft = clamp(startLeft + deltaX, 0, window.innerWidth - hostRect.width);
        const nextTop = clamp(startTop + deltaY, 0, window.innerHeight - hostRect.height);

        host.style.left = `${nextLeft}px`;
        host.style.top = `${nextTop}px`;
        host.style.right = '';
      };

      const endDrag = () => {
        window.removeEventListener('mousemove', onMove, true);
        window.removeEventListener('mouseup', endDrag, true);
      };

      window.addEventListener('mousemove', onMove, true);
      window.addEventListener('mouseup', endDrag, true);
    };

    // Mouse drag
    dragHandle.addEventListener('mousedown', startDrag);

    // Touch drag
    dragHandle.addEventListener(
      'touchstart',
      e => {
        if (e.touches.length === 0) return;
        const touch = e.touches[0];
        startDrag({
          clientX: touch.clientX,
          clientY: touch.clientY,
          preventDefault: () => e.preventDefault(),
          stopPropagation: () => e.stopPropagation(),
        });
      },
      { passive: false },
    );

    dragHandle.dataset.dragBound = 'true';
  }

  function renderMiniPanel(totalInteractive) {
    let isTopContext = true;
    try {
      isTopContext = window.top === window;
    } catch (e) {
      isTopContext = false;
    }
    if (!isTopContext) return;

    const existingHost = document.getElementById(MINI_PANEL_ID);
    if (existingHost) {
      const countEl = existingHost.querySelector('[data-interactive-count]');
      if (countEl) countEl.textContent = String(totalInteractive);

      // Ensure drag is wired if this host was created before drag support
      const existingHeader = existingHost.querySelector('[data-mini-panel-header]');
      if (existingHeader && !existingHeader.dataset.dragBound) {
        attachDrag(existingHeader, existingHost);
      }
      existingHost.style.pointerEvents = 'auto';
      return;
    }

    const host = document.createElement('div');
    host.id = MINI_PANEL_ID;
    host.style.position = 'fixed';
    host.style.top = '12px';
    host.style.right = '12px';
    host.style.zIndex = String(PANEL_Z_INDEX);
    host.style.pointerEvents = 'auto';
    host.style.fontFamily = 'Inter, system-ui, -apple-system, sans-serif';
    host.style.touchAction = 'none';

    const panel = document.createElement('div');
    panel.style.pointerEvents = 'auto';
    panel.style.background = 'rgba(15, 23, 42, 0.95)';
    panel.style.color = '#f8fafc';
    panel.style.borderRadius = '12px';
    panel.style.border = '1px solid rgba(255, 255, 255, 0.08)';
    panel.style.boxShadow = '0 12px 30px rgba(0, 0, 0, 0.25)';
    panel.style.minWidth = '220px';
    panel.style.maxWidth = '260px';
    panel.style.overflow = 'hidden';
    panel.style.transition = 'width 160ms ease, height 160ms ease, opacity 140ms ease';
    panel.dataset.state = 'expanded';

    const header = document.createElement('div');
    header.style.display = 'flex';
    header.style.alignItems = 'center';
    header.style.justifyContent = 'space-between';
    header.style.gap = '8px';
    header.style.padding = '10px 12px';
    header.style.fontSize = '13px';
    header.style.fontWeight = '600';
    header.style.cursor = 'move';
    header.dataset.miniPanelHeader = 'true';
    header.textContent = 'Interactive elements';

    const toggleBtn = document.createElement('button');
    toggleBtn.type = 'button';
    toggleBtn.textContent = 'Collapse';
    toggleBtn.style.background = '#0ea5e9';
    toggleBtn.style.color = '#0b1021';
    toggleBtn.style.border = 'none';
    toggleBtn.style.borderRadius = '8px';
    toggleBtn.style.padding = '4px 10px';
    toggleBtn.style.fontSize = '12px';
    toggleBtn.style.cursor = 'pointer';

    const body = document.createElement('div');
    body.style.padding = '0 12px 12px';
    body.style.fontSize = '13px';
    body.style.lineHeight = '1.4';

    const countRow = document.createElement('div');
    countRow.textContent = 'Total highlighted: ';
    countRow.style.display = 'flex';
    countRow.style.alignItems = 'baseline';
    countRow.style.gap = '6px';

    const countValue = document.createElement('strong');
    countValue.dataset.interactiveCount = 'true';
    countValue.textContent = String(totalInteractive);
    countValue.style.fontSize = '16px';
    countValue.style.letterSpacing = '0.2px';

    countRow.appendChild(countValue);
    body.appendChild(countRow);

    const applyState = state => {
      panel.dataset.state = state;
      if (state === 'collapsed') {
        panel.style.width = '70px';
        panel.style.height = '44px';
        body.style.display = 'none';
        toggleBtn.textContent = 'Expand';
      } else {
        panel.style.width = '';
        panel.style.height = '';
        body.style.display = 'block';
        toggleBtn.textContent = 'Collapse';
      }
    };

    toggleBtn.addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      const nextState = panel.dataset.state === 'expanded' ? 'collapsed' : 'expanded';
      applyState(nextState);
    });

    attachDrag(header, host);

    header.appendChild(toggleBtn);
    panel.appendChild(header);
    panel.appendChild(body);
    host.appendChild(panel);
    document.body.appendChild(host);

    applyState('expanded');
  }

  // window.renderMiniPanel = renderMiniPanel;
})();
