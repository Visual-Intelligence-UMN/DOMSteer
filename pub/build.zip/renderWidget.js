(() => {
  const GENERATED_WIDGET_ID = 'nanobrowser-generated-widget';
  const PANEL_Z_INDEX = 2147483646; // Same layer as mini panel

  function buildPreviewSrcdoc(content) {
    return `
  <!doctype html>
  <html>
    <head>
      <meta charset="utf-8" />
      <style>
        :root { color-scheme: light dark; }
        body { margin: 0; padding: 12px; font-family: Inter, system-ui, -apple-system, sans-serif; background: #0f172a; color: #e2e8f0; }
        button { cursor: pointer; }
        * { box-sizing: border-box; }
        #root { min-height: 120px; }
        pre { margin: 0; }
      </style>
    </head>
    <body>
      <div id="root"></div>
      <script crossorigin src="https://unpkg.com/react@18/umd/react.development.js"></script>
      <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
      <script crossorigin src="https://unpkg.com/@babel/standalone@7.23.9/babel.min.js"></script>
      <script type="text/babel" data-presets="react" data-plugins="transform-modules-umd">
        const render = element => {
          const rootEl = document.getElementById('root');
          if (!rootEl.__root) {
            rootEl.__root = ReactDOM.createRoot(rootEl);
          }
          rootEl.__root.render(element);
        };
        try {
  ${content}
        } catch (err) {
          const rootEl = document.getElementById('root');
          rootEl.innerHTML = '<pre style="color:#f87171">Error: ' + (err?.message || err) + '</pre>';
          console.error('Preview error:', err);
        }
      </script>
    </body>
  </html>`;
  }

  /**
   * Renders a simple draggable widget that shows generated code (or any string content).
   *
   * @param {string} content - The code or text to display.
   */
  function renderGeneratedWidget(content) {
    const test_content =
      // `
      //   function Widget() {
      //     const [value, setValue] = React.useState(0);
      //     return (
      //       <>
      //         <h2>Counter</h2>
      //         <p>{value}</p>
      //         <button onClick={() => setValue(value + 1)}>Increment</button>
      //       </>
      //     );
      //   }
      //   `;
      `
    function InterpreteChart() {
      const [imageDataUrl, setImageDataUrl] = React.useState(null);
      const [isLoading, setIsLoading] = React.useState(false);
      const [result, setResult] = React.useState(null);
      const chartRef = React.useRef(null);


      const OPENAI_API_KEY = ""  
        
      // Take a screenshot of the chart area
      const handleScreenshot = async () => {
        if (!chartRef.current) return;
    
        try {
          const html2canvas = window.html2canvas;
          if (!html2canvas) {
            console.error("html2canvas is not available on window");
            alert("Screenshot capture is not available in this environment.");
            return;
          }
    
          const canvas = await html2canvas(chartRef.current);
          const dataUrl = canvas.toDataURL("image/png");
          setImageDataUrl(dataUrl);
          setResult(null);
        } catch (err) {
          console.error("Failed to capture screenshot", err);
          alert("Failed to capture screenshot.");
        }
      };
    
      // Submit the screenshot directly to OpenAI for interpretation
      const handleInterpret = async () => {
        if (!imageDataUrl) {
          alert("Please take a screenshot first.");
          return;
        }
    
        if (!OPENAI_API_KEY || OPENAI_API_KEY === "YOUR_OPENAI_API_KEY") {
          alert("Please set your OpenAI API key in the code.");
          return;
        }
    
        setIsLoading(true);
        setResult(null);
    
        try {
          const res = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": "Bearer " + OPENAI_API_KEY
            },
            body: JSON.stringify({
              model: "gpt-4o",
              messages: [
                {
                  role: "user",
                  content: [
                    {
                      type: "text",
                      text:
                        "Interpret this chart. Provide a brief summary, key trends, and any notable anomalies."
                    },
                    {
                      type: "image_url",
                      image_url: {
                        url: imageDataUrl
                      }
                    }
                  ]
                }
              ],
              max_tokens: 400
            })
          });
    
          if (!res.ok) {
            console.error("OpenAI error status:", res.status);
            throw new Error("OpenAI API error");
          }
    
          const data = await res.json();
          var message =
            data &&
            data.choices &&
            data.choices[0] &&
            data.choices[0].message &&
            data.choices[0].message.content;
    
          if (!message) {
            message = "No response from the model.";
          }
    
          setResult(message);
        } catch (err) {
          console.error(err);
          setResult("Error interpreting chart.");
        } finally {
          setIsLoading(false);
        }
      };
    
      return (
        <>
          <h2>Interpret Chart</h2>
    
          {/* This is the area you want to screenshot */}
          <div
            ref={chartRef}
            style={{
              border: "1px solid #ccc",
              padding: "16px",
              marginBottom: "12px"
            }}
          >
            {/* Your chart component goes here */}
            <p>Chart goes here…</p>
          </div>
    
          <div style={{ display: "flex", gap: "8px", marginBottom: "12px" }}>
            <button onClick={handleScreenshot}>
              Take screenshot
            </button>
    
            <button
              onClick={handleInterpret}
              disabled={!imageDataUrl || isLoading}
            >
              {isLoading ? "Interpreting..." : "Interpret chart with LLM"}
            </button>
          </div>
    
          {imageDataUrl && (
            <div style={{ marginBottom: "12px" }}>
              <h3>Captured image preview</h3>
              <img
                src={imageDataUrl}
                alt="Chart screenshot"
                style={{ maxWidth: "100%", maxHeight: "200px" }}
              />
            </div>
          )}
    
          {result && (
            <div>
              <h3>LLM Interpretation</h3>
              <p>{result}</p>
            </div>
          )}
        </>
      );
    }
    
    render(<InterpreteChart />);
    `;

    let isTopContext = true;
    try {
      isTopContext = window.top === window;
    } catch (e) {
      isTopContext = false;
    }
    if (!isTopContext) return;

    let widget = document.getElementById(GENERATED_WIDGET_ID);
    if (!widget) {
      widget = document.createElement('div');
      widget.id = GENERATED_WIDGET_ID;
      widget.style.position = 'fixed';
      widget.style.top = '70px';
      widget.style.right = '12px';
      widget.style.zIndex = String(PANEL_Z_INDEX);
      widget.style.pointerEvents = 'auto';
      widget.style.fontFamily = 'Inter, system-ui, -apple-system, sans-serif';
      widget.style.touchAction = 'none';

      const shell = document.createElement('div');
      shell.style.pointerEvents = 'auto';
      shell.style.background = 'rgba(15, 23, 42, 0.95)';
      shell.style.color = '#e2e8f0';
      shell.style.borderRadius = '12px';
      shell.style.border = '1px solid rgba(255, 255, 255, 0.08)';
      shell.style.boxShadow = '0 12px 30px rgba(0, 0, 0, 0.25)';
      shell.style.minWidth = '220px';
      shell.style.maxWidth = '320px';
      shell.style.maxHeight = '420px';
      shell.style.overflow = 'hidden';

      const header = document.createElement('div');
      header.style.display = 'flex';
      header.style.alignItems = 'center';
      header.style.justifyContent = 'space-between';
      header.style.gap = '8px';
      header.style.padding = '10px 12px';
      header.style.fontSize = '13px';
      header.style.fontWeight = '600';
      header.style.cursor = 'move';
      header.dataset.generatedWidgetHeader = 'true';
      header.textContent = 'Generated code';

      const buttonRow = document.createElement('div');
      buttonRow.style.display = 'flex';
      buttonRow.style.gap = '6px';

      const copyBtn = document.createElement('button');
      copyBtn.type = 'button';
      copyBtn.textContent = 'Copy';
      copyBtn.style.background = '#0ea5e9';
      copyBtn.style.color = '#0b1021';
      copyBtn.style.border = 'none';
      copyBtn.style.borderRadius = '8px';
      copyBtn.style.padding = '4px 10px';
      copyBtn.style.fontSize = '12px';
      copyBtn.style.cursor = 'pointer';
      copyBtn.addEventListener('click', e => {
        e.preventDefault();
        e.stopPropagation();
        navigator.clipboard?.writeText(test_content).catch(() => {});
      });

      const closeBtn = document.createElement('button');
      closeBtn.type = 'button';
      closeBtn.textContent = 'Hide';
      closeBtn.style.background = 'transparent';
      closeBtn.style.color = '#cbd5e1';
      closeBtn.style.border = '1px solid rgba(255, 255, 255, 0.12)';
      closeBtn.style.borderRadius = '8px';
      closeBtn.style.padding = '4px 10px';
      closeBtn.style.fontSize = '12px';
      closeBtn.style.cursor = 'pointer';
      closeBtn.addEventListener('click', e => {
        e.preventDefault();
        e.stopPropagation();
        widget.remove();
      });

      buttonRow.appendChild(copyBtn);
      buttonRow.appendChild(closeBtn);
      header.appendChild(buttonRow);

      const body = document.createElement('div');
      body.style.padding = '0 12px 12px';
      body.dataset.generatedBody = 'true';

      const previewLabel = document.createElement('div');
      previewLabel.textContent = 'Preview';
      previewLabel.style.fontSize = '12px';
      previewLabel.style.color = '#cbd5e1';
      previewLabel.style.margin = '0 0 6px 2px';
      body.appendChild(previewLabel);

      const previewFrame = document.createElement('iframe');
      previewFrame.dataset.generatedPreview = 'true';
      previewFrame.style.width = '100%';
      previewFrame.style.height = '200px';
      previewFrame.style.border = '1px solid rgba(255, 255, 255, 0.1)';
      previewFrame.style.borderRadius = '10px';
      previewFrame.style.background = '#0f172a';
      previewFrame.style.marginBottom = '10px';
      previewFrame.sandbox = 'allow-scripts allow-same-origin';
      body.appendChild(previewFrame);

      const codeWrapper = document.createElement('pre');
      codeWrapper.style.margin = '0';
      codeWrapper.style.padding = '10px';
      codeWrapper.style.background = 'rgba(15, 23, 42, 0.6)';
      codeWrapper.style.borderRadius = '10px';
      codeWrapper.style.maxHeight = '160px';
      codeWrapper.style.overflow = 'auto';
      codeWrapper.style.fontSize = '12px';
      codeWrapper.style.lineHeight = '1.5';
      codeWrapper.style.whiteSpace = 'pre-wrap';
      codeWrapper.style.wordBreak = 'break-word';
      codeWrapper.dataset.generatedCode = 'true';
      body.appendChild(codeWrapper);

      shell.appendChild(header);
      shell.appendChild(body);
      widget.appendChild(shell);
      document.body.appendChild(widget);
    }

    const iframe = widget.querySelector('iframe[data-generated-preview]');
    const codeBlock = widget.querySelector('[data-generated-code]');

    if (iframe) {
      iframe.removeAttribute('src');
      iframe.srcdoc = buildPreviewSrcdoc(test_content);
    }
    if (codeBlock) {
      codeBlock.textContent = test_content;
    }

    widget.style.pointerEvents = 'auto';
  }

  window.renderGeneratedWidget = renderGeneratedWidget;
})();
