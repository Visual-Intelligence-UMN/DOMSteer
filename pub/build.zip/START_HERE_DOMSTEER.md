# DOMSteer Quick Start

1. Unzip the extension folder build.zip
2. Open `chrome://extensions/`
3. Turn on `Developer mode`
4. Click `Load unpacked`
5. Select the unzipped folder
6. Pin `DOMSteer`
7. Open DOMSteer
8. Paste your OpenAI API key in `Settings` or `API Setup`
9. Open any `http://` or `https://` webpage
10. Ask a question about the interface

If the floating bar is enabled:
- `Cmd+Shift+Y` on Mac
- `Ctrl+Shift+Y` on Windows/Linux

If it does not work:
- reload the extension in `chrome://extensions/`
- refresh the webpage
