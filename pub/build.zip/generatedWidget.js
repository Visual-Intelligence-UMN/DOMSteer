(() => {
  const GENERATED_WIDGET_ID = 'nanobrowser-generated-widget';
  const PANEL_Z_INDEX = 2147483646; // Same layer as mini panel

  function attachDrag(dragHandle, host) {
    if (!dragHandle || !host) return;

    const clamp = (val, min, max) => Math.max(min, Math.min(val, max));

    const startDrag = event => {
      event.preventDefault();
      event.stopPropagation();

      const hostRect = host.getBoundingClientRect();
      const startX = event.clientX;
      const startY = event.clientY;
      const startLeft = hostRect.left;
      const startTop = hostRect.top;

      const onMove = moveEvent => {
        moveEvent.preventDefault();
        moveEvent.stopPropagation();

        const deltaX = moveEvent.clientX - startX;
        const deltaY = moveEvent.clientY - startY;

        const nextLeft = clamp(startLeft + deltaX, 0, window.innerWidth - hostRect.width);
        const nextTop = clamp(startTop + deltaY, 0, window.innerHeight - hostRect.height);

        host.style.left = `${nextLeft}px`;
        host.style.top = `${nextTop}px`;
        host.style.right = '';
      };

      const endDrag = () => {
        window.removeEventListener('mousemove', onMove, true);
        window.removeEventListener('mouseup', endDrag, true);
      };

      window.addEventListener('mousemove', onMove, true);
      window.addEventListener('mouseup', endDrag, true);
    };

    dragHandle.addEventListener('mousedown', startDrag);
    dragHandle.addEventListener(
      'touchstart',
      e => {
        if (e.touches.length === 0) return;
        const touch = e.touches[0];
        startDrag({
          clientX: touch.clientX,
          clientY: touch.clientY,
          preventDefault: () => e.preventDefault(),
          stopPropagation: () => e.stopPropagation(),
        });
      },
      { passive: false },
    );

    dragHandle.dataset.dragBound = 'true';
  }

  function buildPreviewSrcdoc(content) {
    const reactCdn = 'https://unpkg.com/react@18/umd/react.development.js';
    const reactDomCdn = 'https://unpkg.com/react-dom@18/umd/react-dom.development.js';
    const babelCdn = 'https://unpkg.com/@babel/standalone@7.23.9/babel.min.js';
    const html2canvasCdn = 'https://unpkg.com/html2canvas@1.4.1/dist/html2canvas.min.js';

    return `
      <!doctype html>
      <html>
        <head>
          <meta charset="utf-8" />
          <style>
            #root {
              display: block;
              width: fit-content; 
              height: fit-content;
            }
          </style>
        </head>
        <body>
          <div id="root"></div>
          <script crossorigin src="${reactCdn}"></script>
          <script crossorigin src="${reactDomCdn}"></script>
          <script src="${babelCdn}"></script>
          <script src="${html2canvasCdn}"></script>
          <script type="text/babel" data-presets="react" data-plugins="transform-modules-umd">
            const render = element => {
              const rootEl = document.getElementById('root');
              if (!rootEl.__root) {
                rootEl.__root = ReactDOM.createRoot(rootEl);
              }
              rootEl.__root.render(element);
            };
            try {
              ${content}
            } catch (err) {
              const rootEl = document.getElementById('root');
              rootEl.innerHTML = '<pre style="color:#f87171">Error: ' + (err?.message || err) + '</pre>';
              console.error('Preview error:', err);
            }
          </script>
        </body>
      </html>`;
  }

  /**
   * Renders a simple draggable widget that shows generated code (or any string content).
   *
   * @param {string} content - The code or text to display.
   */
  function renderGeneratedWidget(content) {
    const fallbackContent = `
    function InterpretPastedScreenshot() {
      const [imageDataUrl, setImageDataUrl] = React.useState(null);
      const [isLoading, setIsLoading] = React.useState(false);
      const [result, setResult] = React.useState(null);
      const [error, setError] = React.useState(null);

      const OPENAI_API_KEY = ""
      
      const handlePaste = (event) => {
        event.preventDefault();
        setError(null);
        setResult(null);

        const clipboardItems = event.clipboardData?.items;
        if (!clipboardItems || clipboardItems.length === 0) {
          setError("No clipboard items found. Copy a screenshot first, then paste here.");
          return;
        }

        let imageItem = null;
        for (let i = 0; i < clipboardItems.length; i++) {
          const item = clipboardItems[i];
          if (item.type && item.type.startsWith("image/")) {
            imageItem = item;
            break;
          }
        }

        if (!imageItem) {
          setError("No image found in clipboard. Make sure you copied a screenshot.");
          return;
        }

        const file = imageItem.getAsFile();
        if (!file) {
          setError("Failed to read image from clipboard.");
          return;
        }

        const reader = new FileReader();
        reader.onload = () => {
          setImageDataUrl(reader.result);
        };
        reader.onerror = () => {
          setError("Failed to convert clipboard image.");
        };
        reader.readAsDataURL(file);
      };

      const handleInterpret = async () => {
        setError(null);

        if (!imageDataUrl) {
          setError("Please paste a screenshot first.");
          return;
        }

        if (!OPENAI_API_KEY || OPENAI_API_KEY === "YOUR_OPENAI_API_KEY") {
          setError("Please set your OpenAI API key in the widget (securely).");
          return;
        }

        setIsLoading(true);
        setResult(null);

        try {
          const res = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": "Bearer " + OPENAI_API_KEY,
            },
            body: JSON.stringify({
              model: "gpt-4o",
              messages: [
                {
                  role: "user",
                  content: [
                    {
                      type: "text",
                      text: "Interpret this screenshot of a chart or visualization. Provide TWO sentences with concise summary, key trends, and notable anomalies (if any)."
                    },
                    {
                      type: "image_url",
                      image_url: { url: imageDataUrl }
                    }
                  ]
                }
              ],
              max_tokens: 400,
            }),
          });

          if (!res.ok) {
            console.error("OpenAI error status:", res.status);
            throw new Error("OpenAI API error");
          }

          const data = await res.json();
          const message =
            data &&
            data.choices &&
            data.choices[0] &&
            data.choices[0].message &&
            data.choices[0].message.content;

          setResult(message || "No response from the model.");
        } catch (err) {
          console.error(err);
          setError("Error interpreting screenshot.");
        } finally {
          setIsLoading(false);
        }
      };

      return (
        <>

          {error && (
            <div style={{ color: "red", marginBottom: "8px" }}>
              {error}
            </div>
          )}

          <div
            onPaste={handlePaste}
            contentEditable={true}
            suppressContentEditableWarning={true}
            style={{
              border: "1px dashed #9ca3af",
              padding: "16px",
              marginBottom: "12px",
              minWidth: "220px",
              minHeight: "10px",
              borderRadius: "6px",
              fontSize: "12px",
              outline: "none",
              cursor: "text",
              backgroundColor: "#f9fafb",
            }}
          >
            <p style={{ margin: 0 }}>
              Click here and press <strong>Ctrl+V</strong> (or <strong>Cmd+V</strong> on Mac)
              to paste a screenshot from your clipboard and interprete.
            </p>
          </div>

          {imageDataUrl && (
            <div style={{ marginBottom: "12px" }}>
              <h3>Preview of pasted screenshot</h3>
              <img
                src={imageDataUrl}
                alt="Pasted screenshot"
                style={{ maxWidth: "100%", maxHeight: "200px" }}
              />
            </div>
          )}

          <button
            onClick={handleInterpret}
            disabled={!imageDataUrl || isLoading}
            style={{
              padding: "6px 10px",
              borderRadius: "4px",
              border: "1px solid #d1d5db",
              background: isLoading || !imageDataUrl ? "#e5e7eb" : "#111827",
              color: isLoading || !imageDataUrl ? "#6b7280" : "#f9fafb",
              fontSize: "12px",
              cursor: !imageDataUrl || isLoading ? "not-allowed" : "pointer",
              marginBottom: "12px",
            }}
          >
            {isLoading ? "Interpreting..." : "Interpret screenshot"}
          </button>

          {result && (
            <div>
              <h3>LLM Interpretation</h3>
              <p style={{ whiteSpace: "pre-wrap" }}>{result}</p>
            </div>
          )}
        </>
      );
    }
    render(<InterpretPastedScreenshot />);
    `;

    let isTopContext = true;
    try {
      isTopContext = window.top === window;
    } catch (e) {
      isTopContext = false;
    }
    if (!isTopContext) return;

    let widget = document.getElementById(GENERATED_WIDGET_ID);
    if (!widget) {
      widget = document.createElement('div');
      widget.id = GENERATED_WIDGET_ID;
      widget.boarder = '1px solid rgba(0, 0, 0, 0.08)';
      widget.style.position = 'fixed';
      widget.style.top = '70px';
      widget.style.right = '12px';
      widget.style.zIndex = String(PANEL_Z_INDEX);
      widget.style.pointerEvents = 'auto';
      widget.style.fontFamily = 'Inter, system-ui, -apple-system, sans-serif';
      widget.style.touchAction = 'none';

      const shell = document.createElement('div');
      shell.style.pointerEvents = 'auto';
      shell.style.background = 'rgb(255, 255, 255)';
      shell.style.color = '#333333';
      shell.style.borderRadius = '8px';
      shell.style.border = '1px solid rgba(0, 0, 0, 0.08)';
      shell.style.boxShadow = '0 6px 15px rgba(0, 0, 0, 0.1)';
      shell.style.width = 'fit-content';
      shell.style.height = 'fit-content';
      shell.style.overflow = 'hidden';
      shell.dataset.generatedShell = 'true';

      const header = document.createElement('div');
      header.style.display = 'flex';
      header.style.alignItems = 'center';
      header.style.justifyContent = 'space-between';
      header.style.gap = '8px';
      header.style.padding = '8px 10px';
      header.style.fontSize = '12px';
      header.style.fontWeight = '600';
      header.style.cursor = 'move';
      header.dataset.generatedWidgetHeader = 'true';

      const title = document.createElement('span');
      title.textContent = 'Function'; // title of the function

      const buttonRow = document.createElement('div');
      buttonRow.style.display = 'flex';
      buttonRow.style.gap = '4px'; // Reduced gap

      const createButton = (text, onClick) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.textContent = text;
        btn.style.background = 'transparent';
        btn.style.color = '#525252';
        btn.style.border = '1px solid #e5e7eb';
        btn.style.borderRadius = '5px';
        btn.style.padding = '3px 8px';
        btn.style.fontSize = '11px';
        btn.style.cursor = 'pointer';
        btn.addEventListener('click', onClick);
        return btn;
      };

      const collapseBtn = createButton('➖', e => {
        e.preventDefault();
        e.stopPropagation();
        const isCollapsed = body.style.display === 'none';
        if (isCollapsed) {
          body.style.display = '';
          collapseBtn.textContent = '➖';
        } else {
          body.style.display = 'none';
          collapseBtn.textContent = '➕';
        }
      });

      const deleteBtn = createButton('✖️', e => {
        e.preventDefault();
        e.stopPropagation();
        widget.remove();
      });
      deleteBtn.style.borderRadius = '999px';
      deleteBtn.style.width = '20px';
      deleteBtn.style.height = '20px';
      deleteBtn.style.display = 'flex';
      deleteBtn.style.alignItems = 'center';
      deleteBtn.style.justifyContent = 'center';
      deleteBtn.style.padding = '0';
      deleteBtn.style.fontSize = '14px';
      deleteBtn.style.lineHeight = '1';

      const body = document.createElement('div');
      body.style.padding = '0 10px 10px';
      body.dataset.generatedBody = 'true';
      body.style.width = 'fit-content';
      body.style.height = 'fit-content';

      const previewFrame = document.createElement('iframe');
      previewFrame.dataset.generatedPreview = 'true';
      previewFrame.style.width = 'fit-content';
      previewFrame.style.height = 'fit-content';
      previewFrame.style.border = '1px solid #e5e7eb';
      previewFrame.style.borderRadius = '6px';
      previewFrame.style.background = 'transparent';
      previewFrame.style.display = 'block';
      previewFrame.sandbox = 'allow-scripts allow-same-origin';
      body.appendChild(previewFrame);

      shell.appendChild(header);
      shell.appendChild(body);
      widget.appendChild(shell);
      document.body.appendChild(widget);

      attachDrag(header, widget);

      buttonRow.appendChild(collapseBtn);
      buttonRow.appendChild(deleteBtn);

      header.appendChild(title);
      header.appendChild(buttonRow);

      shell.appendChild(header);
      shell.appendChild(body);
      widget.appendChild(shell);
      document.body.appendChild(widget);

      attachDrag(header, widget);
    }

    const iframe = widget.querySelector('iframe[data-generated-preview]');

    console.log('content', content);

    if (iframe) {
      iframe.removeAttribute('src');
      // const src = typeof content === 'string' && content.trim().length ? content : fallbackContent;
      iframe.srcdoc = buildPreviewSrcdoc(fallbackContent);
      // console.log('iframe.srcdoc', iframe.srcdoc);
    }
    widget.style.pointerEvents = 'auto';
  }

  window.renderGeneratedWidget = renderGeneratedWidget;
})();
